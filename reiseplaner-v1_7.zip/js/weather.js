/**
 * weather.js – Wetter-Forecast (Track 3, Punkt 7)
 * ===================================================
 * Nutzt Open-Meteo (kostenlos, kein API-Key nötig, CORS-freundlich).
 * Datenmodell: station.weatherCache = { fetchedAt, days: [{date, tempMax,
 * tempMin, precipProb, wmoCode}] }
 *
 * Open-Meteo liefert nur ca. 16 Tage Vorhersage in die Zukunft. Stationen,
 * deren Aufenthaltszeitraum außerhalb dieses Horizonts liegt, zeigen
 * "Vorhersage nicht verfügbar" statt eines API-Fehlers.
 */

import { S } from './state.js';
import { saveStationToCloud } from './firebase.js';
import { getStayRange } from './duration.js';

const CACHE_MAX_AGE_MS = 24 * 60 * 60 * 1000;
const FORECAST_HORIZON_DAYS = 16;

const WMO_ICON_MAP = {
    0: ['fa-sun', 'Klar', 'wx-sunny'],
    1: ['fa-sun', 'Meist klar', 'wx-sunny'], 2: ['fa-cloud-sun', 'Teilweise bewölkt', 'wx-sunny'], 3: ['fa-cloud', 'Bewölkt', 'wx-fog'],
    45: ['fa-smog', 'Nebel', 'wx-fog'], 48: ['fa-smog', 'Nebel', 'wx-fog'],
    51: ['fa-cloud-rain', 'Nieselregen', 'wx-rain'], 53: ['fa-cloud-rain', 'Nieselregen', 'wx-rain'], 55: ['fa-cloud-rain', 'Nieselregen', 'wx-rain'],
    56: ['fa-cloud-rain', 'Gefrierender Niesel', 'wx-rain'], 57: ['fa-cloud-rain', 'Gefrierender Niesel', 'wx-rain'],
    61: ['fa-cloud-showers-heavy', 'Regen leicht', 'wx-rain'], 63: ['fa-cloud-showers-heavy', 'Regen', 'wx-rain'], 65: ['fa-cloud-showers-heavy', 'Starkregen', 'wx-rain'],
    66: ['fa-cloud-showers-heavy', 'Gefrierender Regen', 'wx-rain'], 67: ['fa-cloud-showers-heavy', 'Gefrierender Regen', 'wx-rain'],
    71: ['fa-snowflake', 'Schnee leicht', 'wx-snow'], 73: ['fa-snowflake', 'Schnee', 'wx-snow'], 75: ['fa-snowflake', 'Starker Schnee', 'wx-snow'], 77: ['fa-snowflake', 'Schneekörner', 'wx-snow'],
    80: ['fa-cloud-showers-heavy', 'Schauer', 'wx-rain'], 81: ['fa-cloud-showers-heavy', 'Schauer', 'wx-rain'], 82: ['fa-cloud-showers-heavy', 'Heftige Schauer', 'wx-rain'],
    85: ['fa-snowflake', 'Schneeschauer', 'wx-snow'], 86: ['fa-snowflake', 'Schneeschauer', 'wx-snow'],
    95: ['fa-bolt', 'Gewitter', 'wx-storm'], 96: ['fa-bolt', 'Gewitter mit Hagel', 'wx-storm'], 99: ['fa-bolt', 'Starkes Gewitter mit Hagel', 'wx-storm']
};

function wmoIcon(code) { return (WMO_ICON_MAP[code] || ['fa-cloud-question', 'Unbekannt', 'wx-fog'])[0]; }
function wmoLabel(code) { return (WMO_ICON_MAP[code] || ['fa-cloud-question', 'Unbekannt', 'wx-fog'])[1]; }
// Bugfix (Wolke-mit-Regen zeigte pauschal Sonnen-Gelb): eigene CSS-Klasse pro
// Wettertyp statt einer global fest verdrahteten Icon-Farbe.
function wmoColorClass(code) { return (WMO_ICON_MAP[code] || ['fa-cloud-question', 'Unbekannt', 'wx-fog'])[2]; }

function isCacheFresh(station) {
    return station.weatherCache && station.weatherCache.fetchedAt && (Date.now() - station.weatherCache.fetchedAt) < CACHE_MAX_AGE_MS;
}

/**
 * Rettet Tage aus dem (noch aktuellen, aber gleich zu überschreibenden)
 * weatherCache, die inzwischen in der Vergangenheit liegen, in ein
 * separates Archiv station.weatherArchive, BEVOR sie durch den neuen
 * 16-Tage-Cache verdrängt werden. So bleibt "die letzte Prognose, die es
 * für diesen Tag gab" dauerhaft sichtbar - nützlich, wenn man eine Reise
 * Jahre später nochmal anschaut und sehen will, wie das Wetter tatsächlich
 * vorhergesagt war (nicht: wie es wirklich war, das kann diese Wetter-API
 * nicht rückwirkend liefern - siehe Kommentar oben in der Datei).
 *
 * Absichtlich NUR beim regulären Refresh aufgerufen (nicht bei jedem
 * renderWeatherStrip-Aufruf) - ein Tag wird also archiviert, sobald er
 * beim nächsten 24h-Refresh erstmals nicht mehr im Live-Fenster auftaucht,
 * mit dem zu dem Zeitpunkt letzten bekannten Stand.
 */
function archivePastDays(station) {
    if (!station.weatherCache || !station.weatherCache.days) return;
    if (!station.weatherArchive) station.weatherArchive = {};
    const today = new Date(); today.setHours(0, 0, 0, 0);
    for (const day of station.weatherCache.days) {
        const d = new Date(day.date + 'T00:00:00');
        if (d < today) station.weatherArchive[day.date] = day;
    }
}

async function fetchWeatherForStation(station) {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${station.lat}&longitude=${station.lng}&daily=weathercode,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=${FORECAST_HORIZON_DAYS}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Open-Meteo Fehler ' + res.status);
    const data = await res.json();
    if (!data.daily || !data.daily.time) throw new Error('Unerwartetes Antwortformat');

    archivePastDays(station); // vor dem Überschreiben: heute schon vergangene Tage sichern

    const days = data.daily.time.map((date, i) => ({
        date,
        tempMax: data.daily.temperature_2m_max[i],
        tempMin: data.daily.temperature_2m_min[i],
        precipProb: data.daily.precipitation_probability_max[i],
        wmoCode: data.daily.weathercode[i]
    }));

    station.weatherCache = { fetchedAt: Date.now(), days };
    saveStationToCloud(station);
    return station.weatherCache;
}

export function ensureWeather(station, onUpdated) {
    if (isCacheFresh(station)) return;
    fetchWeatherForStation(station)
        .then(() => { if (onUpdated) onUpdated(); })
        .catch(err => console.warn('Wetter-Abruf fehlgeschlagen für', station.name, err.message));
}

/**
 * Bugfix: lieferte für Tage in der Vergangenheit dieselbe "zu weit in der
 * Zukunft"-Meldung wie für Tage jenseits des 16-Tage-Horizonts (diffDays < 0
 * fiel unter denselben false-Fall wie diffDays >= FORECAST_HORIZON_DAYS).
 * Vergangene Tage sind ein eigener Fall: Open-Meteo liefert dafür grundsätzlich
 * keine Vorhersage (auch nicht rückwirkend), das ist kein "zu weit in der
 * Zukunft"-Problem, sondern schlicht "kein Forecast für diesen Tag verfügbar".
 */
function dayInHorizon(dateStr) {
    const target = new Date(dateStr + 'T00:00:00');
    const today = new Date(); today.setHours(0,0,0,0);
    const diffDays = Math.round((target - today) / 86400000);
    return diffDays >= 0 && diffDays < FORECAST_HORIZON_DAYS;
}

function dayIsPast(dateStr) {
    const target = new Date(dateStr + 'T00:00:00');
    const today = new Date(); today.setHours(0,0,0,0);
    return target < today;
}

function findDayEntry(station, dateStr) {
    if (station.weatherCache) {
        const live = station.weatherCache.days.find(d => d.date === dateStr);
        if (live) return live;
    }
    // Fallback: archivierte "letzte bekannte Prognose" für vergangene Tage
    if (station.weatherArchive && station.weatherArchive[dateStr]) {
        return station.weatherArchive[dateStr];
    }
    return null;
}

/**
 * Wetter-Badge für den Karten-Marker. Zeigt bis zu 3 Tage ab dem ANKUNFTSTAG
 * der Station (nicht "heute" - eine Station, die erst in einer Woche besucht
 * wird, soll auch das Wetter von dann zeigen). Begrenzt auf die tatsächliche
 * Aufenthaltsdauer (eine 1-Tages-Station zeigt nur 1 Tag) und auf das, was im
 * 16-Tage-Cache verfügbar ist. Vorher: nur 1 Tag (Ankunftstag) - Nutzer-
 * Feedback war, dass mind. die ersten 3 Tage auf der Karte sichtbar sein sollen.
 */
export function getMarkerWeatherBadge(station) {
    const hasLive = station.weatherCache && station.weatherCache.days.length;
    const hasArchive = station.weatherArchive && Object.keys(station.weatherArchive).length;
    if (!hasLive && !hasArchive) return null;
    const range = getStayRange(station);
    if (!range) return null;   // Bugfix: ohne Aufenthaltszeitraum kein Fallback mehr auf "heute" (siehe Punkt "es werden auch für das Ziel Zeiträume kalkuliert")

    const stayDays = [];
    for (let d = new Date(range.start + 'T00:00:00'); d <= new Date(range.end + 'T00:00:00'); d.setDate(d.getDate() + 1)) {
        stayDays.push(new Date(d).toISOString().slice(0, 10));
        if (stayDays.length >= 3) break;   // max. 3 Tage im Marker-Badge (Platzgründe)
    }
    if (!stayDays.length) stayDays.push(range.start);

    const entries = stayDays
        .map(dateStr => ({ dateStr, entry: findDayEntry(station, dateStr) }))
        .filter(d => d.entry);

    if (!entries.length && hasLive) {
        // Kein exakter Treffer im Cache (z.B. Ankunftstag knapp außerhalb des
        // 16-Tage-Horizonts) - nächstgelegenen Tag als einzelnen Eintrag nehmen.
        const target = new Date(stayDays[0] + 'T00:00:00');
        const fallback = station.weatherCache.days.reduce((best, d) => {
            const diff = Math.abs(new Date(d.date + 'T00:00:00') - target);
            return (!best || diff < best.diff) ? { ...d, diff } : best;
        }, null);
        if (!fallback) return null;
        entries.push({ dateStr: fallback.date, entry: fallback });
    }
    if (!entries.length) return null;

    return {
        days: entries.map(({ dateStr, entry }) => ({
            icon: wmoIcon(entry.wmoCode), colorClass: wmoColorClass(entry.wmoCode),
            tempMax: Math.round(entry.tempMax), date: entry.date, isExact: entry.date === dateStr
        })),
        lat: station.lat, lng: station.lng
    };
}

export function renderWeatherStrip(station) {
    const el = document.getElementById('sp-weather');
    if (!el) return;

    const range = getStayRange(station);
    if (!range) { el.innerHTML = ''; return; }

    ensureWeather(station, () => renderWeatherStrip(station));

    const start = new Date(range.start + 'T00:00:00');
    const end = new Date(range.end + 'T00:00:00');
    const dayList = [];
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
        dayList.push(new Date(d).toISOString().slice(0, 10));
    }

    // Punkt: Wetter-Archiv – ein Tag gilt als "zeigbar", wenn er entweder im
    // Live-Horizont liegt ODER eine archivierte letzte Prognose existiert.
    // Nur wenn WEDER noch aussteht.
    const dayShowable = dateStr => dayInHorizon(dateStr) || !!findDayEntry(station, dateStr);

    if (!dayList.some(dayShowable)) {
        // Bugfix: eigene, korrekte Meldung wenn der GESAMTE Zeitraum in der
        // Vergangenheit liegt - "zu weit in der Zukunft" war hier schlicht
        // falsch (siehe dayInHorizon-Kommentar).
        const allPast = dayList.every(dayIsPast);
        el.innerHTML = allPast
            ? `<div class="text-[11px] text-slate-400 italic"><i class="fa-regular fa-clock"></i> Keine Vorhersage für vergangene Tage verfügbar</div>`
            : `<div class="text-[11px] text-slate-400 italic"><i class="fa-regular fa-clock"></i> Vorhersage noch nicht verfügbar (zu weit in der Zukunft)</div>`;
        return;
    }

    el.innerHTML = `<div class="weather-strip">${dayList.map(dateStr => {
        if (!dayShowable(dateStr)) {
            // Bugfix: vergangene Tage bekommen ein eigenes Icon/Tooltip statt
            // dieselbe "Uhr"-Darstellung wie zukünftige, noch nicht abrufbare Tage.
            const icon = dayIsPast(dateStr) ? 'fa-clock-rotate-left' : 'fa-regular fa-clock';
            const title = dayIsPast(dateStr) ? 'Keine Vorhersage für vergangene Tage' : 'Noch außerhalb des Vorhersage-Horizonts';
            return `<div class="weather-day weather-day-unavailable" title="${title}"><span>${new Date(dateStr + 'T12:00:00').toLocaleDateString('de-DE', { weekday: 'short' })}</span><i class="fa-solid ${icon}"></i></div>`;
        }
        const entry = findDayEntry(station, dateStr);
        if (!entry) {
            return `<div class="weather-day weather-day-loading"><span>${new Date(dateStr + 'T12:00:00').toLocaleDateString('de-DE', { weekday: 'short' })}</span><i class="fa-solid fa-spinner fa-spin"></i></div>`;
        }
        // Punkt: Wetter-Archiv – archivierte (nicht mehr live abrufbare) Tage
        // bekommen einen dezenten Hinweis im Titel, sonst identische Darstellung.
        const isArchived = !dayInHorizon(dateStr);
        const title = isArchived ? `${wmoLabel(entry.wmoCode)} (letzte bekannte Prognose)` : wmoLabel(entry.wmoCode);
        return `<div class="weather-day${isArchived ? ' weather-day-archived' : ''}" title="${title}">
            <span>${new Date(dateStr + 'T12:00:00').toLocaleDateString('de-DE', { weekday: 'short' })}</span>
            <i class="fa-solid ${wmoIcon(entry.wmoCode)} ${wmoColorClass(entry.wmoCode)}"></i>
            <span class="weather-temp">${Math.round(entry.tempMax)}°</span>
            ${entry.precipProb != null ? `<span class="weather-precip"><i class="fa-solid fa-droplet"></i>${entry.precipProb}%</span>` : ''}
        </div>`;
    }).join('')}</div>
    <a href="https://www.google.com/search?q=wetter+${station.lat},${station.lng}" target="_blank" class="weather-detail-link"><i class="fa-solid fa-arrow-up-right-from-square"></i> Ausführliche Vorhersage ansehen</a>`;
}
