/**
 * routing.js – Echte Straßenroute zwischen zwei Stationen (statt Luftlinie)
 * =========================================================================
 * Hintergrund: POIs (Punkt 8/8b) wurden bisher anhand der LUFTLINIE zwischen
 * zwei Stationen platziert bzw. validiert. Bei kurvigen Strecken (Küsten,
 * Berge, Umwege) kann das stark danebenliegen - ein POI "nah an der Route"
 * kann trotzdem weit von der tatsächlich befahrenen Straße entfernt sein.
 *
 * Nutzt OSRM (Open Source Routing Machine, öffentlicher Demo-Server,
 * kostenlos, kein API-Key nötig - im Unterschied zu Google Directions, wofür
 * ein separater, in diesem Projekt nicht vorhandener API-Key nötig wäre).
 * Der öffentliche Server hat keine Uptime-Garantie, daher überall mit
 * Luftlinien-Fallback bei Fehlern/Timeout.
 *
 * Datenmodell: station.segmentFromPrev.routePolyline = [[lat,lng], ...]
 * (gecacht analog zu weatherCache - wird nicht bei jedem renderMap() neu
 * abgerufen, nur wenn noch keine Route für dieses Segment vorliegt).
 */

import { S } from './state.js';
import { saveStationToCloud } from './firebase.js';

const OSRM_BASE = 'https://router.project-osrm.org/route/v1/driving';

/**
 * Holt die Straßenroute zwischen zwei Stationen. Gibt bei Erfolg ein Array
 * von [lat,lng]-Punkten zurück, bei Fehler/Timeout null (Aufrufer muss dann
 * selbst auf Luftlinie zurückfallen).
 */
export async function fetchRoutePolyline(prevStation, curStation) {
    try {
        const url = `${OSRM_BASE}/${prevStation.lng},${prevStation.lat};${curStation.lng},${curStation.lat}?overview=full&geometries=geojson`;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 7000);
        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(timeout);
        if (!res.ok) throw new Error('OSRM-Fehler ' + res.status);

        const data = await res.json();
        if (!data.routes || !data.routes.length) throw new Error('Keine Route gefunden');

        // GeoJSON liefert [lng,lat]-Paare, wir arbeiten intern mit [lat,lng]
        return data.routes[0].geometry.coordinates.map(([lng, lat]) => [lat, lng]);
    } catch (e) {
        console.warn('Straßenrouten-Abruf fehlgeschlagen für', prevStation.name, '→', curStation.name, e.message);
        return null;
    }
}

/**
 * Liefert die gecachte Route für die Etappe, die zu `curStation` führt.
 * Ruft bei Bedarf OSRM ab und speichert das Ergebnis. Fällt bei Fehler auf
 * eine einfache 2-Punkt-Luftlinie zurück (Aufrufer merkt den Unterschied
 * nicht - beide Formate sind [[lat,lng],...]-Arrays), damit nachgelagerte
 * Distanzberechnungen (POI-Validierung) niemals ganz ohne Route dastehen.
 */
export async function ensureRoutePolyline(prevStation, curStation) {
    if (curStation.segmentFromPrev && curStation.segmentFromPrev.routePolyline) {
        return curStation.segmentFromPrev.routePolyline;
    }
    const polyline = await fetchRoutePolyline(prevStation, curStation);
    const finalPolyline = polyline || [[prevStation.lat, prevStation.lng], [curStation.lat, curStation.lng]];

    if (!curStation.segmentFromPrev) curStation.segmentFromPrev = {};
    curStation.segmentFromPrev.routePolyline = finalPolyline;
    curStation.segmentFromPrev.routeIsFallback = !polyline;
    saveStationToCloud(curStation);
    return finalPolyline;
}

/** Liefert die gecachte Route synchron, ohne einen Abruf auszulösen (für Distanzberechnungen, die nicht auf einen Netzwerk-Roundtrip warten können). Luftlinie als Fallback, wenn noch nichts gecacht ist. */
export function getCachedRoutePolyline(prevStation, curStation) {
    if (curStation.segmentFromPrev && curStation.segmentFromPrev.routePolyline) {
        return curStation.segmentFromPrev.routePolyline;
    }
    return [[prevStation.lat, prevStation.lng], [curStation.lat, curStation.lng]];
}

/**
 * Sorgt dafür, dass jede Etappe eine (gecachte) Route hat. Wird bei jedem
 * renderMap() aufgerufen, analog zu ensureSegmentInfo()/ensurePoiSuggestions().
 * Befüllt nur fehlende Routen, ruft OSRM nicht erneut für bereits gecachte
 * Segmente auf.
 */
export function ensureAllRoutePolylines() {
    for (let i = 1; i < S.stations.length; i++) {
        const cur = S.stations[i];
        const prev = S.stations[i - 1];
        if (cur.segmentFromPrev && cur.segmentFromPrev.routePolyline) continue;
        ensureRoutePolyline(prev, cur);
    }
}

/** Kürzeste Distanz (km) eines Punktes zu einer Polyline (Route oder Luftlinien-Fallback). */
export function distancePointToPolylineKm(point, polyline) {
    let best = Infinity;
    for (let i = 1; i < polyline.length; i++) {
        const d = distancePointToSegmentKm(point, { lat: polyline[i - 1][0], lng: polyline[i - 1][1] }, { lat: polyline[i][0], lng: polyline[i][1] });
        if (d < best) best = d;
    }
    return best;
}

function distancePointToSegmentKm(p, a, b) {
    const toXY = (pt) => ({ x: pt.lng * Math.cos(a.lat * Math.PI / 180), y: pt.lat });
    const P = toXY(p), A = toXY(a), B = toXY(b);
    const dx = B.x - A.x, dy = B.y - A.y;
    const lenSq = dx * dx + dy * dy;
    let t = lenSq === 0 ? 0 : ((P.x - A.x) * dx + (P.y - A.y) * dy) / lenSq;
    t = Math.max(0, Math.min(1, t));
    const closest = { lat: A.y + t * dy, lng: (A.x + t * dx) / Math.cos(a.lat * Math.PI / 180) };
    return distanceKm(p.lat, p.lng, closest.lat, closest.lng);
}

function distanceKm(lat1, lng1, lat2, lng2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLng/2)**2;
    return 2 * R * Math.asin(Math.sqrt(a));
}

/**
 * Liefert ein paar Wegpunkte ENTLANG der tatsächlichen Route (nicht nur
 * Start/Ende), zum Einbetten in KI-Prompts (Punkt 8b), damit die KI POIs
 * näher an der echten Straße vorschlägt statt an der Luftlinie zwischen den
 * beiden Stationen.
 */
export function getRouteWaypoints(polyline, count = 4) {
    if (!polyline || polyline.length < 2) return [];
    const step = Math.max(1, Math.floor(polyline.length / (count - 1)));
    const waypoints = [];
    for (let i = 0; i < polyline.length; i += step) waypoints.push(polyline[i]);
    if (waypoints[waypoints.length - 1] !== polyline[polyline.length - 1]) waypoints.push(polyline[polyline.length - 1]);
    return waypoints.slice(0, count);
}
