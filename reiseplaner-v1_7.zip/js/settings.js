/**
 * settings.js – Admin-/Zugriffsrechte, Lock-Screen, Einstellungen-Modal
 */

import { S, DEFAULT_AI_STYLE, tripKey } from './state.js';
import { sha256, tripTitle, showToast, esc } from './utils.js';
import { updateSidePanel } from './stations.js';
import { renderMap } from './map.js';
import { updateGeoTrackStatus } from './geo.js';
import { recalculateStays } from './duration.js';
import { tripDoc, setDoc, subscribeStations, applyTripBranding, renderTripSelect, saveStationToCloud } from './firebase.js';

export async function applyAdminRights() {
    const stored = localStorage.getItem(tripKey('admin_pwd')) || '';
    if (!S.trip) S.isAdmin = false;
    else if (!S.trip.adminHash) S.isAdmin = true;
    else S.isAdmin = stored ? (await sha256(stored)) === S.trip.adminHash : false;

    document.getElementById('body-root').classList.toggle('is-admin', S.isAdmin);
    if (!S.isAdmin) setPreviewMode(false); // F4: Logout beendet automatisch auch die Vorschau
    if (S.currentStationId) updateSidePanel(S.currentStationId);
    applyTripBranding();   // Bugfix (Punkt 3): Header-Hinweis "Zeitraum fehlt" hängt vom Admin-Status ab, muss bei Login/Logout neu berechnet werden
    renderMap();
}

/**
 * F4: Admin-Vorschau-Umschalter. Lässt einen eingeloggten Admin zwischen
 * der normalen Bearbeiten-Ansicht und der Ansicht, die normale Betrachter
 * sehen, wechseln - ohne sich aus- und wieder einzuloggen. Der Umschalter-
 * Button selbst bleibt via CSS (.preview-mode #btn-preview-toggle) immer
 * sichtbar, damit man jederzeit zurück in den Bearbeiten-Modus kommt.
 */
function setPreviewMode(on) {
    S.previewMode = on;
    const root = document.getElementById('body-root');
    if (root) root.classList.toggle('preview-mode', on);
}

window.togglePreviewMode = function() {
    if (!S.isAdmin) return;
    setPreviewMode(!S.previewMode);
    if (S.currentStationId) updateSidePanel(S.currentStationId);
    renderMap();
};

export async function checkViewAccess() {
    if (!S.trip) return false;
    if (!S.trip.viewHash) { S.hasViewAccess = true; return true; }
    const stored = localStorage.getItem(tripKey('view_pwd')) || '';
    S.hasViewAccess = stored ? (await sha256(stored)) === S.trip.viewHash : false;
    if (!S.hasViewAccess) {
        const a = localStorage.getItem(tripKey('admin_pwd')) || '';
        if (a && S.trip.adminHash && (await sha256(a)) === S.trip.adminHash) S.hasViewAccess = true;
    }
    return S.hasViewAccess;
}

export function showLockScreen(show) {
    const el = document.getElementById('lock-screen');
    if (!el) return;
    el.classList.toggle('hidden', !show);
    el.classList.toggle('flex', show);
    if (show) document.getElementById('lock-trip-name').innerText = tripTitle();
}

/**
 * Punkt: Reise-Auswahl vor Passwortabfrage.
 * Zeigt/versteckt den Auswahlbildschirm mit allen Reisen + "Neue Reise anlegen".
 * Wird beim allerersten Start ohne gespeicherte Reise-Wahl gezeigt, sowie über
 * "Andere Reise auswählen" auf dem Sperrbildschirm jederzeit wieder erreichbar.
 */
export function showTripPicker(show) {
    const el = document.getElementById('trip-picker-screen');
    if (!el) return;
    el.classList.toggle('hidden', !show);
    el.classList.toggle('flex', show);
}
window.showTripPicker = function() {
    renderTripPickerList(S.trips);
    showLockScreen(false);
    showTripPicker(true);
};

export function renderTripPickerList(trips) {
    const list = document.getElementById('trip-picker-list');
    if (!list) return;
    if (!trips.length) {
        list.innerHTML = `<p class="text-indigo-300 text-xs">Noch keine Reise angelegt. Leg die erste über den Button unten an.</p>`;
        return;
    }
    list.innerHTML = trips.map(t => `
        <button onclick="window.pickTrip('${esc(t.id)}')"
                class="w-full bg-indigo-900/60 hover:bg-indigo-800 border border-indigo-700 text-white rounded px-3 py-2.5 text-sm text-left flex items-center justify-between gap-2 transition">
            <span class="truncate">${esc(t.name)}</span>
            ${t.viewHash || t.adminHash ? '<i class="fa-solid fa-lock text-indigo-400 text-xs shrink-0"></i>' : ''}
        </button>
    `).join('');
}

window.pickTrip = async function(id) {
    localStorage.setItem('active_trip_id', id);
    showTripPicker(false);
    await window.__selectTripAfterPicker(id);
};

window.submitLockPassword = async function() {
    const pwd = document.getElementById('lock-pwd-input').value;
    const err = document.getElementById('lock-error');
    const hash = await sha256(pwd);

    if (S.trip && S.trip.viewHash && hash === S.trip.viewHash) {
        localStorage.setItem(tripKey('view_pwd'), pwd);
    } else if (S.trip && S.trip.adminHash && hash === S.trip.adminHash) {
        localStorage.setItem(tripKey('admin_pwd'), pwd);
        localStorage.setItem(tripKey('view_pwd'), pwd);
    } else {
        err.classList.remove('hidden');
        return;
    }
    err.classList.add('hidden');
    document.getElementById('lock-pwd-input').value = '';
    S.hasViewAccess = true;
    showLockScreen(false);
    await applyAdminRights();
    subscribeStations();
};

window.openSettings = function() {
    renderTripSelect();
    document.getElementById('admin-pwd-input').value = localStorage.getItem(tripKey('admin_pwd')) || '';
    document.getElementById('api-key-input').value = S.apiKey;
    document.getElementById('ai-style-input').value = S.aiStyle;
    document.getElementById('trip-name-input').value = (S.trip && S.trip.name) || '';
    document.getElementById('trip-subtitle-input').value = (S.trip && S.trip.subtitle) || '';
    document.getElementById('trip-start-date-input').value = (S.trip && S.trip.startDate) || '';
    document.getElementById('trip-end-date-input').value = (S.trip && S.trip.endDate) || '';
    document.getElementById('new-admin-pwd').value = '';
    document.getElementById('new-view-pwd').value = '';
    document.getElementById('clear-view-pwd').checked = false;
    updateAdminStatusLabel();
    document.getElementById('settings-modal').classList.remove('hidden');
    updateGeoTrackStatus();
};

function updateAdminStatusLabel() {
    const el = document.getElementById('admin-status');
    if (!el) return;
    if (S.isAdmin) el.innerHTML = '<span class="text-emerald-600"><i class="fa-solid fa-circle-check"></i> Als Admin angemeldet</span>';
    else if (S.trip && S.trip.adminHash) el.innerHTML = '<span class="text-slate-400"><i class="fa-solid fa-eye"></i> Nur-Lese-Modus</span>';
    else el.innerHTML = '<span class="text-amber-600"><i class="fa-solid fa-triangle-exclamation"></i> Noch kein Admin-Passwort gesetzt</span>';
}

window.closeSettings = function() {
    document.getElementById('settings-modal').classList.add('hidden');
};

window.saveSettings = async function() {
    const entered = document.getElementById('admin-pwd-input').value;
    if (entered) localStorage.setItem(tripKey('admin_pwd'), entered);
    else localStorage.removeItem(tripKey('admin_pwd'));
    await applyAdminRights();

    if (S.isAdmin && S.trip && S.db) {
        const patch = {};
        const name = document.getElementById('trip-name-input').value.trim();
        const subtitle = document.getElementById('trip-subtitle-input').value.trim();
        const newStartDate = document.getElementById('trip-start-date-input').value;
        const newEndDate = document.getElementById('trip-end-date-input').value;
        const newApiKey = document.getElementById('api-key-input').value.trim();
        const newStyle = document.getElementById('ai-style-input').value.trim() || DEFAULT_AI_STYLE;
        const newAdminPwd = document.getElementById('new-admin-pwd').value;
        const newViewPwd = document.getElementById('new-view-pwd').value;
        const clearView = document.getElementById('clear-view-pwd').checked;

        if (newStartDate && newEndDate && new Date(newEndDate) < new Date(newStartDate)) {
            return showToast('Das Enddatum der Reise liegt vor dem Startdatum.', 'info');
        }

        if (name && name !== S.trip.name) patch.name = name;
        if (subtitle !== (S.trip.subtitle || '')) patch.subtitle = subtitle;
        const stayRangeChanged = newStartDate !== (S.trip.startDate || '') || newEndDate !== (S.trip.endDate || '');
        if (stayRangeChanged) { patch.startDate = newStartDate; patch.endDate = newEndDate; }
        if (newApiKey !== (S.trip.apiKey || '')) patch.apiKey = newApiKey;
        if (newStyle !== (S.trip.aiStyle || '')) patch.aiStyle = newStyle;

        if (newAdminPwd) {
            if (newAdminPwd.length < 4) return showToast('Das neue Admin-Passwort muss mindestens 4 Zeichen haben.', 'info');
            patch.adminHash = await sha256(newAdminPwd);
            localStorage.setItem(tripKey('admin_pwd'), newAdminPwd);
        }
        if (clearView) {
            patch.viewHash = '';
            localStorage.removeItem(tripKey('view_pwd'));
        } else if (newViewPwd) {
            patch.viewHash = await sha256(newViewPwd);
            localStorage.setItem(tripKey('view_pwd'), newViewPwd);
        }

        if (Object.keys(patch).length) {
            try {
                await setDoc(tripDoc(S.tripId), patch, { merge: true });
                Object.assign(S.trip, patch);
                S.apiKey = S.trip.apiKey || '';
                S.aiStyle = S.trip.aiStyle || DEFAULT_AI_STYLE;
                applyTripBranding();
                renderTripSelect();
                if (stayRangeChanged) {
                    recalculateStays();
                    S.stations.forEach(st => saveStationToCloud(st));
                    renderMap();
                }
            } catch(e) {
                return showToast('Einstellungen konnten nicht gespeichert werden: ' + e.message, 'error');
            }
        }
    }

    updateAdminStatusLabel();
    S.hasViewAccess = await checkViewAccess();
    showLockScreen(!S.hasViewAccess);
    if (S.hasViewAccess && !S.stationsUnsub) subscribeStations();
    window.closeSettings();
};
