/**
 * media.js – Foto-Upload (inkl. EXIF & Google-Takeout-ZIP), Foto-Editor,
 * chronologischer Foto-Viewer, globale Galerie, ZIP-Export
 */

import { S } from './state.js';
import { esc, distanceKm, dayKey, photoFileName, slugifyName, toggleLoader, tripTitle, resolvePhotoSrc, showToast, showUploadProgress, updateUploadProgress, hideUploadProgress } from './utils.js';
import { findTrackLocation } from './geo.js';
import { getAllPhotosChronological, getTravelDays, renderMap, renderPhotoMarkers } from './map.js';
import { updateSidePanel } from './stations.js';
import { saveStationToCloud, storageRef, uploadBytes, getDownloadURL, deleteObject } from './firebase.js';

// ---- Modul-privater State ----
let editingPhotoIndex = null;
let peMap = null;
let peMarker = null;
const preloadCache = new Map();
let galleryPhotoList = [];

// Foto-Viewer-State: wird auch von map.js gelesen (aktiver-Marker-Highlight),
// deshalb exportiert statt rein privat.
export let pvPhotos = [];
export let pvIndex = 0;
export let pvOpen = false;

function makeThumbnailBlob(fileOrBlob, maxSize = 240, quality = 0.7) {
    return new Promise((resolve, reject) => {
        const url = URL.createObjectURL(fileOrBlob);
        const img = new Image();
        img.onload = () => {
            let w = img.width, h = img.height;
            if (w > h) { if (w > maxSize) { h *= maxSize / w; w = maxSize; } }
            else { if (h > maxSize) { w *= maxSize / h; h = maxSize; } }
            const canvas = document.createElement('canvas');
            canvas.width = Math.round(w); canvas.height = Math.round(h);
            canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
            URL.revokeObjectURL(url);
            canvas.toBlob(b => b ? resolve(b) : reject(new Error('Thumbnail fehlgeschlagen')), 'image/jpeg', quality);
        };
        img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Bild nicht lesbar')); };
        img.src = url;
    });
}

async function processAndUploadImage(fileOrBlob, fileName, st, sidecarMeta, onStatus) {
    let lat = st.lat;
    let lng = st.lng;
    let timestamp = new Date().toISOString();
    let geoSource = 'fallback';
    let timeSource = 'fallback';

    // Punkt 12a: onStatus() ist der nicht-blockierende Upload-Fortschritt
    // (media.js-Aufrufer), Fallback auf den alten Vollbild-Loader für
    // Aufrufer, die (noch) keinen Status-Callback übergeben.
    const status = onStatus || (text => toggleLoader(true, text));
    status(`Lese Metadaten: ${fileName}...`);

    try {
        const exifPromise = exifr.parse(fileOrBlob, { gps: true, pick: ['GPSLatitude', 'GPSLongitude', 'DateTimeOriginal', 'CreateDate'] });
        const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 6000));
        const exifData = await Promise.race([exifPromise, timeoutPromise]);

        console.log('EXIF für', fileName, ':', exifData);

        if (exifData && typeof exifData.latitude === 'number' && typeof exifData.longitude === 'number' && !isNaN(exifData.latitude) && !isNaN(exifData.longitude)) {
            lat = exifData.latitude;
            lng = exifData.longitude;
            geoSource = 'exif';
        }
        const dateVal = exifData && (exifData.DateTimeOriginal || exifData.CreateDate);
        if (dateVal instanceof Date && !isNaN(dateVal)) {
            // Bugfix 0.2: EXIF-Zeitstempel haben KEINE Zeitzonen-Info - es ist
            // nur "11.08. 23:45" ohne Angabe, wo. exifr baut daraus intern ein
            // Date-Objekt über den lokalen Konstruktor (new Date(y,m,d,h,i,s)),
            // d.h. die lokalen Getter liefern uns exakt die rohen EXIF-Zahlen
            // zurück. Wir speichern sie als "floatenden" Zeitstempel OHNE 'Z'/
            // Offset. So bleibt der Kalendertag stabil, egal in welcher Zeit-
            // zone das Tagebuch später betrachtet wird (vorher: Umrechnung via
            // getTimezoneOffset() beim Anzeigen verschob Fotos auf den
            // Vor-/Folgetag, sobald Betrachter- und Aufnahme-Zeitzone
            // auseinanderfielen).
            const pad = n => String(n).padStart(2, '0');
            timestamp = `${dateVal.getFullYear()}-${pad(dateVal.getMonth() + 1)}-${pad(dateVal.getDate())}T${pad(dateVal.getHours())}:${pad(dateVal.getMinutes())}:${pad(dateVal.getSeconds())}`;
            timeSource = 'exif';
        }
    } catch(err) {
        console.warn('EXIF-Auslesen fehlgeschlagen für', fileName, err);
    }

    // Google-Takeout-Begleitdatei (.json) auswerten, falls vorhanden. Punkt 12b:
    // derselbe sidecarMeta-Mechanismus wird auch für live erfasste Kamera-GPS-
    // Position genutzt (sidecarMeta.isLive === true), da EXIF-GPS bei Android
    // idR. zensiert ist (siehe Upload-Hinweistext) - ohne diesen Weg hätten
    // direkt in der App aufgenommene Fotos gar keinen präzisen Standort.
    if (sidecarMeta) {
        if (geoSource !== 'exif' && sidecarMeta.lat != null && sidecarMeta.lng != null) {
            lat = sidecarMeta.lat;
            lng = sidecarMeta.lng;
            geoSource = sidecarMeta.isLive ? 'live' : 'takeout';
            console.log(sidecarMeta.isLive ? 'Live-GPS bei Aufnahme übernommen für' : 'Standort aus Google-Takeout-Datei übernommen für', fileName);
        }
        if (timeSource !== 'exif' && sidecarMeta.timestamp) {
            timestamp = sidecarMeta.timestamp;
            timeSource = sidecarMeta.isLive ? 'live' : 'takeout';
        }
    }

    // Wenn immer noch kein Standort: passenden Punkt aus dem Standort-Verlauf suchen
    if (geoSource === 'fallback') {
        const match = findTrackLocation(timestamp);
        if (match) {
            lat = match.lat;
            lng = match.lng;
            geoSource = 'track';
            console.log(`Standort aus Verlauf zugeordnet (${match.diffMinutes} Min. Abweichung) für`, fileName);
        }
    }

    status(`Lade hoch: ${fileName}...`);
    const safeName = fileName.replace(/[^a-zA-Z0-9.\-_]/g, '_');
    const stamp = Date.now();
    const storagePath = `trips/${S.tripId}/${st.id}/${stamp}_${safeName}`;
    const fileRef = storageRef(S.storage, storagePath);
    await uploadBytes(fileRef, fileOrBlob, { contentType: fileOrBlob.type || 'image/jpeg' });
    const downloadUrl = await getDownloadURL(fileRef);

    // Vorschaubild erzeugen und hochladen (macht Karte & Galerie schnell)
    let thumbUrl = null, thumbPath = null;
    try {
        const thumbBlob = await makeThumbnailBlob(fileOrBlob);
        thumbPath = `trips/${S.tripId}/${st.id}/thumbs/${stamp}_${safeName}.jpg`;
        const thumbRef = storageRef(S.storage, thumbPath);
        await uploadBytes(thumbRef, thumbBlob, { contentType: 'image/jpeg' });
        thumbUrl = await getDownloadURL(thumbRef);
    } catch (e) {
        console.warn('Vorschaubild konnte nicht erstellt werden für', fileName, e);
        thumbPath = null;
    }

    st.images.push({
        url: downloadUrl,
        storagePath: storagePath,
        thumbUrl: thumbUrl,
        thumbPath: thumbPath,
        lat: lat,
        lng: lng,
        timestamp: timestamp,
        geoSource: geoSource,
        timeSource: timeSource
    });

    return geoSource;
}

async function processZipArchive(zipFile, st, tracker) {
    tracker.setLabel(`Entpacke ${zipFile.name}...`);
    const zip = await JSZip.loadAsync(zipFile);

    const imageEntries = [];
    const sidecars = {};

    zip.forEach((path, entry) => {
        if (entry.dir) return;
        const base = path.split('/').pop();
        if (!base || base.startsWith('.') || base.startsWith('__MACOSX')) return;
        if (/\.(jpe?g|png|heic|heif|webp)$/i.test(base)) {
            imageEntries.push({ path, base, entry });
        } else if (/\.json$/i.test(base)) {
            sidecars[base] = entry;
        }
    });

    if (!imageEntries.length) {
        showToast('Im ZIP-Archiv wurden keine Bilder gefunden.', 'info');
        return { total: 0, withGeo: 0 };
    }

    // Punkt 12a: Jetzt, wo die tatsächliche Bilderzahl im ZIP bekannt ist,
    // die Gesamt-Fortschrittsanzeige um diese Zahl erweitern (minus den
    // 1 Platzhalter-Slot, den die ZIP-Datei selbst im äußeren Zähler belegt).
    tracker.addToTotal(imageEntries.length - 1);

    // Google-Takeout-Begleitdateien einlesen (z.B. "IMG_1234.jpg.supplemental-metadata.json")
    const metaByImage = {};
    for (const [name, entry] of Object.entries(sidecars)) {
        try {
            const raw = JSON.parse(await entry.async('string'));
            const geo = raw.geoData || raw.geoDataExif || {};
            const meta = {
                lat: (geo.latitude && geo.latitude !== 0) ? geo.latitude : null,
                lng: (geo.longitude && geo.longitude !== 0) ? geo.longitude : null,
                timestamp: raw.photoTakenTime && raw.photoTakenTime.timestamp
                    ? new Date(parseInt(raw.photoTakenTime.timestamp, 10) * 1000).toISOString()
                    : null
            };
            const key = (raw.title || name.replace(/\.json$/i, '').replace(/\.supplemental-metadata$/i, '')).toLowerCase();
            metaByImage[key] = meta;
        } catch(e) {
            console.warn('Begleitdatei nicht lesbar:', name, e);
        }
    }

    let done = 0, withGeo = 0;
    for (const item of imageEntries) {
        done++;
        try {
            const blob = await item.entry.async('blob');
            const sidecar = metaByImage[item.base.toLowerCase()] || null;
            const source = await processAndUploadImage(blob, item.base, st, sidecar,
                text => tracker.setLabel(`${text} (Archiv ${zipFile.name})`));
            if (source === 'exif' || source === 'takeout') withGeo++;
        } catch(err) {
            console.error('Fehler bei', item.base, err);
        }
        tracker.advance(`Foto ${done}/${imageEntries.length}: ${item.base}`);
    }
    return { total: imageEntries.length, withGeo };
}

/**
 * Bugfix ("wenn ich ein Bild angewählt habe ist es gleich hochgeladen worden,
 * ich konnte nicht mehr weitere anwählen"): der native Datei-Dialog schloss
 * sich nach der Auswahl und der Upload lief sofort los, ohne dass klar war,
 * dass man den Button erneut antippen kann. Fix: Auswahl und Upload werden
 * jetzt getrennt. Ausgewählte Dateien landen zunächst in einer sichtbaren
 * Warteschlange (uploadQueue) - der Button kann beliebig oft erneut
 * angetippt werden, um weitere Dateien hinzuzufügen, bevor der eigentliche
 * Upload per explizitem "Hochladen"-Button gestartet wird.
 */
let uploadQueue = [];

function renderUploadQueue() {
    const box = document.getElementById('upload-queue-box');
    const list = document.getElementById('upload-queue-list');
    const countEl = document.getElementById('upload-queue-count');
    if (!box || !list || !countEl) return;

    if (!uploadQueue.length) {
        box.classList.add('hidden');
        list.innerHTML = '';
        return;
    }
    box.classList.remove('hidden');
    countEl.innerText = uploadQueue.length;
    list.innerHTML = uploadQueue.map((f, i) => `
        <div class="upload-queue-item">
            <i class="fa-solid ${/\.zip$/i.test(f.name) ? 'fa-file-zipper' : 'fa-image'}"></i>
            <span class="upload-queue-item-name">${f.name}</span>
            <button onclick="window.removeFromUploadQueue(${i})" class="upload-queue-item-remove"><i class="fa-solid fa-xmark"></i></button>
        </div>`).join('');
}

window.handleImageSelect = function(event) {
    if (!S.isAdmin) return;
    const newFiles = Array.from(event.target.files);
    if (!newFiles.length) return;
    // Duplikate (Name+Größe) nicht doppelt in die Queue nehmen, falls jemand
    // dieselbe Datei versehentlich zweimal auswählt.
    newFiles.forEach(f => {
        if (!uploadQueue.some(q => q.name === f.name && q.size === f.size)) uploadQueue.push(f);
    });
    renderUploadQueue();
    event.target.value = '';   // Dialog-Reset, damit dieselbe Datei bei Bedarf erneut auswählbar ist
};

window.removeFromUploadQueue = function(i) {
    uploadQueue.splice(i, 1);
    renderUploadQueue();
};

window.clearUploadQueue = function() {
    uploadQueue = [];
    renderUploadQueue();
};

window.confirmUploadQueue = async function() {
    if (!S.isAdmin || !uploadQueue.length || !S.currentStationId) return;
    const files = uploadQueue;
    uploadQueue = [];
    renderUploadQueue();
    await uploadFiles(files);
};

async function uploadFiles(files) {
    if (!S.currentStationId) return;
    const st = S.stations.find(s => s.id === S.currentStationId);
    if (!st.images) st.images = [];

    if (!S.storage) {
        showToast("Cloud-Speicher nicht verfügbar (keine Verbindung zu Firebase Storage). Bitte Internetverbindung prüfen.", 'error');
        return;
    }

    let zipTotal = 0, zipWithGeo = 0;

    // Punkt 12a: geteilter, nicht-blockierender Fortschritts-Tracker über
    // den ganzen Batch (kann Einzelbilder + ZIP-Archive gemischt enthalten).
    // total startet als "1 Slot pro ausgewählter Datei" und wächst, sobald
    // ein ZIP entpackt ist und seine tatsächliche Bilderzahl bekannt ist.
    let completed = 0;
    let total = files.length;
    showUploadProgress(total);
    const tracker = {
        setLabel: (text) => updateUploadProgress(completed, total, text),
        addToTotal: (n) => { total += n; updateUploadProgress(completed, total, ''); },
        advance: (text) => { completed++; updateUploadProgress(completed, total, text); }
    };

    for (const file of files) {
        try {
            if (/\.zip$/i.test(file.name) || file.type === 'application/zip') {
                const res = await processZipArchive(file, st, tracker);
                zipTotal += res.total;
                zipWithGeo += res.withGeo;
            } else {
                await processAndUploadImage(file, file.name, st, null,
                    text => tracker.setLabel(text));
                tracker.advance(`Foto hochgeladen: ${file.name}`);
            }
        } catch (err) {
            console.error('Verarbeitung fehlgeschlagen für', file.name, err);
            showToast(`"${file.name}" konnte nicht verarbeitet werden: ${err.message}`, 'error');
            tracker.advance(file.name);
        }
    }

    saveStationToCloud(st);
    renderMap();
    updateSidePanel(st.id);
    hideUploadProgress();

    if (zipTotal > 0) {
        showToast(`${zipTotal} Foto(s) importiert (${zipWithGeo} mit Original-Geodaten).`, 'success');
    } else {
        showToast(`${files.length} Foto(s) hochgeladen.`, 'success');
    }
}


/**
 * Punkt 12b: Foto direkt in der App aufnehmen (native Kamera via
 * capture="environment" auf dem <input type="file">) statt nur Hochladen
 * bereits existierender Dateien. Erfasst zusätzlich den LIVE-GPS-Standort
 * im Moment der Aufnahme und reicht ihn als sidecarMeta durch denselben
 * Mechanismus wie Google-Takeout-Daten (siehe processAndUploadImage) -
 * notwendig, weil Android GPS-EXIF bei einzeln geteilten/aufgenommenen
 * Fotos idR. entfernt (siehe Upload-Hinweistext im Side Panel).
 *
 * Kein eigener getUserMedia()-Kamera-Stream: der native Datei-Input mit
 * capture-Attribut ist zuverlässiger über iOS/Android/Browser hinweg,
 * braucht keine eigene Kamera-UI/Berechtigungs-Logik und liefert am Ende
 * dieselbe Foto-Datei, die exakt denselben EXIF-Verarbeitungspfad wie ein
 * normaler Upload durchläuft.
 */
window.handleCameraCapture = async function(event) {
    if (!S.isAdmin) return;
    const files = Array.from(event.target.files);
    if (!files.length || !S.currentStationId) return;
    const st = S.stations.find(s => s.id === S.currentStationId);
    if (!st.images) st.images = [];

    if (!S.storage) {
        showToast("Cloud-Speicher nicht verfügbar (keine Verbindung zu Firebase Storage). Bitte Internetverbindung prüfen.", 'error');
        return;
    }

    showUploadProgress(files.length);
    updateUploadProgress(0, files.length, 'Standort wird ermittelt...');

    // Live-Standort EINMAL für den ganzen Aufnahme-Batch abfragen (bei
    // Serienaufnahmen unrealistisch, für jedes Einzelbild erneut zu fragen -
    // Nutzer steht in der Praxis ohnehin am selben Fleck).
    let livePos = null;
    if (navigator.geolocation) {
        try {
            livePos = await new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(
                    pos => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
                    reject,
                    { enableHighAccuracy: true, timeout: 8000, maximumAge: 30000 }
                );
            });
        } catch (e) {
            console.warn('Live-GPS bei Kamera-Aufnahme nicht verfügbar:', e.message);
            // Kein harter Fehler: processAndUploadImage fällt in diesem Fall
            // automatisch auf EXIF/Standort-Verlauf/Stations-Position zurück
            // (dieselbe Kette wie bei einem normalen Datei-Upload).
        }
    }

    let done = 0;
    for (const file of files) {
        try {
            const sidecar = livePos ? { lat: livePos.lat, lng: livePos.lng, isLive: true } : null;
            await processAndUploadImage(file, file.name || `Kamera_${Date.now()}.jpg`, st, sidecar,
                text => updateUploadProgress(done, files.length, text));
        } catch (err) {
            console.error('Kamera-Foto konnte nicht verarbeitet werden:', file.name, err);
            showToast(`Foto konnte nicht verarbeitet werden: ${err.message}`, 'error');
        }
        done++;
        updateUploadProgress(done, files.length, 'Foto verarbeitet');
    }

    saveStationToCloud(st);
    renderMap();
    updateSidePanel(st.id);
    hideUploadProgress();
    showToast(livePos ? `${files.length} Foto(s) mit Live-Standort gespeichert.` : `${files.length} Foto(s) gespeichert (Standort geschätzt).`, 'success');

    document.getElementById('sp-camera-capture').value = '';
};

/**
 * Startbildschirm-Feature: Foto direkt von der Karten-Toolbar aus hinzufügen,
 * OHNE vorher eine Station im Side Panel öffnen zu müssen (Nutzer-Idee: "Bilder
 * direkt aus der App heraus vom Startbildschirm als neues Feature - kann damit
 * das Geotagging-Problem evtl. auch direkt umgangen werden? Speichern dann
 * einfach anhand der Geodaten zur nächstgelegenen Station").
 *
 * Ablauf: Live-GPS EINMAL abfragen -> nächstgelegene Station per Luftlinie
 * bestimmen -> Fotos an DIESE Station hängen, mit dem Live-GPS als sidecarMeta
 * (identischer Mechanismus wie handleCameraCapture). Ohne GPS-Berechtigung
 * kein sinnvoller "nächstgelegene Station"-Bezug möglich - dann Abbruch mit
 * Hinweis, statt zu raten.
 */
window.handleGlobalPhotoCapture = async function(event) {
    if (!S.isAdmin) return;
    const files = Array.from(event.target.files);
    if (!files.length) return;
    if (!S.stations.length) {
        showToast('Es gibt noch keine Stationen, denen ein Foto zugeordnet werden könnte.', 'info');
        return;
    }
    if (!S.storage) {
        showToast("Cloud-Speicher nicht verfügbar (keine Verbindung zu Firebase Storage). Bitte Internetverbindung prüfen.", 'error');
        return;
    }

    showUploadProgress(files.length);
    updateUploadProgress(0, files.length, 'Standort wird ermittelt...');

    let livePos = null;
    if (navigator.geolocation) {
        try {
            livePos = await new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(
                    pos => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
                    reject,
                    { enableHighAccuracy: true, timeout: 8000, maximumAge: 30000 }
                );
            });
        } catch (e) {
            console.warn('Live-GPS beim Startbildschirm-Foto nicht verfügbar:', e.message);
        }
    }

    if (!livePos) {
        hideUploadProgress();
        showToast('Standort konnte nicht ermittelt werden - bitte Standortzugriff erlauben oder das Foto direkt bei der gewünschten Station hochladen.', 'error');
        document.getElementById('global-photo-add').value = '';
        return;
    }

    const nearest = S.stations.reduce((best, st) => {
        const d = distanceKm(livePos.lat, livePos.lng, st.lat, st.lng);
        return (!best || d < best.d) ? { st, d } : best;
    }, null);
    const st = nearest.st;
    if (!st.images) st.images = [];

    let done = 0;
    for (const file of files) {
        try {
            const sidecar = { lat: livePos.lat, lng: livePos.lng, isLive: true };
            await processAndUploadImage(file, file.name || `Foto_${Date.now()}.jpg`, st, sidecar,
                text => updateUploadProgress(done, files.length, text));
        } catch (err) {
            console.error('Foto konnte nicht verarbeitet werden:', file.name, err);
            showToast(`Foto konnte nicht verarbeitet werden: ${err.message}`, 'error');
        }
        done++;
        updateUploadProgress(done, files.length, 'Foto verarbeitet');
    }

    saveStationToCloud(st);
    renderMap();
    if (S.currentStationId === st.id) updateSidePanel(st.id);
    hideUploadProgress();
    showToast(`${files.length} Foto(s) zu "${st.name}" hinzugefügt (${Math.round(nearest.d)} km entfernt).`, 'success');

    document.getElementById('global-photo-add').value = '';
};

export function renderImageGrid(st) {
    const grid = document.getElementById('sp-image-grid');
    const counter = document.getElementById('sp-photo-count');
    const n = (st.images || []).length;
    if (counter) counter.innerText = n ? `${n} Foto${n === 1 ? '' : 's'}` : '';
    if(!st.images || st.images.length === 0) {
        grid.innerHTML = `<div class="col-span-3 text-center text-slate-300 py-5 text-xs"><i class="fa-solid fa-camera-retro text-xl mb-1 block"></i>Noch keine Fotos</div>`;
        return;
    }
    grid.innerHTML = st.images.map((img, i) => {
        const src = resolvePhotoSrc(img);
        if (!src) console.warn('Kein Bildpfad auflösbar für Foto', i, 'in Station', st.name, img);
        const imgTag = src
            ? `<img src="${src}" loading="lazy" decoding="async" onerror="this.onerror=null; this.closest('.relative').classList.add('photo-broken');" class="w-full h-full object-cover group-hover:scale-105 transition">`
            : `<div class="w-full h-full flex flex-col items-center justify-center text-slate-300 bg-slate-50"><i class="fa-solid fa-image-slash text-lg mb-1"></i><span class="text-[9px]">Kein Bild</span></div>`;
        return `
        <div class="relative aspect-square rounded overflow-hidden border border-slate-200 group cursor-pointer" onclick="window.openStationPhoto('${st.id}', ${i})">
            ${imgTag}
            ${img.geoSource === 'fallback' ? `<div class="absolute bottom-1 left-1 bg-amber-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1" title="Kein Standort ermittelt - Stations-Position verwendet. Zum Korrigieren auf den Stift tippen."><i class="fa-solid fa-triangle-exclamation"></i></div>` : ''}
            ${img.geoSource === 'track' ? `<div class="absolute bottom-1 left-1 bg-emerald-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1" title="Standort automatisch aus der Standort-Aufzeichnung zugeordnet"><i class="fa-solid fa-satellite-dish"></i></div>` : ''}
            ${img.geoSource === 'takeout' ? `<div class="absolute bottom-1 left-1 bg-blue-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1" title="Standort aus Google-Takeout-Daten übernommen"><i class="fa-solid fa-file-arrow-down"></i></div>` : ''}
            ${img.geoSource === 'live' ? `<div class="absolute bottom-1 left-1 bg-purple-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1" title="Standort live bei der Aufnahme in der App erfasst"><i class="fa-solid fa-location-crosshairs"></i></div>` : ''}
            ${S.isAdmin ? `<button onclick="event.stopPropagation(); window.openPhotoEditModal(${i})" class="absolute top-1 left-1 bg-indigo-600 text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px] opacity-0 group-hover:opacity-100" title="Ort/Zeit korrigieren"><i class="fa-solid fa-pen"></i></button>` : ''}
            ${S.isAdmin ? `<button onclick="event.stopPropagation(); window.deleteImage(${i})" class="absolute top-1 right-1 bg-red-500 text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px] opacity-0 group-hover:opacity-100"><i class="fa-solid fa-xmark"></i></button>` : ''}
        </div>`;
    }).join('');
}

function setPhotoEditMarker(lat, lng) {
    document.getElementById('pe-lat').value = Number(lat).toFixed(6);
    document.getElementById('pe-lng').value = Number(lng).toFixed(6);
    if (peMap) {
        if (peMarker) peMarker.setLatLng([lat, lng]);
        else peMarker = L.marker([lat, lng], { draggable: true }).addTo(peMap).on('dragend', e => {
            const p = e.target.getLatLng();
            document.getElementById('pe-lat').value = p.lat.toFixed(6);
            document.getElementById('pe-lng').value = p.lng.toFixed(6);
        });
        peMap.setView([lat, lng], Math.max(peMap.getZoom() || 0, 13));
    }
}

window.openPhotoEditModal = function(i) {
    if(!S.isAdmin || !S.currentStationId) return;
    const st = S.stations.find(s => s.id === S.currentStationId);
    const img = st.images[i];
    editingPhotoIndex = i;

    const dt = img.timestamp ? new Date(img.timestamp) : new Date();
    const localVal = new Date(dt.getTime() - dt.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    document.getElementById('pe-datetime').value = localVal;
    document.getElementById('pe-lat').value = img.lat;
    document.getElementById('pe-lng').value = img.lng;

    document.getElementById('photo-edit-modal').classList.remove('hidden');
    document.getElementById('photo-edit-modal').classList.add('flex');

    setTimeout(() => {
        if (!peMap) {
            peMap = L.map('pe-map').setView([img.lat, img.lng], 13);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(peMap);
            peMap.on('click', e => setPhotoEditMarker(e.latlng.lat, e.latlng.lng));
        }
        peMap.invalidateSize();
        setPhotoEditMarker(img.lat, img.lng);
    }, 150);
};

window.closePhotoEditModal = function() {
    document.getElementById('photo-edit-modal').classList.add('hidden');
    document.getElementById('photo-edit-modal').classList.remove('flex');
    editingPhotoIndex = null;
};

window.usePhotoEditGeolocation = function() {
    if(!navigator.geolocation) return showToast('Standortabfrage wird von diesem Browser nicht unterstützt.', 'error');
    navigator.geolocation.getCurrentPosition(
        pos => setPhotoEditMarker(pos.coords.latitude, pos.coords.longitude),
        err => showToast('Aktueller Standort konnte nicht ermittelt werden: ' + err.message, 'error')
    );
};

window.savePhotoEdit = function() {
    if(editingPhotoIndex === null || !S.currentStationId) return;
    const st = S.stations.find(s => s.id === S.currentStationId);
    const img = st.images[editingPhotoIndex];

    const dtVal = document.getElementById('pe-datetime').value;
    const latVal = parseFloat(document.getElementById('pe-lat').value);
    const lngVal = parseFloat(document.getElementById('pe-lng').value);

    if (dtVal) { img.timestamp = new Date(dtVal).toISOString(); img.timeSource = 'manual'; }
    if (!isNaN(latVal) && !isNaN(lngVal)) { img.lat = latVal; img.lng = lngVal; img.geoSource = 'manual'; }

    saveStationToCloud(st);
    renderImageGrid(st);
    renderMap();
    window.closePhotoEditModal();
};

window.openPhotoViewer = function(index, photoList) {
    pvPhotos = photoList || getAllPhotosChronological();
    if (!pvPhotos.length) return;
    pvIndex = Math.max(0, Math.min(index, pvPhotos.length - 1));
    pvOpen = true;
    renderPhotoViewer();
    const m = document.getElementById('photo-viewer-modal');
    m.classList.remove('hidden');
    m.classList.add('flex');
    focusPhotoOnMap();
};

function preloadAround(index, span = 2) {
    for (let d = -span; d <= span; d++) {
        const p = pvPhotos[index + d];
        if (!p) continue;
        const src = p.img.url || p.img.data;
        if (!src || preloadCache.has(src)) continue;
        const im = new Image();
        im.decoding = 'async';
        im.src = src;
        preloadCache.set(src, im);
        if (preloadCache.size > 40) {
            const oldest = preloadCache.keys().next().value;
            preloadCache.delete(oldest);
        }
    }
}

function focusPhotoOnMap() {
    const p = pvPhotos[pvIndex];
    if (!p || !S.map) return;
    const targetZoom = Math.max(S.map.getZoom(), 11);
    S.map.setView([p.img.lat, p.img.lng], targetZoom, { animate: true, duration: 0.6 });
    setTimeout(renderPhotoMarkers, 250);
}

function renderPhotoViewer() {
    const p = pvPhotos[pvIndex];
    if (!p) return;

    const full = p.img.url || p.img.data;
    const thumb = p.img.thumbUrl;
    const imgEl = document.getElementById('pv-img');

    // Sofort das (kleine) Vorschaubild zeigen, dann still auf das Original wechseln
    const cached = preloadCache.get(full);
    if (cached && cached.complete) {
        imgEl.src = full;
        imgEl.classList.remove('pv-loading');
    } else {
        imgEl.src = thumb || full;
        imgEl.classList.add('pv-loading');
        const hi = new Image();
        hi.onload = () => {
            if (pvPhotos[pvIndex] && (pvPhotos[pvIndex].img.url || pvPhotos[pvIndex].img.data) === full) {
                imgEl.src = full;
                imgEl.classList.remove('pv-loading');
            }
        };
        hi.src = full;
        preloadCache.set(full, hi);
    }

    preloadAround(pvIndex);
    const allDays = getTravelDays(getAllPhotosChronological());
    const dIdx = allDays.indexOf(dayKey(p.img.timestamp));
    const dayTxt = dIdx >= 0 ? ` · Reisetag ${dIdx + 1}` : '';
    document.getElementById('pv-counter').innerText = `Foto ${pvIndex + 1} von ${pvPhotos.length}${dayTxt}`;
    document.getElementById('pv-station').innerText = p.station.name;

    const ts = p.img.timestamp
        ? new Date(p.img.timestamp).toLocaleString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })
        : 'Kein Zeitstempel';

    const srcLabel = {
        exif: 'Originalstandort aus Foto',
        takeout: 'Originalstandort aus Google-Daten',
        track: 'Standort aus Aufzeichnung',
        manual: 'Standort manuell gesetzt',
        live: 'Live-Standort bei Aufnahme',
        fallback: 'Standort geschätzt (Station)'
    }[p.img.geoSource] || 'Standort unbekannt';

    const dist = distanceKm(p.station.lat, p.station.lng, p.img.lat, p.img.lng);
    document.getElementById('pv-meta').innerHTML =
        `${ts}<br>${p.img.lat.toFixed(4)}, ${p.img.lng.toFixed(4)} &middot; ${dist < 1 ? '<1' : Math.round(dist)} km von ${p.station.name}<br><span class="text-white/40">${srcLabel}</span>`;

    document.getElementById('pv-prev').disabled = pvIndex === 0;
    document.getElementById('pv-next').disabled = pvIndex === pvPhotos.length - 1;
    document.getElementById('pv-prev').style.opacity = pvIndex === 0 ? '0.35' : '1';
    document.getElementById('pv-next').style.opacity = pvIndex === pvPhotos.length - 1 ? '0.35' : '1';
}

window.photoViewerStep = function(dir) {
    const next = pvIndex + dir;
    if (next < 0 || next >= pvPhotos.length) return;
    pvIndex = next;
    renderPhotoViewer();
    focusPhotoOnMap();
};

window.togglePhotoFullscreen = function() {
    const m = document.getElementById('photo-viewer-modal');
    const on = m.classList.toggle('pv-full');
    const icon = document.querySelector('#pv-fs i');
    if (icon) icon.className = on ? 'fa-solid fa-compress text-xs' : 'fa-solid fa-expand text-xs';
    // Im Vollbild darf die ganze Fläche Wischgesten annehmen
    m.classList.toggle('pointer-events-none', !on);
};

window.closePhotoViewer = function() {
    const m = document.getElementById('photo-viewer-modal');
    m.classList.add('hidden');
    m.classList.remove('flex', 'pv-full');
    m.classList.add('pointer-events-none');
    const icon = document.querySelector('#pv-fs i');
    if (icon) icon.className = 'fa-solid fa-expand text-xs';
    pvOpen = false;
    renderPhotoMarkers();
};

window.deletePhotoFromViewer = function() {
    if (!S.isAdmin) return;
    const p = pvPhotos[pvIndex];
    if (!p) return;
    if (!confirm('Dieses Foto wirklich löschen?')) return;

    const st = p.station;
    const realIdx = st.images.findIndex(x => x === p.img);
    if (realIdx === -1) return;
    const img = st.images[realIdx];

    if (S.storage) {
        if (img.storagePath) deleteObject(storageRef(S.storage, img.storagePath)).catch(err => console.warn('Storage-Löschung:', err));
        if (img.thumbPath) deleteObject(storageRef(S.storage, img.thumbPath)).catch(() => {});
    }
    st.images.splice(realIdx, 1);
    saveStationToCloud(st);
    renderMap();
    if (S.currentStationId === st.id) updateSidePanel(st.id);

    pvPhotos = getAllPhotosChronological();
    if (!pvPhotos.length) return window.closePhotoViewer();
    pvIndex = Math.min(pvIndex, pvPhotos.length - 1);
    renderPhotoViewer();
};

window.editPhotoFromViewer = function() {
    if (!S.isAdmin) return;
    const p = pvPhotos[pvIndex];
    if (!p) return;
    const realIdx = p.station.images.findIndex(x => x === p.img);
    if (realIdx === -1) return;
    S.currentStationId = p.station.id;
    window.closePhotoViewer();
    window.openPhotoEditModal(realIdx);
};

window.openLightbox = function(imgSrc, caption) {
    document.getElementById('lightbox-img').src = imgSrc;
    document.getElementById('lightbox-caption').innerText = caption;
    document.getElementById('lightbox-modal').classList.remove('hidden');
    document.getElementById('lightbox-modal').classList.add('flex');
};

window.closeLightbox = function() {
    document.getElementById('lightbox-modal').classList.add('hidden');
    document.getElementById('lightbox-modal').classList.remove('flex');
};

window.openGlobalGallery = function() {
    const content = document.getElementById('global-gallery-content');
    const all = getAllPhotosChronological();

    // Auch Fotos ohne Koordinaten aufnehmen
    const extra = [];
    S.stations.forEach(st => (st.images || []).forEach(img => {
        if (!(img.lat && img.lng)) extra.push({ img, station: st });
    }));
    const list = all.concat(extra);

    document.getElementById('gallery-subtitle').innerText =
        list.length ? `${list.length} Fotos · chronologisch` : '';

    if (!list.length) {
        content.innerHTML = `<div class="col-span-full text-center text-slate-400 py-16">
            <i class="fa-solid fa-camera-retro text-4xl mb-3"></i>
            <p class="font-bold">Noch keine Fotos vorhanden.</p>
            <p class="text-xs mt-1">Fotos lassen sich in jeder Station hochladen.</p>
        </div>`;
    } else {
        content.innerHTML = list.map((p, i) => {
            const src = resolvePhotoSrc(p.img);
            if (!src) console.warn('Kein Bildpfad auflösbar für Foto', i, 'in Station', p.station.name, p.img);
            const ts = p.img.timestamp
                ? new Date(p.img.timestamp).toLocaleDateString('de-DE', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
                : '—';
            const fullSrc = resolvePhotoSrc(p.img, false);
            const imgTag = src
                ? `<img src="${src}" ${i < 12 ? '' : 'loading="lazy"'} decoding="async"
                             onerror="this.onerror=null; ${fullSrc && fullSrc !== src ? `this.src='${fullSrc}';` : `this.closest('.aspect-square').classList.add('photo-broken');`}"
                             class="w-full h-full object-cover group-hover:scale-105 transition duration-300">`
                : `<div class="w-full h-full flex flex-col items-center justify-center text-slate-300"><i class="fa-solid fa-image-slash text-2xl mb-1"></i><span class="text-[10px]">Kein Bild</span></div>`;
            return `
                <div class="flex flex-col bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden group hover:shadow-md transition">
                    <div class="aspect-square relative cursor-pointer overflow-hidden bg-slate-200" onclick="window.openGalleryPhoto(${i})">
                        ${imgTag}
                    </div>
                    <div class="p-2 bg-white">
                        <div class="text-[11px] font-bold text-slate-700 truncate"><i class="fa-solid fa-location-dot text-indigo-500 mr-1"></i>${esc(p.station.name)}</div>
                        <div class="text-[10px] text-slate-400 font-mono">${ts}</div>
                    </div>
                </div>`;
        }).join('');
    }

    galleryPhotoList = list;
    document.getElementById('global-gallery-modal').classList.remove('hidden');
    document.getElementById('global-gallery-modal').classList.add('flex');
};

window.openStationPhoto = function(stationId, indexInStation) {
    const st = S.stations.find(s => s.id === stationId);
    if (!st || !st.images || !st.images[indexInStation]) return;
    const target = st.images[indexInStation];
    const list = getAllPhotosChronological();
    let pos = list.findIndex(p => p.img === target);
    if (pos === -1) {
        // Foto ohne Koordinaten: eigene Liste dieser Station verwenden
        const own = st.images.map(im => ({ img: im, station: st }));
        return window.openPhotoViewer(indexInStation, own);
    }
    window.openPhotoViewer(pos, list);
};

window.openGalleryPhoto = function(i) {
    window.closeGlobalGallery();
    window.openPhotoViewer(i, galleryPhotoList);
};

window.closeGlobalGallery = function() {
    const m = document.getElementById('global-gallery-modal');
    m.classList.add('hidden');
    m.classList.remove('flex');
};

window.downloadAllPhotosZip = async function() {
    const items = [];
    S.stations.forEach(st => (st.images || []).forEach(img => {
        if (img.url || img.data) items.push({ st, img });
    }));

    if (!items.length) return showToast('Keine Fotos zum Herunterladen vorhanden.', 'info');
    if (!confirm(`${items.length} Foto(s) in Originalqualität als ZIP herunterladen?\n\nJe nach Anzahl kann das einige Minuten dauern und größere Datenmengen übertragen.`)) return;

    const zip = new JSZip();
    let ok = 0, failed = 0, firstError = null;
    const usedNames = new Set();

    for (let i = 0; i < items.length; i++) {
        const { st, img } = items[i];
        toggleLoader(true, `Foto ${i + 1}/${items.length} wird geladen...`);
        try {
            let blob;
            if (img.url) {
                const res = await fetch(img.url);
                if (!res.ok) throw new Error('HTTP ' + res.status);
                blob = await res.blob();
            } else {
                const res = await fetch(img.data);
                blob = await res.blob();
            }

            const folder = slugifyName(st.name);
            let fname = photoFileName(img, st.name);
            let key = folder + '/' + fname;
            let n = 2;
            while (usedNames.has(key)) {
                key = `${folder}/${fname.replace(/\.jpg$/, '')}_${n}.jpg`;
                n++;
            }
            usedNames.add(key);
            zip.file(key, blob);
            ok++;
        } catch (e) {
            console.warn('Download fehlgeschlagen:', e);
            if (!firstError) firstError = e.message || String(e);
            failed++;
        }
    }

    if (!ok) {
        toggleLoader(false);
        let msg = `Kein Foto konnte geladen werden.\n\nFehler: ${firstError}`;
        if (/fetch|network|failed|cors/i.test(firstError || '')) {
            msg += `\n\nWahrscheinliche Ursache: CORS ist für den Firebase-Storage-Bucket noch nicht freigegeben.`;
        }
        return alert(msg);
    }

    toggleLoader(true, 'ZIP-Archiv wird erstellt...');
    const content = await zip.generateAsync({ type: 'blob', compression: 'STORE' },
        meta => { if (meta.percent % 10 < 1) toggleLoader(true, `ZIP wird gepackt: ${Math.round(meta.percent)}%`); });

    const url = URL.createObjectURL(content);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${slugifyName(tripTitle())}_Fotos_${new Date().toISOString().slice(0,10)}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);

    toggleLoader(false);
    if (failed) showToast(`ZIP erstellt. Enthalten: ${ok}, fehlgeschlagen: ${failed}.`, 'info');
};

window.deleteImage = function(i) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === S.currentStationId);
    const img = st.images[i];
    if (!img || !confirm('Dieses Foto wirklich löschen?')) return;
    if (S.storage && img) {
        if (img.storagePath) deleteObject(storageRef(S.storage, img.storagePath)).catch(err => console.warn('Storage-Löschung:', err));
        if (img.thumbPath) deleteObject(storageRef(S.storage, img.thumbPath)).catch(() => {});
    }
    st.images.splice(i, 1);
    saveStationToCloud(st);
    renderMap();
    updateSidePanel(st.id);
};
