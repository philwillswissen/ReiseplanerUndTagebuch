/**
 * stations.js – Stationen anlegen/löschen, Side-Panel, Todos, Campingplätze
 */

import { S } from './state.js';
import { esc, toggleLoader, tripTitle, showToast } from './utils.js';
import { fitMapToStations, renderMap } from './map.js';
import { renderImageGrid } from './media.js';
import { renderStayBlock } from './duration.js';
import { renderWeatherStrip } from './weather.js';
import { saveLocal, saveStationToCloud, uploadAllStations, stationDoc, deleteDoc } from './firebase.js';
import { callGemini, parseGeminiJson, getGeminiErrorMessage } from './gemini.js';

window.openAddModal = function() {
    if(!S.isAdmin) return;
    S.selectedSearchResult = null;
    document.getElementById('add-search-input').value = '';
    document.getElementById('search-results').classList.add('hidden');

    const select = document.getElementById('add-position-select');
    select.innerHTML = '';

    if (S.stations.length === 0) {
        const o = document.createElement('option');
        o.value = 0; o.innerText = 'Erste Station der Reise';
        select.appendChild(o);
    } else if (S.stations.length === 1) {
        [[0, 'Vor ' + S.stations[0].name], [1, 'Nach ' + S.stations[0].name]].forEach(([v, l]) => {
            const o = document.createElement('option');
            o.value = v; o.innerText = l; if (v === 1) o.selected = true;
            select.appendChild(o);
        });
    } else {
        for (let i = 1; i < S.stations.length; i++) {
            const opt = document.createElement('option');
            opt.value = i;
            opt.innerText = `Position ${i} (vor ${S.stations[i].name})`;
            select.appendChild(opt);
        }
        const endOpt = document.createElement('option');
        endOpt.value = S.stations.length - 1;
        endOpt.innerText = `Am Ende (vor ${S.stations[S.stations.length-1].name})`;
        endOpt.selected = true;
        select.appendChild(endOpt);
    }

    document.getElementById('add-modal').classList.remove('hidden');
};

window.closeAddModal = function() {
    document.getElementById('add-modal').classList.add('hidden');
};

window.debouncedSearch = function(query) {
    clearTimeout(S.searchTimeout);
    if (!query || query.length < 2) {
        document.getElementById('search-results').classList.add('hidden');
        return;
    }
    S.searchTimeout = setTimeout(async () => {
        try {
            const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5`);
            const data = await res.json();

            const resDiv = document.getElementById('search-results');
            resDiv.innerHTML = '';
            if (data.length === 0) {
                resDiv.innerHTML = '<div class="p-2 text-slate-400">Keine Ergebnisse gefunden</div>';
            } else {
                data.forEach(item => {
                    const row = document.createElement('div');
                    row.className = "p-2 hover:bg-indigo-50 cursor-pointer truncate";
                    row.innerText = item.display_name;
                    row.onclick = () => {
                        S.selectedSearchResult = {
                            name: item.display_name.split(',')[0],
                            lat: parseFloat(item.lat),
                            lng: parseFloat(item.lon)
                        };
                        document.getElementById('add-search-input').value = item.display_name;
                        resDiv.classList.add('hidden');
                    };
                    resDiv.appendChild(row);
                });
            }
            resDiv.classList.remove('hidden');
        } catch(e){}
    }, 300);
};

window.confirmAddStation = async function() {
    if (!S.isAdmin) return;
    if (!S.selectedSearchResult) {
        showToast("Bitte wählen Sie einen Ort aus den Suchvorschlägen aus.", 'info');
        return;
    }

    const cleanName = S.selectedSearchResult.name.replace(/^\d+[\.\-\s]*/, '').trim();
    const targetPos = parseInt(document.getElementById('add-position-select').value);
    const newId = 'st-' + Date.now();

    const newStation = {
        id: newId,
        name: cleanName,
        lat: S.selectedSearchResult.lat,
        lng: S.selectedSearchResult.lng,
        order: targetPos,
        desc: 'Daten werden generiert...',
        activities: [],
        campsites: [],
        todos: [],
        notes: '',
        blogEntry: '',
        images: []
    };

    const pos = isNaN(targetPos) ? S.stations.length : targetPos;
    S.stations.splice(pos, 0, newStation);
    S.stations.forEach((s, idx) => s.order = idx);

    window.closeAddModal();
    renderMap();
    if (S.stations.length <= 2) { S.hasFittedMap = false; fitMapToStations(); }
    uploadAllStations();

    enrichStationDataViaAI(newStation);
};

window.openSidePanel = function(id) {
    S.currentStationId = id;
    updateSidePanel(id);
    document.getElementById('side-panel').classList.add('open');
    const st = S.stations.find(s => s.id === id);
    if(st) S.map.panTo([st.lat, st.lng]);
};

window.closeSidePanel = function() {
    document.getElementById('side-panel').classList.remove('open');
    S.currentStationId = null;
};

export function updateSidePanel(id) {
    const st = S.stations.find(s => s.id === id);
    if(!st) return window.closeSidePanel();

    if (S.currentStationId !== id && window.clearUploadQueue) window.clearUploadQueue();   // Bugfix: Warteschlange gehört zur gerade offenen Station, nicht stationsübergreifend

    const titlePrefix = (st.order > 0 && st.order < S.stations.length - 1) ? `${st.order}. ` : '';
    document.getElementById('sp-title').innerText = `${titlePrefix}${st.name}`;
    document.getElementById('sp-title').dataset.stationId = st.id;
    document.getElementById('sp-desc').innerText = st.desc;

    renderStayBlock(st);
    renderWeatherStrip(st);

    document.getElementById('sp-activities').innerHTML = (st.activities || []).map(a => {
        if (typeof a === 'string') {
            return `<li><i class="fa-solid fa-chevron-right text-indigo-400 mr-2 text-[10px]"></i><span class="font-semibold text-slate-800">${a}</span></li>`;
        }
        const mapsLink = a.googleMapsUrl ? ` <a href="${a.googleMapsUrl}" target="_blank" class="activity-maps-link" title="In Google Maps öffnen"><i class="fa-solid fa-map-location-dot"></i></a>` : '';
        return `<li><i class="fa-solid fa-chevron-right text-indigo-400 mr-2 text-[10px]"></i><span class="font-semibold text-slate-800">${esc(a.name)}</span>${mapsLink}${a.desc ? `<p class="text-xs text-slate-600 ml-5 mt-1 leading-relaxed">${esc(a.desc)}</p>` : ''}</li>`;
    }).join('');

    document.getElementById('sp-campsites').innerHTML = (st.campsites || []).map((c, idx) => `
        <div class="border rounded-lg p-3 shadow-sm transition-all ${c.selected ? 'border-emerald-400 bg-emerald-50 ring-1 ring-emerald-200' : 'border-slate-100 bg-white'}">
            <div class="flex justify-between items-start gap-2">
                <div class="flex-grow">
                    <a href="${c.url || 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(c.name)}" target="_blank" class="font-bold text-sm text-indigo-700 hover:underline flex items-center gap-1">
                        ${c.name} <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                    </a>
                    <div class="text-[10px] text-slate-500 font-mono my-1.5 bg-slate-100 px-1.5 py-0.5 rounded inline-block">${c.tags}</div>
                    <div class="text-xs text-slate-600 leading-relaxed">${c.desc}</div>
                </div>
                <div class="admin-only-flex flex-col gap-1">
                    <button onclick="window.selectCampsite('${st.id}', ${idx})"
                        class="px-2 py-1 text-[10px] font-bold rounded transition-all whitespace-nowrap ${c.selected ? 'bg-emerald-500 text-white hover:bg-emerald-600' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}">
                        <i class="fa-solid ${c.selected ? 'fa-check' : 'fa-check'}"></i> ${c.selected ? 'Gewählt' : 'Wählen'}
                    </button>
                    ${c.custom ? `<button onclick="window.deleteCampsite('${st.id}', ${idx})" class="px-2 py-1 text-[10px] font-bold rounded bg-red-100 text-red-600 hover:bg-red-200 transition-all"><i class="fa-solid fa-trash"></i></button>` : ''}
                </div>
            </div>
        </div>
    `).join('');

    // Formular zum Hinzufügen eines eigenen Campingplatzes
    const customCampsiteHtml = `
        <div class="admin-only border-t border-slate-200 pt-3 mt-3">
            <p class="text-xs font-bold text-slate-600 mb-2 uppercase">Eigener Campingplatz</p>
            <div class="space-y-2">
                <input type="text" id="custom-camp-name" placeholder="Name..." class="w-full border border-slate-200 rounded px-2 py-1.5 text-xs focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-200">
                <input type="url" id="custom-camp-url" placeholder="Google Maps Link (optional)..." class="w-full border border-slate-200 rounded px-2 py-1.5 text-xs focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-200">
                <textarea id="custom-camp-desc" rows="2" placeholder="Notiz..." class="w-full border border-slate-200 rounded px-2 py-1.5 text-xs focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-200"></textarea>
                <button onclick="window.addCustomCampsite('${st.id}')" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-1.5 px-2 rounded text-xs transition-all flex items-center justify-center gap-1">
                    <i class="fa-solid fa-plus"></i> Hinzufügen
                </button>
            </div>
        </div>
    `;
    document.getElementById('sp-campsites').innerHTML += customCampsiteHtml;

    renderTodos(st);

    const taNotes = document.getElementById('sp-notes');
    taNotes.value = st.notes || '';
    taNotes.onblur = () => { if(S.isAdmin) { st.notes = taNotes.value; saveStationToCloud(st); }};

    const taBlog = document.getElementById('sp-blog');
    taBlog.value = st.blogEntry || '';
    const blogRender = document.getElementById('sp-blog-render');
    blogRender.innerHTML = parseMarkdown(st.blogEntry || '');
    taBlog.onblur = () => { st.blogEntry = taBlog.value; blogRender.innerHTML = parseMarkdown(st.blogEntry || ''); saveStationToCloud(st); };

    renderImageGrid(st);
}

export function parseMarkdown(text) {
    if (!text) return '';
    let escaped = text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');

    const lines = escaped.split(/\n/);
    let html = '';
    let paragraphBuffer = [];

    const flushParagraph = () => {
        if (paragraphBuffer.length) {
            html += `<p>${paragraphBuffer.join('<br>')}</p>`;
            paragraphBuffer = [];
        }
    };

    const inlineFormat = (str) => str
        .replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g, '<em>$1</em>');

    lines.forEach(rawLine => {
        const line = rawLine.trim();
        if (line === '' || /^\*{3,}\s*$/.test(line) || /^-{3,}\s*$/.test(line)) {
            flushParagraph();
            return;
        }
        const h3Match = line.match(/^###\s+(.*)$/);
        const h2Match = line.match(/^##\s+(.*)$/);
        if (h3Match) { flushParagraph(); html += `<h3>${inlineFormat(h3Match[1])}</h3>`; return; }
        if (h2Match) { flushParagraph(); html += `<h2>${inlineFormat(h2Match[1])}</h2>`; return; }
        paragraphBuffer.push(inlineFormat(line));
    });
    flushParagraph();
    return html;
}

export function renderTodos(st) {
    const container = document.getElementById('sp-todo-list');
    if(!st.todos || st.todos.length === 0) {
        container.innerHTML = '<div class="text-xs text-slate-400 italic">Keine To-Dos hinterlegt.</div>';
        return;
    }

    container.innerHTML = st.todos.map((t, i) => `
        <div class="flex items-center gap-2 group py-1.5 border-b border-slate-100 last:border-0 bg-white" data-id="${i}">
            ${S.isAdmin ? `<i class="fa-solid fa-grip-vertical text-slate-300 drag-handle cursor-grab active:cursor-grabbing text-lg px-2 hover:text-indigo-400 transition"></i>` : `<i class="fa-solid fa-minus text-slate-300 text-sm px-2"></i>`}
            <input type="checkbox" ${t.done ? 'checked' : ''} ${!S.isAdmin ? 'disabled' : ''} onchange="window.toggleTodo(${i})" class="rounded text-indigo-600 w-4 h-4 ${S.isAdmin ? 'cursor-pointer' : 'cursor-default'}">
            <span class="text-sm flex-grow ${t.done ? 'line-through text-slate-400' : 'text-slate-700'}">${esc(t.text)}</span>
            ${t.googleMapsUrl ? `<a href="${t.googleMapsUrl}" target="_blank" class="text-indigo-400 hover:text-indigo-600 px-1" title="In Google Maps öffnen" onclick="event.stopPropagation()"><i class="fa-solid fa-map-location-dot text-xs"></i></a>` : ''}
            ${S.isAdmin ? `<button onclick="window.editTodo(${i})" class="text-slate-400 hover:text-indigo-600 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition px-2" title="Bearbeiten"><i class="fa-solid fa-pen text-xs"></i></button>
            <button onclick="window.deleteTodo(${i})" class="text-red-400 hover:text-red-600 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition px-2" title="Löschen"><i class="fa-solid fa-trash-can text-xs"></i></button>` : ''}
        </div>
    `).join('');

    if (S.todoSortable) {
        S.todoSortable.destroy();
        S.todoSortable = null;
    }
    if (S.isAdmin) {
        S.todoSortable = Sortable.create(container, {
            handle: '.drag-handle',
            animation: 150,
            onEnd: function (evt) {
                if (evt.oldIndex === evt.newIndex) return;
                const stNode = S.stations.find(s => s.id === S.currentStationId);
                const itemEl = stNode.todos.splice(evt.oldIndex, 1)[0];
                stNode.todos.splice(evt.newIndex, 0, itemEl);
                saveStationToCloud(stNode);
                updateSidePanel(stNode.id);
            }
        });
    }
}

window.addTodo = function() {
    if (!S.isAdmin) return;
    const input = document.getElementById('sp-todo-input');
    const val = input.value.trim();
    if(!val || !S.currentStationId) return;
    const st = S.stations.find(s => s.id === S.currentStationId);
    if(!st.todos) st.todos = [];
    st.todos.push({ text: val, done: false });
    input.value = '';
    saveStationToCloud(st);
    updateSidePanel(st.id);
};

window.editTodo = function(i) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === S.currentStationId);
    if (!st || !st.todos[i]) return;
    const newText = prompt("To-Do bearbeiten:", st.todos[i].text);
    if (newText !== null && newText.trim() !== "") {
        st.todos[i].text = newText.trim();
        saveStationToCloud(st);
        updateSidePanel(st.id);
    }
};

window.toggleTodo = function(i) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === S.currentStationId);
    st.todos[i].done = !st.todos[i].done;
    saveStationToCloud(st);
    updateSidePanel(st.id);
};

window.deleteTodo = function(i) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === S.currentStationId);
    st.todos.splice(i, 1);
    saveStationToCloud(st);
    updateSidePanel(st.id);
};

window.selectCampsite = function(stationId, campsiteIndex) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === stationId);
    if (!st || !st.campsites || !st.campsites[campsiteIndex]) return;

    st.campsites.forEach((c, idx) => {
        c.selected = (idx === campsiteIndex);
    });

    saveStationToCloud(st);
    updateSidePanel(st.id);
};

window.addCustomCampsite = function(stationId) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === stationId);
    if (!st) return;

    const nameInput = document.getElementById('custom-camp-name');
    const urlInput = document.getElementById('custom-camp-url');
    const descInput = document.getElementById('custom-camp-desc');

    const name = nameInput.value.trim();
    if (!name) {
        showToast('Bitte einen Namen eingeben', 'info');
        return;
    }

    const newCampsite = {
        name: name,
        url: urlInput.value.trim() || '',
        tags: 'manuell',
        desc: descInput.value.trim() || '',
        custom: true,
        selected: false
    };

    if (!st.campsites) st.campsites = [];
    st.campsites.push(newCampsite);

    nameInput.value = '';
    urlInput.value = '';
    descInput.value = '';

    saveStationToCloud(st);
    updateSidePanel(st.id);
};

window.deleteCampsite = function(stationId, campsiteIndex) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === stationId);
    if (!st || !st.campsites || !st.campsites[campsiteIndex]) return;

    if (!st.campsites[campsiteIndex].custom) {
        showToast('Nur manuell hinzugefügte Campingplätze können gelöscht werden', 'info');
        return;
    }

    st.campsites.splice(campsiteIndex, 1);
    saveStationToCloud(st);
    updateSidePanel(st.id);
};

window.deleteCurrentStation = async function() {
    if (!S.isAdmin) return;
    if(!S.currentStationId || !confirm("Station wirklich löschen?")) return;
    const id = S.currentStationId;
    const delIdx = S.stations.findIndex(s => s.id === id);
    const deletedStation = S.stations[delIdx];

    const orphanedPois = (deletedStation && deletedStation.segmentFromPrev && deletedStation.segmentFromPrev.pois) || [];
    const nextStation = S.stations[delIdx + 1];
    const prevStation = S.stations[delIdx - 1];
    if (orphanedPois.length) {
        const heir = nextStation || prevStation;
        if (heir) {
            if (!heir.segmentFromPrev) heir.segmentFromPrev = {};
            if (!heir.segmentFromPrev.pois) heir.segmentFromPrev.pois = [];
            heir.segmentFromPrev.pois.push(...orphanedPois);
        }
    }

    S.stations = S.stations.filter(s => s.id !== id);
    S.stations.forEach((s, idx) => s.order = idx);
    window.closeSidePanel();

    saveLocal();
    renderMap();
    if(S.db && S.currentUser) {
        await deleteDoc(stationDoc(S.tripId, id));
        uploadAllStations();
    }
};

export async function enrichStationDataViaAI(station) {
    toggleLoader(true, `Generiere Informationen für ${station.name}...`);
    try {
        if (!S.apiKey || S.apiKey.trim() === "") throw new Error("API Key fehlt in den Einstellungen.");

        const prompt = `Generiere touristische Metadaten für die Station '${station.name}' (Reise: ${tripTitle()}). Antworte ausschließlich im JSON-Format mit den Schlüsseln desc, activities (Array von Objekten mit name und desc), campsites (Array von Objekten mit name, url, tags, desc).`;

        // ✅ BUG-2 FIX: callGemini() mit automatischem Retry bei 429 (Quota)/503 (Overloaded),
        // Exponential Backoff 1s/2s/4s - fängt die meisten kurzfristigen Rate-Limit-Spitzen ab
        const rawText = await callGemini(prompt, {
            onRetry: (attempt, max, delay) => toggleLoader(true, `KI-Dienst ausgelastet – erneuter Versuch ${attempt}/${max}...`)
        });
        const aiData = parseGeminiJson(rawText);

        station.desc = aiData.desc || station.desc;
        station.activities = aiData.activities || [];
        station.campsites = (aiData.campsites || []).map(c => ({
            ...c,
            custom: false,
            selected: false
        }));
        saveStationToCloud(station);

    } catch(e) {
        // ✅ BUG-3 FIX: Das ist genau der gemeldete Bug (Screenshot: rohes JSON
        // "Google API Fehler 429 – You exceeded your current quota..." im Toast).
        // Jetzt: kurze, verständliche deutsche Meldung statt technischem Rohtext.
        console.error('KI-Anreicherung fehlgeschlagen für', station.name, e);
        showToast(getGeminiErrorMessage(e), 'error');

        station.desc = `Zwischenstopp auf der Reise. Beschreibung kann manuell ergänzt oder per KI erzeugt werden.`;
        station.activities = [
            { name: `${station.name} Stadtrundgang & Zentrum`, desc: "Gemütliche Erkundung der historischen Straßenzüge, lokalen Märkte und kinderfreundlichen Parks." },
            { name: `Natur- & Ausflugsziel ${station.name}`, desc: "Familienfreundlicher Rundweg mit Aussichtspunkten und Möglichkeiten zum Picknicken im Grünen." }
        ];
        station.campsites = [
            {
                name: `Camping ${station.name}`,
                url: `https://www.google.com/maps/search/?api=1&query=Camping+${encodeURIComponent(station.name)}`,
                tags: "Familie, Natur, Wohnmobil",
                desc: `Zentral gelegener Campingplatz bei ${station.name} mit moderner Sanitär-Ausstattung, Wohnmobil-Stellplätzen und guter Verkehrsanbindung.`,
                custom: false,
                selected: false
            }
        ];
        saveStationToCloud(station);
    }
    toggleLoader(false);
    if (S.currentStationId === station.id) updateSidePanel(station.id);
}

// ---- Spracheingabe für Notizen ----
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
    S.recognition = new SpeechRecognition();
    S.recognition.continuous = false;
    S.recognition.interimResults = false;
    S.recognition.lang = 'de-DE';
    S.recognition.onresult = async (e) => {
        const text = e.results[0][0].transcript;
        window.toggleAudioRecording();
        const st = S.stations.find(s => s.id === S.currentStationId);
        if(st) {
            st.notes = (st.notes ? st.notes + "\n" : "") + text;
            saveStationToCloud(st);
            updateSidePanel(st.id);
        }
    };
    S.recognition.onerror = () => window.toggleAudioRecording();
}

window.toggleAudioRecording = function() {
    if (!S.isAdmin) return;
    if(!S.recognition) return showToast("Spracherkennung in diesem Browser nicht unterstützt.", 'error');
    const btn = document.getElementById('btn-record-audio');
    if(S.isRecording) { S.recognition.stop(); S.isRecording = false; btn.classList.remove('recording'); }
    else { S.recognition.start(); S.isRecording = true; btn.classList.add('recording'); }
};