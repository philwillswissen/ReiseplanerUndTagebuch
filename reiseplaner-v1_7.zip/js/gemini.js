/**
 * gemini.js – Zentraler Gemini-API-Client mit Retry-Logik & Error-Handling
 * ============================================================================
 * BUG-2 FIX (Quota Exceeded / 429):
 *   Alle 6 Stellen im Code, die bisher direkt `fetch(gemini-url)` aufgerufen
 *   haben (diary.js x2, duration.js, place-links.js, poi-suggestions.js,
 *   segments.js, stations.js), laufen jetzt über callGemini() hier.
 *   Bei HTTP 429 (Quota) oder 503 (Overloaded) wird automatisch mit
 *   Exponential Backoff erneut versucht (1s -> 2s -> 4s), bevor endgültig
 *   aufgegeben wird. Das fängt die meisten kurzfristigen Rate-Limit-Spitzen
 *   ab, ohne dass der Nutzer etwas davon merkt.
 *
 * BUG-3 FIX (Kryptische Fehlermeldungen):
 *   getGeminiErrorMessage() übersetzt technische Fehler (HTTP-Codes,
 *   "Failed to fetch" etc.) in kurze, verständliche deutsche Meldungen.
 *   Wird von allen Aufrufern statt des rohen e.message verwendet.
 */

import { S } from './state.js';

const MAX_RETRIES = 3;
const BASE_DELAY_MS = 1000;

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Übersetzt einen Fehler (HTTP-Status oder Exception) in eine kurze,
 * verständliche deutsche Meldung für den Endnutzer. Technische Details
 * bleiben in der Konsole (console.error), NICHT im UI.
 */
export function getGeminiErrorMessage(err) {
    const status = err && err.status;
    if (status === 429) return 'KI-Dienst gerade stark ausgelastet. Bitte in ein paar Minuten erneut versuchen.';
    if (status === 503) return 'KI-Dienst momentan nicht erreichbar. Bitte später erneut versuchen.';
    if (status === 400) return 'KI-Anfrage ungültig. Bitte Admin informieren.';
    if (status === 401 || status === 403) return 'KI-Zugang nicht autorisiert. API-Key in den Einstellungen prüfen.';
    if (err && err.name === 'TypeError' && /fetch/i.test(err.message || '')) {
        return 'Netzwerkfehler: Keine Verbindung zum KI-Dienst. Internetverbindung prüfen.';
    }
    return 'KI-Fehler: Anfrage konnte nicht verarbeitet werden.';
}

/**
 * Zentraler Gemini-API-Call mit automatischem Retry bei 429/503.
 *
 * @param {string|Array} promptOrParts - Entweder reiner Prompt-Text (string)
 *   ODER ein fertiges "parts"-Array für multimodale Anfragen (Text + Bilder,
 *   z.B. { text: '...' } und { inline_data: { mime_type, data } } gemischt -
 *   wird von diary.js für die Foto-Analyse beim Blog-Eintrag gebraucht).
 * @param {object} opts - { retries, onRetry }
 * @returns {Promise<string>} - Der reine Text der KI-Antwort
 * @throws {Error} mit .status gesetzt, wenn nach allen Retries kein Erfolg
 */
export async function callGemini(promptOrParts, opts = {}) {
    if (!S.apiKey) {
        const e = new Error('Kein API-Key hinterlegt.');
        e.status = 401;
        e.noKey = true;
        throw e;
    }

    const maxRetries = opts.retries ?? MAX_RETRIES;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${S.apiKey}`;
    const parts = Array.isArray(promptOrParts) ? promptOrParts : [{ text: promptOrParts }];

    let lastErr = null;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            const res = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ contents: [{ parts }] })
            });

            if (!res.ok) {
                const e = new Error(`Gemini API Fehler ${res.status}`);
                e.status = res.status;
                // Nur bei 429 (Quota) und 503 (Overloaded) erneut versuchen -
                // andere Fehler (400, 401, 403) sind nicht durch Warten lösbar.
                if ((res.status === 429 || res.status === 503) && attempt < maxRetries) {
                    lastErr = e;
                    const delay = BASE_DELAY_MS * Math.pow(2, attempt);   // 1s, 2s, 4s
                    console.warn(`Gemini ${res.status} – Retry ${attempt + 1}/${maxRetries} in ${delay}ms`);
                    if (opts.onRetry) opts.onRetry(attempt + 1, maxRetries, delay);
                    await sleep(delay);
                    continue;
                }
                throw e;
            }

            const data = await res.json();
            const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
            if (!text) {
                const e = new Error('Gemini-Antwort leer oder unerwartetes Format.');
                e.status = 500;
                throw e;
            }
            return text;

        } catch (err) {
            // Netzwerkfehler (TypeError: Failed to fetch) ebenfalls retry-fähig
            if (err instanceof TypeError && attempt < maxRetries) {
                lastErr = err;
                const delay = BASE_DELAY_MS * Math.pow(2, attempt);
                console.warn(`Netzwerkfehler – Retry ${attempt + 1}/${maxRetries} in ${delay}ms`);
                if (opts.onRetry) opts.onRetry(attempt + 1, maxRetries, delay);
                await sleep(delay);
                continue;
            }
            throw err;
        }
    }
    throw lastErr;
}

/**
 * Hilfsfunktion: räumt ```json-Codefences aus der KI-Antwort und parsed sie.
 * Wird von allen Stellen genutzt, die strukturiertes JSON von Gemini erwarten
 * (duration.js, poi-suggestions.js, segments.js, stations.js).
 */
export function parseGeminiJson(rawText) {
    const cleaned = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
    return JSON.parse(cleaned);
}