/**
 * segments.js – Etappen-Infos zwischen Stationen (Track 2, Punkt 6)
 * =========================================================================
 * Datenmodell: station.segmentFromPrev = { durationMin, mode, tollRequired,
 * tollNote, prebookingRequired, prebookingNote, aiGenerated, generatedAt }
 * "segmentFromPrev" hängt an der ZWEITEN Station eines Paares (beschreibt
 * die Etappe, die zu dieser Station HIN führt) - so bleibt das Datenmodell
 * stabil, auch wenn Stationen davor eingefügt/gelöscht werden.
 *
 * WICHTIG (Korrektur nach Nutzer-Feedback): Diese Werte werden NICHT mehr
 * manuell im Popup eingetragen, sondern automatisch per KI (Gemini) befüllt,
 * sobald eine Etappe neu entsteht (Station hinzugefügt/verschoben) - analog
 * zu enrichStationDataViaAI() für Campingplätze/Aktivitäten. Das Popup ist
 * reine Anzeige (read-only) für alle Nutzer, inklusive Admins.
 *
 * Technischer Ansatz: unsichtbare, breitere Polyline über der eigentlichen
 * (dekorativen) Routenlinie, damit Touch-Ziele groß genug sind. Diese
 * Etappen-Linien sind ein eigenes Layer, unabhängig von der farbigen
 * "tatsächliche Route"-Linie aus map.js (die ist foto-basiert, rein
 * visuell).
 */

import { S } from './state.js';
import { esc, distanceKm } from './utils.js';
import { saveStationToCloud } from './firebase.js';
import { callGemini, parseGeminiJson, getGeminiErrorMessage } from './gemini.js';

let segmentLayers = [];

const MODE_LABELS = {
    car: 'PKW', rv: 'Wohnmobil', ferry: 'Fähre', train: 'Zug'
};
const MODE_ICONS = {
    car: 'fa-car', rv: 'fa-caravan', ferry: 'fa-ferry', train: 'fa-train'
};

function fmtDuration(min) {
    if (!min && min !== 0) return '';
    const h = Math.floor(min / 60);
    const m = min % 60;
    if (h && m) return `${h} Std. ${m} Min.`;
    if (h) return `${h} Std.`;
    return `${m} Min.`;
}

function popupHtml(station, prevStation) {
    const seg = station.segmentFromPrev;
    const mode = (seg && seg.mode) || 'car';

    if (!seg || seg.pending) {
        return `
            <div class="segment-popup">
                <div class="segment-popup-title">${esc(prevStation.name)} → ${esc(station.name)}</div>
                <div class="text-slate-400 italic"><i class="fa-solid fa-spinner fa-spin"></i> KI ermittelt Infos zur Etappe...</div>
            </div>`;
    }
    if (seg.error) {
        // ✅ BUG-3 FIX: konkrete deutsche Meldung statt generischem "Keine Angaben verfügbar" (nur Admin, normale User sehen nichts Technisches)
        const errText = S.isAdmin && seg.errorMessage ? seg.errorMessage : 'Keine Angaben verfügbar.';
        return `
            <div class="segment-popup">
                <div class="segment-popup-title">${esc(prevStation.name)} → ${esc(station.name)}</div>
                <div class="text-slate-400 italic">${esc(errText)}</div>
                ${S.isAdmin ? `<button onclick="window.retrySegmentInfo('${station.id}')" class="segment-save-btn mt-2"><i class="fa-solid fa-rotate-right"></i> Erneut versuchen</button>` : ''}
            </div>`;
    }

    return `
        <div class="segment-popup">
            <div class="segment-popup-title">${esc(prevStation.name)} → ${esc(station.name)}</div>
            ${seg.durationMin ? `<div><i class="fa-solid ${MODE_ICONS[mode] || 'fa-car'}"></i> ${fmtDuration(seg.durationMin)} · ${MODE_LABELS[mode] || 'PKW'}</div>` : '<div class="text-slate-400 italic">Keine Angaben verfügbar</div>'}
            ${seg.tollRequired ? `<div class="mt-1"><i class="fa-solid fa-road"></i> Mautpflichtig${seg.tollNote ? ': ' + esc(seg.tollNote) : ''}</div>` : ''}
            ${seg.prebookingRequired ? `<div class="mt-1"><i class="fa-solid fa-triangle-exclamation text-amber-600"></i> Vorabbuchung nötig${seg.prebookingNote ? ': ' + esc(seg.prebookingNote) : ''}</div>` : ''}
            <div class="text-[9px] text-slate-400 mt-2"><i class="fa-solid fa-wand-magic-sparkles"></i> KI-generiert${S.isAdmin ? ` &middot; <a href="#" onclick="window.retrySegmentInfo('${station.id}'); return false;" class="underline">neu ermitteln</a>` : ''}</div>
        </div>`;
}

/**
 * Fragt Gemini nach Fahrtdauer/Verkehrsmittel/Maut/Vorabbuchung für eine
 * Etappe. Nutzt denselben apiKey-Mechanismus wie enrichStationDataViaAI.
 */
async function enrichSegmentViaAI(station, prevStation) {
    if (!S.apiKey) {
        station.segmentFromPrev = { error: true, pending: false };
        return;
    }
    station.segmentFromPrev = { pending: true };

    try {
        const distKm = Math.round(distanceKm(prevStation.lat, prevStation.lng, station.lat, station.lng));
        const prompt = `Route von "${prevStation.name}" (${prevStation.lat},${prevStation.lng}) nach "${station.name}" (${station.lat},${station.lng}), Luftlinie ca. ${distKm} km, Reise mit einem Wohnmobil/PKW. Schätze realistisch: Fahrtdauer in Minuten, wahrscheinliches Verkehrsmittel (car/rv/ferry/train - "ferry" wenn eine Meerenge/größeres Gewässer dazwischen liegt, sonst car/rv), ob die Strecke typischerweise mautpflichtig ist, und ob eine Vorabbuchung nötig ist (z.B. bei Fähren). Antworte AUSSCHLIESSLICH als JSON: {"durationMin": number, "mode": "car"|"rv"|"ferry"|"train", "tollRequired": boolean, "tollNote": string, "prebookingRequired": boolean, "prebookingNote": string}. Notizen kurz und auf Deutsch, leer wenn nicht zutreffend.`;

        // ✅ BUG-2 FIX: callGemini() mit automatischem Retry bei 429/503
        const raw = await callGemini(prompt);
        const parsed = parseGeminiJson(raw);

        station.segmentFromPrev = {
            durationMin: typeof parsed.durationMin === 'number' ? parsed.durationMin : null,
            mode: ['car', 'rv', 'ferry', 'train'].includes(parsed.mode) ? parsed.mode : 'car',
            tollRequired: !!parsed.tollRequired,
            tollNote: parsed.tollNote || '',
            prebookingRequired: !!parsed.prebookingRequired,
            prebookingNote: parsed.prebookingNote || '',
            aiGenerated: true,
            generatedAt: Date.now(),
            pending: false
        };
        saveStationToCloud(station);
    } catch (e) {
        console.error('Etappen-Anreicherung fehlgeschlagen für', station.name, e);
        // ✅ BUG-3 FIX: verständliche deutsche Meldung mitgeben (statt nur error:true)
        station.segmentFromPrev = { error: true, pending: false, errorMessage: getGeminiErrorMessage(e) };
    }
}

window.retrySegmentInfo = function(stationId) {
    if (!S.isAdmin) return;
    const idx = S.stations.findIndex(s => s.id === stationId);
    if (idx <= 0) return;
    S.map.closePopup();
    enrichSegmentViaAI(S.stations[idx], S.stations[idx - 1]).then(renderSegmentLines);
};

/**
 * Stellt sicher, dass jede Etappe (Station i-1 -> i) angereicherte Infos
 * hat. Wird bei jedem renderMap() aufgerufen (analog zu recalculateStays) -
 * befüllt nur fehlende Etappen, überschreibt nichts Vorhandenes. So entsteht
 * die Anreicherung automatisch bei neuen/verschobenen Stationen, ohne dass
 * bereits ermittelte Etappen erneut angefragt werden.
 */
export function ensureSegmentInfo() {
    for (let i = 1; i < S.stations.length; i++) {
        const cur = S.stations[i];
        const prev = S.stations[i - 1];
        if (!cur.segmentFromPrev) {
            enrichSegmentViaAI(cur, prev).then(renderSegmentLines);
        }
    }
}

export function renderSegmentLines() {
    if (!S.map) return;
    segmentLayers.forEach(l => S.map.removeLayer(l));
    segmentLayers = [];

    for (let i = 1; i < S.stations.length; i++) {
        const prev = S.stations[i - 1];
        const cur = S.stations[i];
        const seg = cur.segmentFromPrev;
        const hasInfo = seg && !seg.pending && !seg.error && (seg.durationMin || seg.tollRequired || seg.prebookingRequired);

        const hitbox = L.polyline([[prev.lat, prev.lng], [cur.lat, cur.lng]], {
            color: '#000', weight: 22, opacity: 0.001, interactive: true
        }).addTo(S.map);

        hitbox.bindPopup(() => popupHtml(cur, prev), { maxWidth: 260, className: 'segment-leaflet-popup' });

        if (hasInfo) {
            const midLat = (prev.lat + cur.lat) / 2;
            const midLng = (prev.lng + cur.lng) / 2;
            const icon = L.divIcon({
                className: '',
                html: `<div class="segment-indicator"><i class="fa-solid ${MODE_ICONS[seg.mode] || 'fa-car'}"></i></div>`,
                iconSize: [22, 22], iconAnchor: [11, 11]
            });
            const indicator = L.marker([midLat, midLng], { icon, zIndexOffset: 500 }).addTo(S.map);
            indicator.on('click', () => hitbox.openPopup([midLat, midLng]));
            segmentLayers.push(indicator);
        }

        segmentLayers.push(hitbox);
    }
}