/**
 * pois.js – Sehenswürdigkeiten/Aussichtspunkte entlang der Etappen (Track 3, Punkt 8)
 * =======================================================================================
 * Datenmodell: station.segmentFromPrev.pois = [{ name, lat, lng, desc, googleMapsUrl }]
 * (POIs hängen am segmentFromPrev-Objekt der NACHFOLGENDEN Station, d.h. am
 * Segment zwischen zwei Stationen - nicht an einer Station selbst.)
 *
 * KORREKTUR nach Nutzer-Feedback: Kein Formular/Abschnitt pro Stations-Popup
 * mehr. POIs werden global per Karten-Klick gesetzt (Button in der Toolbar
 * schaltet einen "POI hinzufügen"-Modus um) und automatisch dem nächst-
 * gelegenen Segment zugeordnet. Bei jeder Routenänderung (Station hinzugefügt/
 * gelöscht/verschoben) prüft revalidatePois(), ob bestehende POIs noch in
 * sinnvoller Nähe zu einem aktuellen Segment liegen - falls ja, werden sie
 * dem neuen nächstgelegenen Segment zugeordnet (Umzug), falls nein, werden
 * sie entfernt (Admin bekommt eine kurze Zusammenfassung).
 *
 * Clustering: ab ~50 sichtbaren POIs schaltet Leaflet.markercluster automatisch
 * auf Cluster-Darstellung um.
 */

import { S } from './state.js';
import { esc, showToast } from './utils.js';
import { saveStationToCloud } from './firebase.js';
import { getCachedRoutePolyline, distancePointToPolylineKm } from './routing.js';

let poiClusterGroup = null;

// Ab welcher Distanz (km) zur nächsten Etappe ein POI als "nicht mehr gültig" gilt
const POI_VALIDITY_RADIUS_KM = 30;

function distanceKm(lat1, lng1, lat2, lng2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLng/2)**2;
    return 2 * R * Math.asin(Math.sqrt(a));
}

// Bugfix ("POIs sollten nicht entlang der Luftlinie laufen, sondern entlang
// der vorgeschlagenen Route"): distancePointToSegmentKm/distancePointToPolylineKm
// aus routing.js nutzen die gecachte Straßenroute (OSRM) statt der geraden
// Verbindungslinie zwischen zwei Stationen - bei kurvigen Strecken kann der
// Unterschied erheblich sein.

// Bugfix ("Icons der POI an das Thema des POIs anpassen z.B. Camping -> Zelt,
// Strand -> Wellensymbol etc."): POI-Kategorie bestimmt das Icon. Wird von
// der KI beim Vorschlagen mitgeliefert (poi-suggestions.js) bzw. beim
// manuellen Hinzufügen abgefragt. 'default' als Fallback für ältere,
// bereits gespeicherte POIs ohne category-Feld.
export const POI_CATEGORY_ICONS = {
    viewpoint: 'fa-mountain-sun',
    beach: 'fa-water',
    camping: 'fa-campground',
    restaurant: 'fa-utensils',
    historic: 'fa-landmark',
    nature: 'fa-tree',
    town: 'fa-city',
    museum: 'fa-building-columns',
    activity: 'fa-person-hiking',
    shopping: 'fa-bag-shopping',
    default: 'fa-star'
};

export const POI_CATEGORY_LABELS = {
    viewpoint: 'Aussichtspunkt', beach: 'Strand', camping: 'Camping', restaurant: 'Restaurant',
    historic: 'Historisch', nature: 'Natur', town: 'Ort', museum: 'Museum', activity: 'Aktivität',
    shopping: 'Einkaufen', default: 'Sehenswürdigkeit'
};

function poiIcon(category) {
    const iconClass = POI_CATEGORY_ICONS[category] || POI_CATEGORY_ICONS.default;
    return L.divIcon({
        className: '',
        html: `<div class="poi-marker poi-marker-${category || 'default'}"><i class="fa-solid ${iconClass}"></i></div>`,
        iconSize: [22, 22], iconAnchor: [11, 11]
    });
}

function poiPopupHtml(poi, stationId, poiIndex) {
    const mapsUrl = poi.googleMapsUrl || `https://www.google.com/maps/search/?api=1&query=${poi.lat},${poi.lng}`;
    const categoryLabel = POI_CATEGORY_LABELS[poi.category] || POI_CATEGORY_LABELS.default;
    return `
        <div class="poi-popup">
            <div class="poi-popup-category">${categoryLabel}</div>
            <div class="poi-popup-title">${esc(poi.name)}</div>
            ${poi.desc ? `<div class="poi-popup-desc">${esc(poi.desc)}</div>` : ''}
            <a href="${mapsUrl}" target="_blank" class="poi-popup-link"><i class="fa-solid fa-arrow-up-right-from-square"></i> In Google Maps öffnen</a>
            ${S.isAdmin ? `<button onclick="window.deletePoi('${stationId}', ${poiIndex})" class="poi-popup-delete"><i class="fa-solid fa-trash"></i> Löschen</button>` : ''}
        </div>`;
}

export function renderPoiMarkers() {
    if (!S.map) return;
    if (poiClusterGroup) { S.map.removeLayer(poiClusterGroup); }
    if (!S.showPois) return;

    poiClusterGroup = L.markerClusterGroup({
        maxClusterRadius: 45,
        disableClusteringAtZoom: 13,
        iconCreateFunction: cluster => L.divIcon({
            html: `<div class="poi-cluster">${cluster.getChildCount()}</div>`,
            className: '', iconSize: [30, 30]
        })
    });

    S.stations.forEach(st => {
        const pois = (st.segmentFromPrev && st.segmentFromPrev.pois) || [];
        pois.forEach((poi, i) => {
            if (typeof poi.lat !== 'number' || typeof poi.lng !== 'number') return;
            const marker = L.marker([poi.lat, poi.lng], { icon: poiIcon(poi.category) });
            marker.bindPopup(() => poiPopupHtml(poi, st.id, i), { maxWidth: 220 });
            poiClusterGroup.addLayer(marker);
        });
    });

    S.map.addLayer(poiClusterGroup);
}

window.deletePoi = function(stationId, poiIndex) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === stationId);
    if (!st || !st.segmentFromPrev || !st.segmentFromPrev.pois) return;
    if (!confirm('Diesen Punkt wirklich löschen?')) return;

    st.segmentFromPrev.pois.splice(poiIndex, 1);
    saveStationToCloud(st);
    S.map.closePopup();
    renderPoiMarkers();
};

let addPoiMode = false;

/**
 * Findet das Segment (Index der ZWEITEN Station des Paares), das einem
 * Punkt am nächsten liegt - jetzt anhand der gecachten Straßenroute (OSRM),
 * nicht mehr der Luftlinie zwischen den beiden Stationen.
 */
function findNearestSegment(lat, lng) {
    let best = null, bestDist = Infinity;
    for (let i = 1; i < S.stations.length; i++) {
        const polyline = getCachedRoutePolyline(S.stations[i - 1], S.stations[i]);
        const d = distancePointToPolylineKm({ lat, lng }, polyline);
        if (d < bestDist) { bestDist = d; best = i; }
    }
    return best === null ? null : { stationIndex: best, distanceKm: bestDist };
}

window.togglePoiAddMode = function() {
    if (!S.isAdmin) return;
    addPoiMode = !addPoiMode;
    const btn = document.getElementById('btn-toggle-poi-add');
    if (btn) btn.classList.toggle('poi-add-active', addPoiMode);
    S.map.getContainer().style.cursor = addPoiMode ? 'crosshair' : '';
};

export function initPoiClickHandler() {
    if (!S.map) return;
    S.map.on('click', (e) => {
        if (!addPoiMode) return;
        if (S.stations.length < 2) {
            showToast('Für POIs werden mindestens 2 Stationen benötigt (POIs gehören zu einer Etappe zwischen zwei Stationen).', 'info');
            return;
        }
        const nearest = findNearestSegment(e.latlng.lat, e.latlng.lng);
        const st = S.stations[nearest.stationIndex];

        const name = prompt('Name des Punktes (z.B. Aussichtspunkt, Raststätte):');
        if (!name || !name.trim()) return;
        const desc = prompt('Kurze Beschreibung (optional):') || '';
        const categoryInput = (prompt('Kategorie: aussicht / strand / camping / restaurant / historisch / natur / ort / museum / aktivitaet / einkaufen (Enter = allgemein)') || '').trim().toLowerCase();
        const categoryMap = {
            aussicht: 'viewpoint', strand: 'beach', camping: 'camping', restaurant: 'restaurant',
            historisch: 'historic', natur: 'nature', ort: 'town', museum: 'museum',
            aktivitaet: 'activity', einkaufen: 'shopping'
        };
        const category = categoryMap[categoryInput] || 'default';

        if (!st.segmentFromPrev) st.segmentFromPrev = {};
        if (!st.segmentFromPrev.pois) st.segmentFromPrev.pois = [];
        st.segmentFromPrev.pois.push({
            name: name.trim(), lat: e.latlng.lat, lng: e.latlng.lng, desc: desc.trim(), category,
            googleMapsUrl: `https://www.google.com/maps/search/?api=1&query=${e.latlng.lat},${e.latlng.lng}`
        });

        saveStationToCloud(st);
        renderPoiMarkers();
    });
}

/**
 * Wird bei jeder Routenänderung (Station hinzugefügt/gelöscht/verschoben)
 * aufgerufen. Sammelt alle POIs, prüft für jeden, ob er noch nah genug an
 * IRGENDEINEM aktuellen Segment liegt: wenn ja, wird er (falls nötig) dem
 * neuen nächstgelegenen Segment zugeordnet; wenn nein, wird er entfernt.
 * Gibt eine Zusammenfassung zurück (für optionale Admin-Benachrichtigung).
 */
export function revalidatePois() {
    if (S.stations.length < 2) {
        // Keine gültige Route mehr möglich -> alle POIs entfernen
        let removed = 0;
        S.stations.forEach(st => {
            if (st.segmentFromPrev && st.segmentFromPrev.pois && st.segmentFromPrev.pois.length) {
                removed += st.segmentFromPrev.pois.length;
                st.segmentFromPrev.pois = [];
            }
        });
        return { moved: 0, removed, unchanged: 0 };
    }

    const allPois = [];
    S.stations.forEach(st => {
        if (st.segmentFromPrev && st.segmentFromPrev.pois) {
            st.segmentFromPrev.pois.forEach(poi => allPois.push({ poi, fromStation: st }));
            st.segmentFromPrev.pois = [];   // erst leeren, gleich neu verteilen
        }
    });

    let moved = 0, removed = 0, unchanged = 0;
    const touchedStations = new Set();

    allPois.forEach(({ poi, fromStation }) => {
        const nearest = findNearestSegment(poi.lat, poi.lng);
        if (!nearest || nearest.distanceKm > POI_VALIDITY_RADIUS_KM) {
            removed++;
            touchedStations.add(fromStation);
            return;
        }
        const targetStation = S.stations[nearest.stationIndex];
        if (!targetStation.segmentFromPrev) targetStation.segmentFromPrev = {};
        if (!targetStation.segmentFromPrev.pois) targetStation.segmentFromPrev.pois = [];
        targetStation.segmentFromPrev.pois.push(poi);
        touchedStations.add(targetStation);
        if (targetStation !== fromStation) moved++;
        else unchanged++;
    });

    touchedStations.forEach(st => saveStationToCloud(st));
    return { moved, removed, unchanged };
}
