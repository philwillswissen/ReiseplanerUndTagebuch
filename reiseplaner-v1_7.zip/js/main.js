/**
 * main.js – App-Einstiegspunkt
 * ================================
 * Wird als einziges <script type="module"> in index.html eingebunden.
 * Importiert alle anderen Module (wodurch deren window.xxx-Handler und
 * Event-Listener registriert werden) und startet die App.
 *
 * Reihenfolge der Importe ist für ES-Module technisch egal (zirkuläre
 * Importe werden aufgelöst, sobald alle Module geladen sind), aber
 * absichtlich von "Basis" zu "Feature" sortiert für die Lesbarkeit.
 */

import './state.js';
import './utils.js';
import './geo.js';
import './firebase.js';
import './settings.js';
import './duration.js';
import './segments.js';
import './weather.js';
import './pois.js';
import './map.js';
import './stations.js';
import './media.js';
import './diary.js';
import './onboarding.js';

import { initMap } from './map.js';
import { initSystem } from './firebase.js';
import { showOnboardingIfFirstVisit } from './onboarding.js';

// ---- App-Start ----
document.addEventListener("DOMContentLoaded", () => {
    initMap();
    initSystem();
    if (localStorage.getItem('skand_geo_tracking_on') === '1') {
        window.startGeoTracking(true);
    }
    // Punkt: Onboarding - kurze Verzögerung, damit die Karte im Hintergrund
    // schon sichtbar ist, bevor sich das Erklär-Overlay davorlegt
    setTimeout(showOnboardingIfFirstVisit, 500);
});

// ---- Zentrale Tastatursteuerung ----
document.addEventListener('keydown', (e) => {
    const viewer = document.getElementById('photo-viewer-modal');
    if (viewer && !viewer.classList.contains('hidden')) {
        if (e.key === 'ArrowLeft') return window.photoViewerStep(-1);
        if (e.key === 'ArrowRight') return window.photoViewerStep(1);
        if (e.key === 'Escape') return window.closePhotoViewer();
    }
    if (e.key !== 'Escape') return;

    // ESC schließt das oberste offene Fenster
    const layers = [
        ['lightbox-modal', window.closeLightbox],
        ['photo-edit-modal', window.closePhotoEditModal],
        ['export-modal', window.closeExport],
        ['global-gallery-modal', window.closeGlobalGallery],
        ['add-modal', () => document.getElementById('add-modal').classList.add('hidden')],
        ['settings-modal', () => document.getElementById('settings-modal').classList.add('hidden')],
        ['onboarding-overlay', window.closeOnboarding]
    ];
    for (const [id, close] of layers) {
        const el = document.getElementById(id);
        if (el && !el.classList.contains('hidden')) { close(); return; }
    }
    const panel = document.getElementById('side-panel');
    if (panel && panel.classList.contains('open')) window.closeSidePanel();
});

// ---- Klick auf den abgedunkelten Hintergrund schließt das Fenster ----
[
    ['global-gallery-modal', () => window.closeGlobalGallery()],
    ['export-modal', () => window.closeExport()],
    ['lightbox-modal', () => window.closeLightbox()],
    ['photo-edit-modal', () => window.closePhotoEditModal()],
    ['onboarding-overlay', () => window.closeOnboarding()]
].forEach(([id, close]) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('click', ev => { if (ev.target === el) close(); });
});

// ---- Wischgesten für den Foto-Viewer (mobil) ----
(function initSwipe() {
    let startX = null, startY = null, moved = false;
    const el = document.getElementById('photo-viewer-modal');
    if (!el) return;
    el.addEventListener('touchstart', e => {
        startX = e.changedTouches[0].clientX;
        startY = e.changedTouches[0].clientY;
        moved = false;
    }, { passive: true });
    el.addEventListener('touchmove', () => { moved = true; }, { passive: true });
    el.addEventListener('touchend', e => {
        if (startX === null) return;
        const dx = e.changedTouches[0].clientX - startX;
        const dy = e.changedTouches[0].clientY - startY;
        if (Math.abs(dx) > 55 && Math.abs(dx) > Math.abs(dy)) {
            window.photoViewerStep(dx > 0 ? -1 : 1);
        } else if (Math.abs(dy) > 90 && el.classList.contains('pv-full')) {
            window.togglePhotoFullscreen();   // nach unten wischen verlässt Vollbild
        }
        startX = startY = null;
    }, { passive: true });
})();

// ===== PWA: Service Worker Registrierung & Install-Flow (Task 2) =====
let deferredInstallPrompt = null;
let pwaRegistration = null;

if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(reg => {
                pwaRegistration = reg;
                console.log('[PWA] Service Worker registriert, Scope:', reg.scope);

                // Prüft periodisch (bei jedem Laden + stündlich) auf ein neues sw.js
                reg.addEventListener('updatefound', () => {
                    const newWorker = reg.installing;
                    if (!newWorker) return;
                    newWorker.addEventListener('statechange', () => {
                        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                            // Es läuft bereits ein alter SW UND ein neuer ist bereit -> Update-Banner zeigen
                            document.getElementById('pwa-update-banner')?.classList.remove('hidden');
                        }
                    });
                });

                setInterval(() => reg.update().catch(() => {}), 60 * 60 * 1000);
            })
            .catch(err => console.warn('[PWA] Service-Worker-Registrierung fehlgeschlagen:', err));

        // Wenn der neue SW die Kontrolle übernimmt, Seite einmalig neu laden
        let refreshedOnce = false;
        navigator.serviceWorker.addEventListener('controllerchange', () => {
            if (refreshedOnce) return;
            refreshedOnce = true;
            window.location.reload();
        });
    });
}

window.applyPwaUpdate = function () {
    if (pwaRegistration && pwaRegistration.waiting) {
        pwaRegistration.waiting.postMessage('SKIP_WAITING');
    } else {
        window.location.reload();
    }
};

// Chrome/Android: nativer "Zum Startbildschirm hinzufügen"-Prompt
window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
    document.getElementById('btn-install-pwa')?.classList.remove('hidden');
});

window.triggerPwaInstall = async function () {
    const btn = document.getElementById('btn-install-pwa');
    if (!deferredInstallPrompt) {
        // iOS Safari kennt kein beforeinstallprompt -> Anleitung zeigen
        alert('Um die App zu installieren:\n\niOS (Safari): Teilen-Symbol → "Zum Home-Bildschirm"\nAndroid (Chrome): Menü (⋮) → "App installieren"');
        return;
    }
    deferredInstallPrompt.prompt();
    const { outcome } = await deferredInstallPrompt.userChoice;
    console.log('[PWA] Install-Prompt Ergebnis:', outcome);
    deferredInstallPrompt = null;
    btn?.classList.add('hidden');
};

// Bereits installierte Instanz (standalone) -> Install-Button gar nicht erst anzeigen
window.addEventListener('appinstalled', () => {
    document.getElementById('btn-install-pwa')?.classList.add('hidden');
    deferredInstallPrompt = null;
});
if (window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true) {
    document.getElementById('btn-install-pwa')?.classList.add('hidden');
}

// Offline/Online Hinweis im Sync-Status-Bereich
function updatePwaNetworkStatus() {
    const el = document.getElementById('sync-status');
    if (!el) return;
    if (!navigator.onLine) {
        el.innerHTML = '<i class="fa-solid fa-plug-circle-xmark"></i> Offline – zeige zuletzt geladene Daten';
    }
}
window.addEventListener('offline', updatePwaNetworkStatus);
// ===== END PWA =====
