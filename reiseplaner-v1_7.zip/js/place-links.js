/**
 * place-links.js – Automatische Google-Maps-Links für ToDos, Aktivitäten
 * und Campingplätze per KI (Nutzer-Feedback: "Für ToDos und Vorschlags-
 * aktivitäten und Campingplätze automatisch POIs setzen über KI in Google
 * Maps finden und Google Maps Link einbauen")
 * =========================================================================
 * Wichtig: Das ist NICHT dasselbe wie die POIs aus pois.js/poi-suggestions.js
 * (das sind eigenständige Marker ENTLANG der Route zwischen zwei Stationen).
 * Hier geht es um Links AN bereits existierenden Einträgen einer Station
 * (ein To-Do "Freilichtmuseum besuchen" bekommt einen Link zum echten Ort).
 *
 * Da wir keinen Google-Places-API-Key haben (nur einen Gemini-Key, siehe
 * routing.js-Kommentar zur selben Problematik), nutzen wir denselben Ansatz
 * wie überall sonst im Projekt: KI liefert einen möglichst eindeutigen
 * Suchbegriff (Name + Ort), daraus wird ein Google-Maps-SUCH-Link gebaut
 * (kein Places-Places-ID-Lookup, aber landet zuverlässig auf der richtigen
 * Ergebnisseite).
 *
 * Datenmodell-Erweiterung:
 * - todo.googleMapsUrl (string|undefined), todo.placeChecked (bool)
 * - activity.googleMapsUrl (string|undefined), activity.placeChecked (bool)
 * - campsite.url bereits vorhanden (aus enrichStationDataViaAI) - wird hier
 *   nur NACHGERÜSTET, wenn leer; campsite.placeChecked analog.
 *
 * placeChecked unterscheidet "geprüft, aber kein eindeutiger Ort gefunden"
 * von "noch nie geprüft" (undefined) - genau wie bei den Wetter-/Segment-/
 * POI-Caches an anderer Stelle im Projekt. Verhindert, dass dieselbe
 * unklare Aktivität (z.B. "am Strand baden") bei jedem renderMap() erneut
 * angefragt wird.
 */

import { S } from './state.js';
import { saveStationToCloud } from './firebase.js';
import { updateSidePanel } from './stations.js';
import { callGemini, parseGeminiJson, getGeminiErrorMessage } from './gemini.js';

// Nur 1 Station gleichzeitig anfragen (Hintergrund-Nachpflege soll nicht die
// API mit vielen Parallel-Requests fluten, wenn eine Reise viele Stationen hat).
let checkInFlight = false;

function needsCheck(item) {
    return item && item.placeChecked === undefined;
}

async function checkPlacesForStation(station) {
    if (!S.apiKey) return;

    const todosToCheck = (station.todos || []).map((t, i) => ({ i, text: t.text })).filter(t => needsCheck(station.todos[t.i]));
    const activitiesToCheck = (station.activities || [])
        .map((a, i) => ({ i, name: typeof a === 'string' ? a : a.name }))
        .filter(a => needsCheck(station.activities[a.i]));
    const campsitesToCheck = (station.campsites || [])
        .map((c, i) => ({ i, name: c.name }))
        .filter(c => !station.campsites[c.i].url && needsCheck(station.campsites[c.i]));

    if (!todosToCheck.length && !activitiesToCheck.length && !campsitesToCheck.length) return;

    checkInFlight = true;
    try {
        const entries = [
            ...todosToCheck.map(t => ({ ref: `todo:${t.i}`, text: t.text })),
            ...activitiesToCheck.map(a => ({ ref: `activity:${a.i}`, text: a.name })),
            ...campsitesToCheck.map(c => ({ ref: `campsite:${c.i}`, text: c.name }))
        ];

        const listText = entries.map(e => `${e.ref}: "${e.text}"`).join('\n');
        const prompt = `Für die Reisestation "${station.name}": Prüfe für jeden der folgenden Einträge, ob es sich um einen KONKRETEN, in Google Maps auffindbaren Ort handelt (z.B. ein bestimmtes Museum, Restaurant, eine Sehenswürdigkeit, ein Campingplatz) - nicht um eine allgemeine Aktivität ohne festen Ort (z.B. "am Strand baden", "einkaufen gehen", "entspannen").\n\n${listText}\n\nAntworte AUSSCHLIESSLICH als JSON-Array. Für jeden Eintrag MIT konkretem Ort: {"ref": string, "searchQuery": string} (searchQuery = Name + Ort/Stadt zur eindeutigen Google-Maps-Suche). Für Einträge OHNE konkreten Ort: diesen Eintrag einfach WEGLASSEN (nicht ins Array aufnehmen). Jeder "ref"-Wert muss exakt einem der oben genannten refs entsprechen.`;

        const raw = await callGemini(prompt);
        const parsed = parseGeminiJson(raw);
        if (!Array.isArray(parsed)) throw new Error('Unerwartetes Format');

        const foundRefs = new Set();
        parsed.forEach(p => {
            if (!p.ref || !p.searchQuery) return;
            const [type, idxStr] = p.ref.split(':');
            const idx = parseInt(idxStr, 10);
            const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(p.searchQuery)}`;
            foundRefs.add(p.ref);

            if (type === 'todo' && station.todos[idx]) {
                station.todos[idx].googleMapsUrl = mapsUrl;
                station.todos[idx].placeChecked = true;
            } else if (type === 'activity' && station.activities[idx]) {
                if (typeof station.activities[idx] === 'string') {
                    station.activities[idx] = { name: station.activities[idx], googleMapsUrl: mapsUrl, placeChecked: true };
                } else {
                    station.activities[idx].googleMapsUrl = mapsUrl;
                    station.activities[idx].placeChecked = true;
                }
            } else if (type === 'campsite' && station.campsites[idx]) {
                station.campsites[idx].url = mapsUrl;
                station.campsites[idx].placeChecked = true;
            }
        });

        // Alle angefragten, aber nicht in der Antwort enthaltenen Einträge:
        // KI hat sie bewusst weggelassen (kein konkreter Ort) - trotzdem als
        // "geprüft" markieren, damit sie nicht bei jedem renderMap() erneut
        // angefragt werden.
        entries.forEach(e => {
            if (foundRefs.has(e.ref)) return;
            const [type, idxStr] = e.ref.split(':');
            const idx = parseInt(idxStr, 10);
            if (type === 'todo' && station.todos[idx]) station.todos[idx].placeChecked = true;
            else if (type === 'activity' && station.activities[idx]) {
                if (typeof station.activities[idx] === 'string') station.activities[idx] = { name: station.activities[idx], placeChecked: true };
                else station.activities[idx].placeChecked = true;
            } else if (type === 'campsite' && station.campsites[idx]) station.campsites[idx].placeChecked = true;
        });

        saveStationToCloud(station);
        if (S.currentStationId === station.id) updateSidePanel(station.id);
    } catch (e) {
        console.error('Place-Link-Ermittlung fehlgeschlagen für', station.name, getGeminiErrorMessage(e), e);
        // Bewusst NICHT als placeChecked markieren bei Fehlern (Netzwerk/API-
        // Ausfall) - nächster renderMap()-Durchlauf versucht es erneut, analog
        // zum poiSuggestionsError-Pattern in poi-suggestions.js.
    } finally {
        checkInFlight = false;
    }
}

/**
 * Wird bei jedem renderMap() aufgerufen. Prüft Stationen der Reihe nach
 * (max. 1 gleichzeitig) auf ungeprüfte ToDos/Aktivitäten/Campingplätze -
 * deckt sowohl neu hinzugefügte Einträge als auch das einmalige Nachpflegen
 * bestehender (alter) Einträge ohne placeChecked-Feld ab.
 */
export function ensurePlaceLinks() {
    if (!S.isAdmin || checkInFlight) return;
    for (const station of S.stations) {
        const hasUnchecked =
            (station.todos || []).some(needsCheck) ||
            (station.activities || []).some(a => needsCheck(typeof a === 'string' ? null : a)) ||
            (station.campsites || []).some(c => !c.url && needsCheck(c));
        if (hasUnchecked) {
            checkPlacesForStation(station);
            break;   // nur 1 Station pro renderMap()-Durchlauf anstoßen
        }
    }
}