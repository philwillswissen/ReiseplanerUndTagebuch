/**
 * firebase.js – Cloud-Anbindung (Firebase Auth/Firestore/Storage)
 * ===================================================================
 * Enthält auch initSystem() (App-Bootstrap) – logisch gehört das hierher,
 * auch wenn es im Original-Monolith einfach "irgendwo am Ende" stand.
 */

import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import { getAuth, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { getFirestore, collection, onSnapshot, doc, setDoc, deleteDoc, getDocs, getDoc } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import { getStorage, ref as storageRef, uploadBytes, getDownloadURL, deleteObject } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-storage.js";

import { S, appId, LEGACY_TRIP_ID, DEFAULT_AI_STYLE, firebaseConfig, tripKey, tripKeyFor } from './state.js';
import { sha256, esc, slugifyName, toggleLoader, tripTitle } from './utils.js';
import { applyAdminRights, checkViewAccess, showLockScreen, showTripPicker, renderTripPickerList } from './settings.js';
import { fitMapToStations, renderMap, updateTripProgress } from './map.js';
import { updateSidePanel } from './stations.js';

// storageRef/uploadBytes/getDownloadURL/deleteObject werden von media.js gebraucht,
// deshalb hier re-exportiert statt doppelt zu importieren.
export { storageRef, uploadBytes, getDownloadURL, deleteObject, onSnapshot, setDoc, deleteDoc, getDoc, getDocs, collection, doc };

// ---- Firestore Pfad-Helfer ----
export const tripsCol = () => collection(S.db, 'artifacts', appId, 'public', 'data', 'trips');
export const tripDoc = (id) => doc(S.db, 'artifacts', appId, 'public', 'data', 'trips', id);
export const stationsCol = (id) => collection(S.db, 'artifacts', appId, 'public', 'data', 'trips', id, 'stations');
export const stationDoc = (tid, sid) => doc(S.db, 'artifacts', appId, 'public', 'data', 'trips', tid, 'stations', sid);

// ---- App-Bootstrap ----
export async function initSystem() {
    try {
        const app = initializeApp(firebaseConfig);
        const auth = getAuth(app);
        S.db = getFirestore(app);
        S.storage = getStorage(app);

        await signInAnonymously(auth);

        onAuthStateChanged(auth, async (user) => {
            if (!user) return;
            S.currentUser = user;
            document.getElementById('sync-status').innerHTML = `<i class="fa-solid fa-cloud-bolt text-green-400"></i> Cloud aktiv`;

            try { await migrateLegacyData(); } catch(e) { console.warn('Migration:', e); }

            if (S.tripsUnsub) S.tripsUnsub();
            let firstLoad = true;
            // Punkt: Reise-Auswahl vor Passwortabfrage. Nur wenn der Nutzer schon einmal
            // eine Reise gewählt hatte (localStorage 'active_trip_id' gesetzt, siehe state.js),
            // wird diese automatisch wieder aktiviert - sonst würde jeder Neustart erneut
            // die Auswahl zeigen, was bei wiederkehrenden Nutzern nur nervt.
            const hasStoredChoice = !!localStorage.getItem('active_trip_id');
            S.tripsUnsub = onSnapshot(tripsCol(), async (snap) => {
                S.trips = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                S.trips.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));

                const storedTripStillExists = S.trips.find(t => t.id === S.tripId);

                if (firstLoad && !hasStoredChoice) {
                    // Kein Trip zuvor gewählt (frisches Gerät/frischer Browser) -> Auswahlbildschirm
                    // zeigen statt blind die erste Reise zu öffnen. Bei genau einer Reise wird sie
                    // trotzdem angezeigt (nicht automatisch übersprungen), damit der Nutzer bewusst
                    // "Neue Reise anlegen" sehen und wählen kann.
                    firstLoad = false;
                    renderTripPickerList(S.trips);
                    showTripPicker(true);
                    updateTripProgress();
                    return;
                }

                if (!storedTripStillExists) S.tripId = S.trips.length ? S.trips[0].id : LEGACY_TRIP_ID;
                S.trip = S.trips.find(t => t.id === S.tripId) || null;
                S.apiKey = (S.trip && S.trip.apiKey) || '';
                S.aiStyle = (S.trip && S.trip.aiStyle) || DEFAULT_AI_STYLE;

                renderTripSelect();
                applyTripBranding();
                await applyAdminRights();

                if (firstLoad) {
                    firstLoad = false;
                    const ok = await checkViewAccess();
                    showLockScreen(!ok);
                    if (ok) subscribeStations();
                }
                updateTripProgress();
            });
        });
    } catch(e) {
        console.error(e);
        document.getElementById('sync-status').innerHTML = `<i class="fa-solid fa-hard-drive text-amber-400"></i> Lokaler Modus`;
        S.stations = (JSON.parse(localStorage.getItem(tripKey('stations')) || '[]') || []).filter(st => st && typeof st.lat === 'number' && typeof st.lng === 'number');
        S.hasViewAccess = true;
        renderMap();
    }
}

// Einmalige Übernahme der bisherigen Daten in die neue Reise-Struktur
export async function migrateLegacyData() {
    const ref = tripDoc(LEGACY_TRIP_ID);
    if ((await getDoc(ref)).exists()) return;

    const old = await getDocs(collection(S.db, 'artifacts', appId, 'public', 'data', 'stations'));
    await setDoc(ref, {
        name: 'Skandinavien Reiseplaner',
        subtitle: 'Wohnmobil-Rundreise',
        adminHash: await sha256('5kand1nav1en2026!'),
        viewHash: '',
        apiKey: localStorage.getItem('gemini_api_key') || '',
        aiStyle: localStorage.getItem('ai_style_instruction') || DEFAULT_AI_STYLE,
        createdAt: Date.now()
    });
    if (!old.empty) {
        for (const d of old.docs) await setDoc(stationDoc(LEGACY_TRIP_ID, d.id), d.data(), { merge: true });
        console.log(`${old.size} Station(en) übernommen.`);
    }
    // Altes Admin-Passwort lokal übernehmen, damit Bestandsnutzer angemeldet bleiben
    if (localStorage.getItem('admin_pwd') === '5kand1nav1en2026!') {
        localStorage.setItem(tripKeyFor(LEGACY_TRIP_ID, 'admin_pwd'), '5kand1nav1en2026!');
    }
}

export function subscribeStations() {
    if (S.stationsUnsub) { S.stationsUnsub(); S.stationsUnsub = null; }
    if (!S.db || !S.trip || !S.hasViewAccess) return;

    S.stationsUnsub = onSnapshot(stationsCol(S.tripId), (snap) => {
        S.stations = snap.docs.map(d => ({ id: d.id, ...d.data() }))
            .filter(st => typeof st.lat === 'number' && typeof st.lng === 'number' && !isNaN(st.lat) && !isNaN(st.lng));
        S.stations.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
        saveLocal();
        renderMap();
        fitMapToStations();
        if (S.currentStationId && !S.stations.find(s => s.id === S.currentStationId)) window.closeSidePanel();
        else if (S.currentStationId) updateSidePanel(S.currentStationId);
    });
}

export function applyTripBranding() {
    const name = tripTitle();
    document.title = name;
    const h = document.getElementById('app-title');
    if (h) h.innerHTML = `<i class="fa-solid fa-route text-blue-400"></i> ${esc(name)}`;

    const rangeEl = document.getElementById('trip-daterange');
    const rangeText = document.getElementById('trip-daterange-text');
    if (rangeEl && rangeText) {
        if (S.trip && S.trip.startDate && S.trip.endDate) {
            const fmt = iso => new Date(iso + 'T12:00:00').toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: '2-digit' });
            rangeText.innerText = `${fmt(S.trip.startDate)} – ${fmt(S.trip.endDate)}`;
            rangeEl.classList.remove('hidden', 'trip-daterange-missing');
            rangeEl.onclick = null;
        } else if (S.isAdmin) {
            // Bugfix (Punkt 3): statt den Zeitraum einfach unsichtbar zu machen,
            // Admins direkt zum Nachtragen anstupsen - sonst wirkt es, als sei
            // das Feature "kaputt", dabei fehlt nur die Eingabe in den Einstellungen.
            rangeText.innerText = 'Reise-Zeitraum fehlt – zum Ergänzen tippen';
            rangeEl.classList.remove('hidden');
            rangeEl.classList.add('trip-daterange-missing');
            rangeEl.onclick = () => window.openSettings();
        } else {
            rangeEl.classList.add('hidden');
        }
    }
}

export function renderTripSelect() {
    const sel = document.getElementById('trip-select');
    if (!sel) return;
    sel.innerHTML = S.trips.map(t =>
        `<option value="${esc(t.id)}" ${t.id === S.tripId ? 'selected' : ''}>${esc(t.name)}${t.viewHash ? ' (geschützt)' : ''}</option>`
    ).join('');
}

export async function selectTrip(id) {
    if (S.stationsUnsub) { S.stationsUnsub(); S.stationsUnsub = null; }
    S.tripId = id;
    localStorage.setItem('active_trip_id', id);
    S.trip = S.trips.find(t => t.id === id) || null;

    S.stations = (JSON.parse(localStorage.getItem(tripKey('stations')) || '[]') || []).filter(st => st && typeof st.lat === 'number' && typeof st.lng === 'number');
    S.hasFittedMap = false;
    S.currentStationId = null;
    window.closeSidePanel && window.closeSidePanel();

    S.apiKey = (S.trip && S.trip.apiKey) || '';
    S.aiStyle = (S.trip && S.trip.aiStyle) || DEFAULT_AI_STYLE;

    applyTripBranding();
    await applyAdminRights();

    const ok = await checkViewAccess();
    showLockScreen(!ok);
    renderMap();
    if (ok) subscribeStations();
}

window.onTripChange = async function(id) {
    await selectTrip(id);
    renderTripSelect();
    window.closeSettings();
};

// Von settings.js (Trip-Picker) aufgerufen - Brücke, um den zirkulären Import
// firebase.js <-> settings.js zu vermeiden (gleiches Muster wie an anderen
// Stellen im Code, wo Module sich über window statt ES-Import erreichen).
window.__selectTripAfterPicker = selectTrip;

window.openNewTripModal = function() {
    ['nt-name','nt-subtitle','nt-start-date','nt-end-date','nt-admin','nt-admin2','nt-view'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('nt-error').classList.add('hidden');
    document.getElementById('new-trip-modal').classList.remove('hidden');
    document.getElementById('new-trip-modal').classList.add('flex');
};

window.closeNewTripModal = function() {
    const m = document.getElementById('new-trip-modal');
    m.classList.add('hidden'); m.classList.remove('flex');
};

window.createTrip = async function() {
    const name = document.getElementById('nt-name').value.trim();
    const subtitle = document.getElementById('nt-subtitle').value.trim();
    const startDate = document.getElementById('nt-start-date').value;
    const endDate = document.getElementById('nt-end-date').value;
    const pwd = document.getElementById('nt-admin').value;
    const pwd2 = document.getElementById('nt-admin2').value;
    const viewPwd = document.getElementById('nt-view').value;
    const err = document.getElementById('nt-error');
    const fail = (msg) => { err.innerText = msg; err.classList.remove('hidden'); };

    if (!name) return fail('Bitte einen Namen für die Reise angeben.');
    if (!startDate || !endDate) return fail('Bitte Start- und Enddatum der Reise angeben.');
    if (new Date(endDate) < new Date(startDate)) return fail('Das Enddatum liegt vor dem Startdatum.');
    if (pwd.length < 4) return fail('Das Admin-Passwort muss mindestens 4 Zeichen haben.');
    if (pwd !== pwd2) return fail('Die beiden Admin-Passwörter stimmen nicht überein.');
    if (!S.db) return fail('Keine Cloud-Verbindung – Reise kann nicht angelegt werden.');

    const id = slugifyName(name).toLowerCase() + '-' + Math.random().toString(36).slice(2, 7);
    toggleLoader(true, 'Reise wird angelegt...');
    try {
        await setDoc(tripDoc(id), {
            name, subtitle,
            startDate, endDate,
            adminHash: await sha256(pwd),
            viewHash: viewPwd ? await sha256(viewPwd) : '',
            apiKey: '', aiStyle: DEFAULT_AI_STYLE,
            createdAt: Date.now()
        });
        localStorage.setItem(tripKeyFor(id, 'admin_pwd'), pwd);
        if (viewPwd) localStorage.setItem(tripKeyFor(id, 'view_pwd'), viewPwd);
        toggleLoader(false);
        window.closeNewTripModal();
        window.closeSettings();
        showTripPicker(false); // falls die Reise direkt vom Auswahlbildschirm aus angelegt wurde
        setTimeout(() => selectTrip(id), 500);
    } catch(e) {
        toggleLoader(false);
        fail('Fehler: ' + e.message);
    }
};

export function saveLocal() {
    localStorage.setItem(tripKey('stations'), JSON.stringify(S.stations));
}

export async function saveStationToCloud(st) {
    saveLocal();
    if (!S.db || !S.currentUser || !S.isAdmin) return;
    try {
        await setDoc(stationDoc(S.tripId, st.id), st, { merge: true });
    } catch(e) {
        console.error('Speichern fehlgeschlagen:', e);
        const el = document.getElementById('sync-status');
        if (el) el.innerHTML = `<i class="fa-solid fa-triangle-exclamation text-amber-400"></i> Nicht gespeichert`;
    }
}

export async function uploadAllStations() {
    S.stations.forEach(st => saveStationToCloud(st));
}
