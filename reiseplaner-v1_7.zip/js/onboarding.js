/**
 * onboarding.js – Einführung für neue Nutzer (v1_4, Punkt: Onboarding)
 * ============================================================================
 * Zeigt beim allerersten Start ein Overlay, das kurz und bildlich erklärt,
 * was die App kann - mit Fokus auf die Stärken, die sonst im UI untergehen
 * (Karte mit Stationen, Fotos direkt auf der Karte beim Reinzoomen, Datum/
 * Wetter pro Station, Ein-/Ausblenden von Kartenebenen). Tagebuch/Galerie
 * sind im Header schon selbsterklärend groß und bekommen deshalb nur einen
 * kurzen letzten Slide statt der Hauptrolle.
 *
 * Persistenz: localStorage 'skand_onboarding_seen' (geräteweit, nicht pro
 * Reise - ein Familienmitglied, das die App kennt, muss es nicht pro neuer
 * Reise wieder sehen). Über den Info-Button (unten links auf der Karte)
 * jederzeit erneut aufrufbar, unabhängig vom localStorage-Wert.
 */

const SLIDES = [
    {
        icon: 'fa-route',
        title: 'Willkommen an Bord! 👋',
        text: 'Diese App zeigt eure ganze Reise auf einer Karte - mit allen Stationen, Fotos, Wetter und Notizen an einem Ort. Kurzer Rundgang in 9 Schritten.'
    },
    {
        icon: 'fa-map-location-dot',
        title: 'Karte & Stationen',
        text: 'Jede Station eurer Reise ist ein Punkt auf der Karte. Tippt auf einen Punkt, um Details, Fotos und Notizen zu dieser Station zu sehen.'
    },
    {
        icon: 'fa-images',
        title: 'Fotos direkt auf der Karte',
        text: 'Zoomt in die Karte hinein - dort, wo Fotos aufgenommen wurden, erscheinen kleine Bildvorschauen genau am richtigen Ort. So könnt ihr die Reise Foto für Foto nachverfolgen.'
    },
    {
        icon: 'fa-cloud-sun',
        title: 'Datum & Wetter',
        text: 'Tippt oben rechts auf der Karte auf das Wolken-Symbol, um Wettervorhersagen pro Station ein- oder auszublenden. Das Kalender-Symbol zeigt An-/Abreisedaten direkt auf der Karte. Auch Jahre später bleibt hier sichtbar, wie das Wetter damals vorhergesagt wurde.'
    },
    {
        icon: 'fa-sliders',
        title: 'Ebenen ein- und ausblenden',
        text: 'Mit den Symbolen oben rechts könnt ihr Wetter, Sehenswürdigkeiten und Reisedaten unabhängig voneinander ein- und ausblenden - so seht ihr immer nur, was euch gerade interessiert.'
    },
    {
        icon: 'fa-route',
        title: 'Die Route zwischen Stationen',
        text: 'Tippt auf die Linie zwischen zwei Stationen - dort zeigt euch die App automatisch Fahrzeit, Verkehrsmittel und ob Maut oder eine Fährbuchung nötig ist.'
    },
    {
        icon: 'fa-star',
        title: 'Sehenswürdigkeiten entlang der Strecke',
        text: 'Die App schlägt automatisch Sehenswürdigkeiten, Strände und Aussichtspunkte entlang eurer Route vor. Ihr entscheidet, welche davon als Punkt auf der Karte erscheinen sollen.'
    },
    {
        icon: 'fa-wand-magic-sparkles',
        title: 'Von der KI unterstützt',
        text: 'Beschreibungen, Aktivitäten-Tipps und Reisetagebuch-Einträge werden auf Wunsch automatisch erstellt - aus euren Notizen, Stichpunkten und Fotos. Ihr könnt jeden Text danach frei anpassen.'
    },
    {
        icon: 'fa-book-open',
        title: 'Tagebuch & Galerie',
        text: 'Oben im Menü findet ihr außerdem das Reisetagebuch mit allen Einträgen im Lesefluss, und die Galerie mit allen Fotos der Reise auf einen Blick. Diesen Rundgang findet ihr jederzeit wieder über das ⓘ-Symbol unten links auf der Karte.',
        isLast: true
    }
];

let currentSlide = 0;

function renderSlide() {
    const s = SLIDES[currentSlide];
    const container = document.getElementById('onboarding-slides');
    if (!container) return;

    container.innerHTML = `
        <div class="w-16 h-16 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center text-2xl mx-auto mb-4">
            <i class="fa-solid ${s.icon}"></i>
        </div>
        <h3 class="text-lg font-bold text-slate-800 text-center mb-2">${s.title}</h3>
        <p class="text-sm text-slate-600 text-center leading-relaxed">${s.text}</p>
    `;

    const dots = document.getElementById('onboarding-dots');
    if (dots) {
        dots.innerHTML = SLIDES.map((_, i) =>
            `<span class="w-1.5 h-1.5 rounded-full ${i === currentSlide ? 'bg-indigo-600' : 'bg-slate-200'}"></span>`
        ).join('');
    }

    const prevBtn = document.getElementById('onboarding-prev');
    const nextBtn = document.getElementById('onboarding-next');
    if (prevBtn) prevBtn.classList.toggle('invisible', currentSlide === 0);
    if (nextBtn) nextBtn.textContent = s.isLast ? 'Los geht\'s!' : 'Weiter';
}

window.openOnboarding = function() {
    currentSlide = 0;
    renderSlide();
    const overlay = document.getElementById('onboarding-overlay');
    if (overlay) overlay.classList.remove('hidden');
};

window.closeOnboarding = function() {
    const overlay = document.getElementById('onboarding-overlay');
    if (overlay) overlay.classList.add('hidden');
    localStorage.setItem('skand_onboarding_seen', '1');
};

window.onboardingNext = function() {
    const s = SLIDES[currentSlide];
    if (s.isLast) { window.closeOnboarding(); return; }
    currentSlide = Math.min(currentSlide + 1, SLIDES.length - 1);
    renderSlide();
};

window.onboardingPrev = function() {
    currentSlide = Math.max(currentSlide - 1, 0);
    renderSlide();
};

/**
 * Beim allerersten Start automatisch anzeigen. Wird von main.js nach dem
 * initialen Kartenaufbau aufgerufen, damit das Overlay nicht schon vor der
 * Karte im Hintergrund erscheint.
 */
export function showOnboardingIfFirstVisit() {
    if (localStorage.getItem('skand_onboarding_seen') === '1') return;
    window.openOnboarding();
}
