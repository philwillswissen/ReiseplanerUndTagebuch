/**
 * poi-suggestions.js – KI-POI-Vorschläge pro Etappe (Punkt 8b)
 * =========================================================================
 * Ergänzt Punkt 8 (pois.js, rein manuelles Hinzufügen per Karten-Klick) um
 * automatische KI-Vorschläge, analog zu ensureSegmentInfo() in segments.js.
 *
 * WICHTIGER Unterschied zu segments.js: Vorschläge werden NICHT automatisch
 * übernommen. POIs sind ortsfeste Marker, die auch mal danebenliegen können
 * (KI-Koordinaten sind Schätzungen) - deshalb kein Blind-Trust wie bei den
 * Etappen-Metadaten, sondern Bestätigen/Verwerfen durch den Admin, genau wie
 * im Requirement Spec für den späteren KI-Chat (Punkt 10) vorgesehen.
 *
 * Datenmodell: station.segmentFromPrev.poiSuggestions = [
 *   { name, lat, lng, desc, status: 'pending'|'rejected', generatedAt }
 * ]
 * - Bestätigte Vorschläge wandern nach station.segmentFromPrev.pois (das
 *   bestehende Datenmodell aus pois.js) und werden aus poiSuggestions entfernt.
 * - Verworfene Vorschläge bleiben mit status:'rejected' stehen, damit dieselbe
 *   Etappe nicht bei jedem renderMap() erneut angefragt wird.
 * - undefined (Property fehlt komplett) = "noch nie angefragt" -> wird von
 *   ensurePoiSuggestions() aufgegriffen. Ein leeres Array [] zählt bereits
 *   als "angefragt, aber KI hatte nichts Sinnvolles" - wird nicht erneut probiert.
 */

import { S } from './state.js';
import { esc, distanceKm, showToast } from './utils.js';
import { saveStationToCloud } from './firebase.js';
import { renderPoiMarkers, POI_CATEGORY_ICONS, POI_CATEGORY_LABELS } from './pois.js';
import { ensureRoutePolyline, getRouteWaypoints } from './routing.js';
import { callGemini, parseGeminiJson, getGeminiErrorMessage } from './gemini.js';

const MAX_SUGGESTIONS_PER_SEGMENT = 4;
const VALID_CATEGORIES = ['viewpoint', 'beach', 'camping', 'restaurant', 'historic', 'nature', 'town', 'museum', 'activity', 'shopping'];

async function generatePoiSuggestions(prevStation, curStation) {
    if (!S.apiKey) return;
    curStation.segmentFromPrev.poiSuggestionsPending = true;

    try {
        const distKm = Math.round(distanceKm(prevStation.lat, prevStation.lng, curStation.lat, curStation.lng));

        // Bugfix ("POIs sollten nicht entlang der Luftlinie laufen, sondern
        // entlang der vorgeschlagenen Route"): echte Straßenroute (OSRM) statt
        // nur Start-/Endkoordinaten in den Prompt geben, damit die KI Punkte
        // vorschlägt, die wirklich an der befahrenen Strecke liegen.
        const polyline = await ensureRoutePolyline(prevStation, curStation);
        const waypoints = getRouteWaypoints(polyline, 5);
        const routeDesc = waypoints.map(([lat, lng]) => `${lat.toFixed(3)},${lng.toFixed(3)}`).join(' → ');

        const prompt = `Route von "${prevStation.name}" nach "${curStation.name}", ca. ${distKm} km, Reise mit Wohnmobil/PKW. Die tatsächliche Straßenroute verläuft über diese GPS-Wegpunkte (in Reihenfolge): ${routeDesc}. Nenne 2-4 sehenswerte Punkte NAHE DIESER TATSÄCHLICHEN STRASSENROUTE (nicht der Luftlinie!) - Aussichtspunkte, Sehenswürdigkeiten, gute Raststätten, Strände, historische Orte etc. Antworte AUSSCHLIESSLICH als JSON-Array: [{"name": string, "lat": number, "lng": number, "desc": string, "category": string}]. category ist genau eines von: ${VALID_CATEGORIES.join(', ')}. Beschreibung kurz (max. 1 Satz), auf Deutsch. Nur Punkte mit plausiblen, realistischen GPS-Koordinaten nahe der genannten Wegpunkte. Falls dir keine sinnvollen Punkte bekannt sind, antworte mit [].`;

        const raw = await callGemini(prompt);
        const parsed = parseGeminiJson(raw);
        if (!Array.isArray(parsed)) throw new Error('Unerwartetes Format');

        const now = Date.now();
        const suggestions = parsed
            .filter(p => typeof p.lat === 'number' && typeof p.lng === 'number' && p.name)
            .slice(0, MAX_SUGGESTIONS_PER_SEGMENT)
            .map(p => ({
                name: String(p.name).trim(),
                lat: p.lat, lng: p.lng,
                desc: (p.desc || '').trim(),
                category: VALID_CATEGORIES.includes(p.category) ? p.category : 'default',
                status: 'pending',
                generatedAt: now
            }));

        curStation.segmentFromPrev.poiSuggestions = suggestions;
        curStation.segmentFromPrev.poiSuggestionsPending = false;
        saveStationToCloud(curStation);
    } catch (e) {
        console.error('POI-Vorschläge fehlgeschlagen für', curStation.name, e);
        // Bewusst KEIN leeres Array setzen bei Fehlern (im Unterschied zu "KI hatte
        // nichts Sinnvolles") - sonst würde ein temporärer API-Fehler die Etappe
        // dauerhaft von weiteren Versuchen ausschließen. poiSuggestionsError
        // erlaubt späteres erneutes Prüfen, ohne bei jedem renderMap() sofort
        // wieder zu feuern (siehe ensurePoiSuggestions()).
        curStation.segmentFromPrev.poiSuggestionsPending = false;
        curStation.segmentFromPrev.poiSuggestionsError = true;
        // ✅ BUG-3 FIX: verständliche deutsche Meldung merken (für Admin-UI, falls dort später angezeigt)
        curStation.segmentFromPrev.poiSuggestionsErrorMessage = getGeminiErrorMessage(e);
    }
}

/**
 * Wird bei jedem renderMap() aufgerufen (analog zu ensureSegmentInfo). Fragt
 * nur Etappen an, die noch keine poiSuggestions haben UND deren Etappen-Info
 * (segmentFromPrev) bereits vorliegt (kein Doppel-Request während
 * ensureSegmentInfo für dieselbe Etappe noch läuft).
 */
export function ensurePoiSuggestions() {
    if (!S.isAdmin) return;   // Vorschläge sind eine Admin-Funktion, kein Grund sie im Hintergrund für Betrachter abzufragen
    for (let i = 1; i < S.stations.length; i++) {
        const cur = S.stations[i];
        const prev = S.stations[i - 1];
        if (!cur.segmentFromPrev || cur.segmentFromPrev.pending) continue;   // Etappen-Info muss zuerst fertig sein
        if (cur.segmentFromPrev.poiSuggestions !== undefined) continue;      // schon angefragt (auch leeres Array zählt als "erledigt")
        if (cur.segmentFromPrev.poiSuggestionsPending) continue;             // Anfrage läuft bereits
        if (cur.segmentFromPrev.poiSuggestionsError) continue;               // letzter Versuch fehlgeschlagen - kein Auto-Retry, Admin kann manuell erneut anstoßen
        generatePoiSuggestions(prev, cur).then(() => renderPoiSuggestionsBadge());
    }
}

export function getPendingSuggestions() {
    const result = [];
    S.stations.forEach((st, idx) => {
        const suggestions = (st.segmentFromPrev && st.segmentFromPrev.poiSuggestions) || [];
        suggestions.forEach((sug, sIdx) => {
            if (sug.status === 'pending') {
                result.push({ station: st, prevStation: S.stations[idx - 1], suggestion: sug, suggestionIndex: sIdx });
            }
        });
    });
    return result;
}

export function renderPoiSuggestionsBadge() {
    const badge = document.getElementById('poi-suggestions-badge');
    if (!badge) return;
    const count = getPendingSuggestions().length;
    if (count > 0) {
        badge.innerText = count;
        badge.classList.remove('hidden');
    } else {
        badge.classList.add('hidden');
    }
}

function suggestionCardHtml(item) {
    const { station, prevStation, suggestion, suggestionIndex } = item;
    const routeLabel = prevStation ? `${esc(prevStation.name)} → ${esc(station.name)}` : esc(station.name);
    const categoryIcon = POI_CATEGORY_ICONS[suggestion.category] || POI_CATEGORY_ICONS.default;
    const categoryLabel = POI_CATEGORY_LABELS[suggestion.category] || POI_CATEGORY_LABELS.default;
    return `
        <div class="poi-suggestion-card">
            <div class="poi-suggestion-route">${routeLabel}</div>
            <div class="poi-suggestion-name"><i class="fa-solid ${categoryIcon} poi-suggestion-category-icon" title="${categoryLabel}"></i> ${esc(suggestion.name)}</div>
            ${suggestion.desc ? `<div class="poi-suggestion-desc">${esc(suggestion.desc)}</div>` : ''}
            <a href="https://www.google.com/maps/search/?api=1&query=${suggestion.lat},${suggestion.lng}" target="_blank" class="poi-suggestion-maplink"><i class="fa-solid fa-arrow-up-right-from-square"></i> Auf Karte prüfen</a>
            <div class="poi-suggestion-actions">
                <button onclick="window.rejectPoiSuggestion('${station.id}', ${suggestionIndex})" class="poi-suggestion-reject"><i class="fa-solid fa-xmark"></i> Verwerfen</button>
                <button onclick="window.acceptPoiSuggestion('${station.id}', ${suggestionIndex})" class="poi-suggestion-accept"><i class="fa-solid fa-check"></i> Übernehmen</button>
            </div>
        </div>`;
}

export function renderPoiSuggestionsList() {
    const container = document.getElementById('poi-suggestions-list');
    if (!container) return;
    const pending = getPendingSuggestions();
    if (!pending.length) {
        container.innerHTML = `<div class="poi-suggestions-empty">Keine offenen Vorschläge. Neue Etappen werden automatisch geprüft, sobald ihre Fahrtdaten ermittelt wurden.</div>`;
        return;
    }
    container.innerHTML = pending.map(suggestionCardHtml).join('');
}

window.openPoiSuggestionsModal = function() {
    if (!S.isAdmin) return;
    renderPoiSuggestionsList();
    document.getElementById('poi-suggestions-modal').classList.remove('hidden');
};

window.closePoiSuggestionsModal = function() {
    document.getElementById('poi-suggestions-modal').classList.add('hidden');
};

window.acceptPoiSuggestion = function(stationId, suggestionIndex) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === stationId);
    if (!st || !st.segmentFromPrev || !st.segmentFromPrev.poiSuggestions) return;
    const sug = st.segmentFromPrev.poiSuggestions[suggestionIndex];
    if (!sug || sug.status !== 'pending') return;

    if (!st.segmentFromPrev.pois) st.segmentFromPrev.pois = [];
    st.segmentFromPrev.pois.push({
        name: sug.name, lat: sug.lat, lng: sug.lng, desc: sug.desc, category: sug.category || 'default',
        googleMapsUrl: `https://www.google.com/maps/search/?api=1&query=${sug.lat},${sug.lng}`
    });
    st.segmentFromPrev.poiSuggestions.splice(suggestionIndex, 1);

    saveStationToCloud(st);
    renderPoiMarkers();
    renderPoiSuggestionsList();
    renderPoiSuggestionsBadge();
    showToast(`"${sug.name}" wurde als Sehenswürdigkeit übernommen.`, 'success');
};

window.rejectPoiSuggestion = function(stationId, suggestionIndex) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === stationId);
    if (!st || !st.segmentFromPrev || !st.segmentFromPrev.poiSuggestions) return;
    const sug = st.segmentFromPrev.poiSuggestions[suggestionIndex];
    if (!sug || sug.status !== 'pending') return;

    sug.status = 'rejected';
    saveStationToCloud(st);
    renderPoiSuggestionsList();
    renderPoiSuggestionsBadge();
};