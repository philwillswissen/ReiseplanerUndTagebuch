/**
 * duration.js – Anwesenheitsdauer pro Station (Track 2, Punkt 4)
 * ==================================================================
 * Datenmodell: station.stay = {
 *   suggestedStart, suggestedEnd,       // berechneter Vorschlag
 *   overrideStart, overrideEnd,         // manuelle Korrektur (Admin)
 *   isManual,                           // true wenn override aktiv
 *   isPastLocked,                       // true wenn aus Foto-Zeitstempeln übernommen (siehe unten)
 *   aiWeight, aiWeightReason, aiWeightGeneratedAt   // KI-Einschätzung, s.u.
 * }
 *
 * WICHTIG (2. Korrektur nach Nutzer-Feedback):
 *
 * 1) GEWICHTUNG PER KI STATT AKTIVITÄTEN-ANZAHL
 *    Die alte Heuristik ("mehr Aktivitäten = mehr Tage") war irreführend,
 *    weil die KI bei der Stations-Anreicherung ohnehin meist ~3 Aktivitäten
 *    liefert - jede Station hätte am Ende gleich viele Tage bekommen. Jetzt
 *    liest die KI Name/Beschreibung/Aktivitäten/Notizen der Station und
 *    schätzt ein RELATIVES Gewicht (1-14) für die Aufenthaltsdauer - z.B.
 *    "Hamburg, kurzer Zwischenstopp" -> 1, "Woche Kitesurfen" -> 7. Das
 *    Gewicht wird einmalig ermittelt und gecacht (aiWeight), nicht bei
 *    jedem Render neu abgefragt.
 *
 *    Der eigentliche Verteilungs-Algorithmus (proportional nach Gewicht,
 *    exakt innerhalb des Reise-Zeitraums, siehe distributeDays) bleibt
 *    unverändert - nur die Gewichts-QUELLE hat sich geändert. Das hält die
 *    mathematisch heikle Anker-Logik unangetastet, während die KI nur einen
 *    einzelnen, leicht überprüfbaren Wert pro Station liefert.
 *
 *    Hinweis: Sobald Punkt 10 (KI-Chat zur Reiseplanung) existiert, wird der
 *    Aufenthaltswunsch dort direkt im Dialog geäußert und dieser Automatismus
 *    hier wird selten noch gebraucht - bis dahin ist das hier die beste
 *    verfügbare Näherung auf Basis der ohnehin vorhandenen Stationstexte.
 *
 * 2) VERGANGENHEITSSCHUTZ
 *    Stationen mit Fotos gelten als (zumindest teilweise) bereits besucht.
 *    Ihr Zeitraum wird aus den tatsächlichen Foto-Zeitstempeln übernommen
 *    (isPastLocked) und wirkt - genau wie eine manuelle Überschreibung -
 *    als fester ANKER, an dem die Route in Segmente zerlegt wird. Die KI
 *    und der Verteilungs-Algorithmus rühren diese Zeiträume nicht an, egal
 *    was sich sonst an der Route ändert.
 *
 * 3) VALIDITÄTSPRÜFUNG
 *    getStayValidityWarning() vergleicht den gespeicherten (ggf. manuell
 *    gesetzten) Zeitraum gegen die tatsächlichen Foto-Zeitstempel. Weichen
 *    sie ab, liefert es einen Warntext, der als gelbes Dreieck mit Tooltip
 *    neben dem Datum erscheint (renderStayBlock).
 */

import { S } from './state.js';
import { dayKey, toggleLoader, showToast } from './utils.js';
import { saveStationToCloud } from './firebase.js';
import { updateSidePanel } from './stations.js';
import { renderMap } from './map.js';
import { callGemini, parseGeminiJson, getGeminiErrorMessage } from './gemini.js';

const AVG_DAILY_DRIVE_KM = 280;
const DEFAULT_AI_WEIGHT = 1;

function addDays(date, n) {
    const d = new Date(date);
    d.setDate(d.getDate() + n);
    return d;
}

function daysBetween(a, b) {
    return Math.round((b - a) / 86400000);
}

function isoDate(d) {
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function parseIso(s) {
    return new Date(s + 'T00:00:00');
}

function distanceKm(lat1, lng1, lat2, lng2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLng/2)**2;
    return 2 * R * Math.asin(Math.sqrt(a));
}

function travelDaysBetween(a, b) {
    const dist = distanceKm(a.lat, a.lng, b.lat, b.lng);
    return Math.max(0, Math.ceil(dist / AVG_DAILY_DRIVE_KM) - 1);
}

function distributeDays(stations, availableDays) {
    if (!stations.length) return [];
    const weights = stations.map(s => (s.stay && s.stay.aiWeight) || DEFAULT_AI_WEIGHT);
    const totalWeight = weights.reduce((a, b) => a + b, 0);
    const raw = weights.map(w => (availableDays * w) / totalWeight);
    const floored = raw.map(Math.floor);
    let assigned = floored.reduce((a, b) => a + b, 0);
    let remainder = availableDays - assigned;
    const order = raw.map((v, i) => [v - floored[i], i]).sort((a, b) => b[0] - a[0]);
    const result = [...floored];
    for (let i = 0; i < remainder && i < order.length; i++) result[order[i][1]]++;
    return result.map(d => Math.max(1, d));
}

/**
 * Foto-Zeitraum einer Station (kalendertaggenau, nutzt dieselbe Floating-
 * Timestamp-sichere Logik wie dayKey() für Tagebuch-Sortierung - siehe
 * Bugfix 0.2). null, wenn keine (georeferenzierten) Fotos vorhanden.
 * 
 * Returns: { start, end, newestTimestamp } oder null
 * newestTimestamp wird für die isPastLocked-Heuristik gebraucht: nur Stationen,
 * deren neuestes Foto älter als 24h ist, gelten als "wirklich vorbei".
 */
function getPhotoRange(station) {
    const days = (station.images || [])
        .map((img, i) => ({
            day: dayKey(img.timestamp),
            timestamp: img.timestamp || 0,
            idx: i
        }))
        .filter(d => d.day !== 'unbekannt');
    if (!days.length) return null;
    days.sort((a, b) => a.day.localeCompare(b.day));
    const newest = days.reduce((best, d) => !best || d.timestamp > best.timestamp ? d : best, null);
    return {
        start: days[0].day,
        end: days[days.length - 1].day,
        newestTimestamp: newest ? newest.timestamp : null
    };
}

/**
 * Bugfix 0.9 (Punkt 4 Erweiterung): isPastLocked sollte nur für Stationen gelten,
 * deren neuestes Foto älter als 24h ist. Sonst können laufende Stationen (gerade
 * dort, noch Fotos hochladend) nicht manuell auf das finale Enddatum korrigiert werden.
 */
function isPhotoReallyPast(photoRange) {
    if (!photoRange || !photoRange.newestTimestamp) return false;
    const newestMs = typeof photoRange.newestTimestamp === 'number' ? photoRange.newestTimestamp : new Date(photoRange.newestTimestamp).getTime();
    const ageHours = (Date.now() - newestMs) / (1000 * 60 * 60);
    return ageHours >= 24;
}

/**
 * Fragt Gemini nach einer relativen Gewichtung (1-14) für die Aufenthalts-
 * dauer einer Station, basierend auf Name/Beschreibung/Aktivitäten/Notizen.
 * Wird einmalig pro Station ermittelt und in station.stay.aiWeight gecacht -
 * kein wiederholter API-Call bei jedem Render.
 */
async function estimateStayWeightViaAI(station) {
    if (!S.apiKey) {
        station.stay.aiWeight = DEFAULT_AI_WEIGHT;
        if (S.isAdmin) {
            station.stay.aiWeightReason = '⚙️ Kein Gemini-Key – nutze einfachen Fallback. Zum Aktivieren: Einstellungen → Reise-Info → API-Key';
        } else {
            station.stay.aiWeightReason = '';
        }
        return;
    }
    try {
        const activityText = (station.activities || []).map(a => typeof a === 'string' ? a : `${a.name}: ${a.desc || ''}`).join('; ');
        const prompt = `Station einer Reiseroute: "${station.name}". Beschreibung: "${station.desc || ''}". Aktivitäten: "${activityText}". Notizen: "${station.notes || ''}".
Schätze eine RELATIVE Gewichtung von 1 bis 14 dafür, wie viele Tage jemand hier sinnvollerweise verbringen sollte, im Vergleich zu anderen Stationen derselben Reise. Ein reiner Durchfahrts-/Übernachtungsstopp bekommt 1. Eine Station mit explizit langer Aktivität (z.B. "eine Woche Kitesurfen", mehrtägiger Wanderung, Familientreffen über mehrere Tage) bekommt einen entsprechend hohen Wert bis 14. Städte/Sehenswürdigkeiten ohne besonderen Hinweis meist 1-3.
Antworte AUSSCHLIESSLICH als JSON: {"weight": number, "reason": string (kurz, auf Deutsch)}.`;

        // ✅ BUG-2 FIX: callGemini() statt direktem fetch – retried automatisch
        // bei 429 (Quota)/503 (Overloaded) mit Exponential Backoff (1s/2s/4s)
        const raw = await callGemini(prompt);
        const parsed = parseGeminiJson(raw);

        const weight = Math.max(1, Math.min(14, Math.round(Number(parsed.weight) || DEFAULT_AI_WEIGHT)));
        station.stay.aiWeight = weight;
        station.stay.aiWeightReason = parsed.reason || '';
        station.stay.aiWeightGeneratedAt = Date.now();
    } catch (e) {
        console.error('KI-Gewichtung fehlgeschlagen für Station', station.name, '– nutze Fallback. Fehler:', e);
        station.stay.aiWeight = DEFAULT_AI_WEIGHT;
        // ✅ BUG-3 FIX: verständliche deutsche Meldung statt rohem e.message,
        // weiterhin nur für Admins sichtbar (FIX 3 aus v5.3.1 bleibt erhalten)
        if (S.isAdmin) {
            station.stay.aiWeightReason = `⚙️ ${getGeminiErrorMessage(e)} (Fallback-Wert wird verwendet)`;
        } else {
            station.stay.aiWeightReason = '';
        }
    }
}

/**
 * Ermittelt fehlende KI-Gewichte nach (nur für Stationen ohne Cache und
 * ohne Vergangenheitsschutz - vergangene Stationen brauchen kein Gewicht,
 * ihr Zeitraum steht ja bereits über die Fotos fest). Wird bei Routen-
 * änderung aus map.js aufgerufen, analog zu ensureSegmentInfo/revalidatePois.
 * Ruft recalculateStays() + onDone() erneut auf, sobald alle Gewichte da sind.
 */
export async function ensureStayWeights(onDone) {
    const pending = S.stations.filter(st => {
        if (getPhotoRange(st)) return false;   // Vergangenheit: kein Gewicht nötig
        if (!st.stay) st.stay = {};
        return st.stay.aiWeight === undefined;
    });
    if (!pending.length) return;

    await Promise.all(pending.map(st => {
        if (!st.stay) st.stay = {};
        return estimateStayWeightViaAI(st);
    }));
    pending.forEach(st => saveStationToCloud(st));
    recalculateStays();
    if (onDone) onDone();
}

export function recalculateStays() {
    if (!S.stations.length) return;
    if (!S.trip || !S.trip.startDate || !S.trip.endDate) {
        return;
    }

    const tripStart = parseIso(S.trip.startDate);
    const tripEnd = parseIso(S.trip.endDate);
    const tripTotalDays = daysBetween(tripStart, tripEnd);
    S.stayOverflowWarning = tripTotalDays < S.stations.length;

    S.stations.forEach(st => {
        if (!st.stay) st.stay = { suggestedStart: null, suggestedEnd: null, overrideStart: null, overrideEnd: null, isManual: false };
    });

    // Anker: Reise-Start/-Ende (Rand), manuelle Überschreibungen, UND
    // vergangene (fotografisch belegte) Stationen. Reihenfolge der Prüfung
    // wichtig: eine manuelle Überschreibung auf einer vergangenen Station
    // (falls ein Admin sie explizit gesetzt hat) hat Vorrang vor den Fotos.
    const anchors = [{ idx: -1, date: tripStart }];
    S.stations.forEach((st, idx) => {
        st.stay.isPastLocked = false;
        if (st.stay.isManual && st.stay.overrideStart && st.stay.overrideEnd) {
            anchors.push({ idx, start: parseIso(st.stay.overrideStart), end: parseIso(st.stay.overrideEnd) });
            return;
        }
        const photoRange = getPhotoRange(st);
        if (photoRange) {
            const photoStart = parseIso(photoRange.start);
            const photoEnd = parseIso(photoRange.end);
            // Schutz gegen fehlerhafte EXIF-/Sidecar-Zeitstempel (z.B. Kamera-Uhr
            // falsch gestellt, Testfotos): ein Foto weit außerhalb des Reise-
            // Zeitraums ist eher ein Datenfehler als ein Beleg für eine vergangene
            // Anwesenheit und würde als Anker die komplette Berechnung verzerren.
            // Solche Fälle NICHT als Anker verwenden - sie werden stattdessen über
            // getStayValidityWarning() sichtbar (Warndreieck neben dem Datum),
            // damit der Admin die Foto-Metadaten korrigieren kann.
            if (photoEnd >= tripStart && photoStart <= tripEnd) {
                // Bugfix 0.9: Nur lock und als Anker verwenden, wenn die Fotos
                // wirklich "past" sind (älter als 24h). Laufende Stationen mit
                // aktuellen Fotos bleiben editierbar (Fotos werden dort nicht als
                // Anker verwendet).
                if (isPhotoReallyPast(photoRange)) {
                    st.stay.isPastLocked = true;
                    anchors.push({ idx, start: photoStart, end: photoEnd });
                }
            }
        }
    });
    anchors.push({ idx: S.stations.length, date: tripEnd });

    // Bugfix ("es werden auch für das Ziel Zeiträume kalkuliert - das ist
    // Quatsch"): ohne diese Sonderbehandlung wird die LETZTE Station wie eine
    // normale Zwischenstation im Verteilungs-Loop unten behandelt und bekommt
    // dadurch einen mehrtägigen "Aufenthalt am Ziel" zugewiesen. Gewünscht:
    // das Ziel hat nur ein ANKUNFTSDATUM = Reiseende (kein Bereich). Die
    // vorletzte Station bekommt dadurch automatisch korrekt weniger Tage
    // zugewiesen, weil travelDaysBetween(vorletzte, letzte) beim Verteilen
    // abgezogen wird - das entspricht "Reise-Enddatum - Dauer letzte Etappe =
    // Enddatum der letzten Zwischenstation". Nur wenn die letzte Station
    // schon anderweitig verankert ist (Fotos = tatsächlich schon dort
    // angekommen, oder Admin-Override), hat das Vorrang vor dieser Regel.
    const lastIdx = S.stations.length - 1;
    const lastAlreadyAnchored = anchors.some(a => a.idx === lastIdx);
    if (lastIdx >= 0 && !lastAlreadyAnchored) {
        anchors.push({ idx: lastIdx, start: tripEnd, end: tripEnd });
        anchors.sort((a, b) => a.idx - b.idx);
    }

    for (let a = 0; a < anchors.length - 1; a++) {
        const from = anchors[a];
        const to = anchors[a + 1];
        const segmentStations = [];
        for (let i = from.idx + 1; i < to.idx; i++) segmentStations.push(S.stations[i]);

        const segmentStart = from.end || from.date;
        const segmentEnd = to.start || to.date;

        if (!segmentStations.length) continue;

        const totalSpanDays = Math.max(0, daysBetween(segmentStart, segmentEnd));
        const travelDaysTotal = segmentStations.reduce((sum, st, i) => {
            const next = segmentStations[i + 1] || (to.idx < S.stations.length ? S.stations[to.idx] : null);
            return sum + (next ? travelDaysBetween(st, next) : 0);
        }, 0);
        const availableStayDays = Math.max(segmentStations.length, totalSpanDays - travelDaysTotal);

        const stayDaysPerStation = distributeDays(segmentStations, availableStayDays);

        let cursor = new Date(segmentStart);
        segmentStations.forEach((st, i) => {
            const start = new Date(cursor);
            const end = addDays(start, stayDaysPerStation[i]);
            st.stay.suggestedStart = isoDate(start);
            st.stay.suggestedEnd = isoDate(end);

            const next = segmentStations[i + 1] || (to.idx < S.stations.length ? S.stations[to.idx] : null);
            const travel = next ? travelDaysBetween(st, next) : 0;
            cursor = addDays(end, travel);
        });
    }

    // Anker-Stationen selbst: ihr Zeitraum ist der Anker-Zeitraum (Fotos,
    // manuelle Überschreibung, oder das neue Ziel-Ankunftsdatum), nicht das
    // Ergebnis der Verteilung.
    S.stations.forEach((st, idx) => {
        if (st.stay.isManual && st.stay.overrideStart && st.stay.overrideEnd) return;   // schon korrekt via getStayRange
        if (st.stay.isPastLocked) {
            const photoRange = getPhotoRange(st);
            if (photoRange) { st.stay.suggestedStart = photoRange.start; st.stay.suggestedEnd = photoRange.end; }
            return;
        }
        if (idx === lastIdx && !lastAlreadyAnchored) {
            st.stay.suggestedStart = isoDate(tripEnd);
            st.stay.suggestedEnd = isoDate(tripEnd);
        }
    });
}

export function getStayRange(station) {
    if (!station.stay) return null;
    const start = station.stay.isManual && station.stay.overrideStart ? station.stay.overrideStart : station.stay.suggestedStart;
    const end = station.stay.isManual && station.stay.overrideEnd ? station.stay.overrideEnd : station.stay.suggestedEnd;
    if (!start || !end) return null;
    return { start, end, isManual: !!station.stay.isManual, isPastLocked: !!station.stay.isPastLocked };
}

/**
 * Punkt 3 (Validitätsprüfung): vergleicht den gespeicherten Zeitraum gegen
 * die tatsächlichen Foto-Zeitstempel. Liefert einen Warntext, wenn sie nicht
 * zusammenpassen, sonst null. Bei isPastLocked-Stationen ist per Definition
 * kein Mismatch möglich (der Zeitraum WIRD ja aus den Fotos übernommen) -
 * die Prüfung greift also v.a. bei manuell überschriebenen vergangenen
 * Stationen oder bei zukünftigen Stationen, die bereits (unerwartet) Fotos
 * haben, deren Termin aber noch nicht neu berechnet wurde.
 */
export function getStayValidityWarning(station) {
    const photoRange = getPhotoRange(station);
    if (!photoRange) return null;
    const range = getStayRange(station);
    if (!range) return null;
    if (photoRange.start >= range.start && photoRange.end <= range.end) return null;   // Fotos liegen im gespeicherten Zeitraum -> OK

    return `Die Fotos dieser Station stammen vom ${fmtShort(photoRange.start)} bis ${fmtShort(photoRange.end)}, der gespeicherte Zeitraum ist aber ${fmtShort(range.start)} bis ${fmtShort(range.end)}.`;
}

function fmtShort(isoStr) {
    if (!isoStr) return '';
    const d = new Date(isoStr + 'T12:00:00');
    if (isNaN(d)) return '';
    return d.toLocaleDateString('de-DE', { day: '2-digit', month: 'short' });
}

export function renderStayBlock(station) {
    const el = document.getElementById('sp-stay');
    if (!el) return;

    if (!S.trip || !S.trip.startDate || !S.trip.endDate) {
        el.innerHTML = S.isAdmin
            ? `<div class="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded px-2 py-1.5"><i class="fa-solid fa-triangle-exclamation"></i> Kein Reise-Zeitraum hinterlegt. <a href="#" onclick="window.openSettings(); return false;" class="underline font-bold">In Einstellungen ergänzen</a></div>`
            : '';
        return;
    }

    const range = getStayRange(station);
    const warning = getStayValidityWarning(station);
    const warningHtml = warning
        ? ` <i class="fa-solid fa-triangle-exclamation text-amber-500 cursor-help" title="${warning.replace(/"/g, '&quot;')}"></i>`
        : '';

    const lockLabel = range && range.isPastLocked
        ? ' <span class="badge-manual" title="Zeitraum aus den Foto-Zeitstempeln übernommen, bereits besucht - wird bei Routenänderungen nicht überschrieben.">bereits besucht</span>'
        : (range && range.isManual ? ' <span class="badge-manual">manuell</span>' : '');

    const readonlyText = range
        ? `${fmtShort(range.start)} – ${fmtShort(range.end)}${lockLabel}${warningHtml}`
        : '<span class="text-slate-400 italic">wird berechnet…</span>';

    if (!S.isAdmin) {
        el.innerHTML = `<div class="text-sm font-semibold text-slate-700"><i class="fa-regular fa-calendar-days text-indigo-500 mr-1.5"></i>${readonlyText}</div>`;
        return;
    }

    if (range && range.isPastLocked) {
        // Bereits besuchte Station: read-only auch für Admins, kein Override-Formular.
        // (Wer trotzdem manuell korrigieren will/muss, kann das über die Fotos selbst tun -
        // z.B. Zeitstempel eines Fotos korrigieren, siehe Foto-Editor.)
        el.innerHTML = `<div class="text-sm font-semibold text-slate-700"><i class="fa-regular fa-calendar-days text-indigo-500 mr-1.5"></i>${readonlyText}</div>`;
        return;
    }

    const startVal = range ? range.start : '';
    const endVal = range ? range.end : '';
    // F2 FIX: Icon-only Buttons (↻ Zurücksetzen, ✓ Speichern) statt ausgeschriebenem
    // Text, alles kompakt in einer Zeile mit den Datumsfeldern statt eigener Zeile.
    el.innerHTML = `
        <div class="flex items-center gap-1.5 flex-wrap">
            <input type="date" id="stay-start-input" value="${startVal}" min="${S.trip.startDate}" max="${S.trip.endDate}" class="border border-slate-200 rounded px-2 py-1 text-xs">
            <span class="text-slate-400 text-xs">bis</span>
            <input type="date" id="stay-end-input" value="${endVal}" min="${S.trip.startDate}" max="${S.trip.endDate}" class="border border-slate-200 rounded px-2 py-1 text-xs">
            ${range && range.isManual ? `<button onclick="window.clearStationStayOverride('${station.id}')" class="w-7 h-7 flex items-center justify-center text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded shrink-0" title="Zurücksetzen"><i class="fa-solid fa-rotate-left text-xs"></i></button>` : ''}
            <button onclick="window.setStationStayOverride('${station.id}')" class="w-7 h-7 flex items-center justify-center bg-indigo-600 hover:bg-indigo-500 text-white rounded shrink-0" title="Speichern"><i class="fa-solid fa-check text-xs"></i></button>
            ${range && range.isManual ? '<span class="badge-manual">manuell</span>' : ''}
            ${warningHtml}
        </div>
        ${station.stay && station.stay.aiWeightReason ? `<div class="text-[10px] text-slate-400 mt-1"><i class="fa-solid fa-wand-magic-sparkles"></i> ${esc(station.stay.aiWeightReason)}</div>` : ''}
    `;
}

function esc(str) {
    return String(str == null ? '' : str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

window.setStationStayOverride = function(stationId) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === stationId);
    if (!st) return;
    const startVal = document.getElementById('stay-start-input').value;
    const endVal = document.getElementById('stay-end-input').value;
    if (!startVal || !endVal) return showToast('Bitte An- und Abreisedatum angeben.', 'info');
    if (new Date(endVal) < new Date(startVal)) return showToast('Das Abreisedatum liegt vor dem Anreisedatum.', 'info');
    if (S.trip && S.trip.startDate && startVal < S.trip.startDate) return showToast('Das Datum liegt vor dem Reisebeginn.', 'info');
    if (S.trip && S.trip.endDate && endVal > S.trip.endDate) return showToast('Das Datum liegt nach dem Reiseende.', 'info');

    if (!st.stay) st.stay = {};
    st.stay.overrideStart = startVal;
    st.stay.overrideEnd = endVal;
    st.stay.isManual = true;

    recalculateStays();
    S.stations.forEach(s => saveStationToCloud(s));
    updateSidePanel(st.id);
    renderMap();   // Bugfix (Punkt 1): Marker (Wetter-/Datums-Badge) sofort aktualisieren statt auf Firestore-Sync zu warten
};

window.clearStationStayOverride = function(stationId) {
    if (!S.isAdmin) return;
    const st = S.stations.find(s => s.id === stationId);
    if (!st || !st.stay) return;
    st.stay.overrideStart = null;
    st.stay.overrideEnd = null;
    st.stay.isManual = false;

    recalculateStays();
    S.stations.forEach(s => saveStationToCloud(s));
    updateSidePanel(st.id);
    renderMap();   // Bugfix (Punkt 1): siehe setStationStayOverride
};