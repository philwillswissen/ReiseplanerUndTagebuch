/**
 * utils.js – Reine Helferfunktionen
 * ===================================
 * Größtenteils zustandslos (nehmen Eingaben, geben Ausgaben zurück).
 * tripTitle/tripSubtitle/zoomWeight lesen den globalen State (S), da sie an
 * vielen Stellen für Anzeige-Zwecke gebraucht werden.
 */

import { S } from './state.js';

export async function sha256(text) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

export function tripTitle() { return (S.trip && S.trip.name) || 'Reiseplaner'; }

export function tripSubtitle() { return (S.trip && S.trip.subtitle) || ''; }

export function distanceKm(lat1, lng1, lat2, lng2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLng/2)**2;
    return 2 * R * Math.asin(Math.sqrt(a));
}

export function dayKey(timestamp) {
    if (!timestamp) return 'unbekannt';
    const s = String(timestamp);
    // Bugfix 0.2: "Floatender" Zeitstempel ohne Zeitzonen-Angabe (z.B. aus
    // EXIF-Fotodaten, siehe media.js) - Kalendertag direkt aus dem String
    // lesen. NICHT über new Date() + getTimezoneOffset() umrechnen, sonst
    // verschiebt sich der Tag abhängig von der Zeitzone des Betrachters.
    const isFloating = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(s) && !/Z$|[+-]\d{2}:?\d{2}$/.test(s);
    if (isFloating) return s.slice(0, 10);

    const d = new Date(timestamp);
    if (isNaN(d)) return 'unbekannt';
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}

export function dayColor(dayIndex, totalDays) {
    const span = Math.max(1, totalDays - 1);
    const hue = 158 - (dayIndex / span) * 68;   // Türkisgrün -> Gelbgrün
    const light = 30 + (dayIndex / span) * 14;
    return `hsl(${hue}, 72%, ${light}%)`;
}

export function zoomWeight(base) {
    const z = S.map ? S.map.getZoom() : 6;
    return Math.max(2, Math.min(10, base + (z - 6) * 0.7));
}

/**
 * Bugfix (Punkt 4 / Wetter-Overlap): eigene Zoom-Skalierung für Stations-
 * Marker-Icons. zoomWeight() ist für Linienstärken gedacht (Range 2-10) -
 * wurde für die Marker-Größe zweckentfremdet (Aufruf zoomWeight(30)), aber
 * der harte Clamp auf max. 10 hat das effektiv IMMER auf 10 gezackelt,
 * unabhängig vom Zoom. Ergebnis: Marker waren immer nur ~13px groß (10*1.3),
 * viel zu klein für die Wetter-/Datums-Badges, die eine feste Höhe von je
 * 14px mitbringen -> Badges haben das winzige Stations-Icon überdeckt.
 * Eigene Range (22-58px), die tatsächlich mit dem Zoom mitwächst.
 */
export function markerSize(base = 34) {
    const z = S.map ? S.map.getZoom() : 6;
    return Math.round(Math.max(22, Math.min(58, base + (z - 6) * 3)));
}

export function esc(str) {
    return String(str == null ? '' : str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/**
 * Bugfix 0.5b: nicht-blockierende Toast-Benachrichtigung statt alert().
 * alert() friert die ganze Seite ein (schlecht auf Mobile, wirkt wie ein
 * Absturz) und sieht auf jedem Betriebssystem anders/unschön aus.
 *
 * Bewusste Ausnahme (NICHT konvertiert): Mehrzeilige Anleitungen oder
 * Diagnose-Texte, die der Nutzer in Ruhe lesen/kopieren soll (z.B. PWA-
 * Installationsanleitung in main.js, Download-Fehlerdiagnose in media.js) -
 * dort bleibt alert() bewusst bestehen, weil ein autom. verschwindender
 * Toast dafür ungeeignet ist.
 */
let toastTimeout = null;
export function showToast(message, type = 'info') {
    let el = document.getElementById('app-toast');
    if (!el) {
        el = document.createElement('div');
        el.id = 'app-toast';
        document.body.appendChild(el);
    }
    el.className = `app-toast app-toast-${type}`;
    el.innerText = message;
    // Reflow erzwingen, damit die Transition auch bei schnell aufeinander
    // folgenden Toasts (gleiche Klasse) neu antriggert.
    void el.offsetWidth;
    el.classList.add('app-toast-visible');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => el.classList.remove('app-toast-visible'), 3800);
}

/**
 * Punkt 12a: Nicht-blockierender Fortschritts-Indikator für Foto-Uploads.
 * Ersetzt den bisherigen Vollbild-Blocker (#ai-loader, position:absolute
 * inset:0 über der ganzen Karte) für den Upload-Flow - Nutzer kann während
 * des Uploads weiter auf der Karte navigieren, Side Panel wechseln etc.
 * Bleibt bewusst sichtbar bis hideUploadProgress() (kein Auto-Timeout wie
 * beim Toast), da ein laufender Upload potenziell lange dauert.
 */
export function showUploadProgress(total) {
    let el = document.getElementById('upload-progress');
    if (!el) {
        el = document.createElement('div');
        el.id = 'upload-progress';
        el.innerHTML = `
            <i class="fa-solid fa-cloud-arrow-up upload-progress-icon"></i>
            <div class="upload-progress-body">
                <div class="upload-progress-label" id="upload-progress-label">Wird hochgeladen...</div>
                <div class="upload-progress-track"><div class="upload-progress-fill" id="upload-progress-fill"></div></div>
            </div>`;
        document.body.appendChild(el);
    }
    el.classList.add('upload-progress-visible');
    updateUploadProgress(0, total, 'Wird vorbereitet...');
}

export function updateUploadProgress(current, total, label) {
    const fill = document.getElementById('upload-progress-fill');
    const labelEl = document.getElementById('upload-progress-label');
    if (!fill || !labelEl) return;
    const pct = total > 0 ? Math.min(100, Math.round((current / total) * 100)) : 0;
    fill.style.width = pct + '%';
    labelEl.innerText = total > 0 ? `${label} (${current}/${total})` : label;
}

export function hideUploadProgress() {
    const el = document.getElementById('upload-progress');
    if (el) el.classList.remove('upload-progress-visible');
}

export function photoFileName(img, stationName) {
    const d = img.timestamp ? new Date(img.timestamp) : new Date(0);
    const pad = n => String(n).padStart(2, '0');
    const stamp = isNaN(d) || d.getTime() === 0
        ? '00000000_000000'
        : `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
    const safeStation = slugifyName(stationName);
    return `${stamp}_${safeStation}.jpg`;
}

export function slugifyName(name) {
    return String(name || 'Station')
        .replace(/[äÄ]/g, 'ae').replace(/[öÖ]/g, 'oe').replace(/[üÜ]/g, 'ue').replace(/ß/g, 'ss')
        .replace(/[øØ]/g, 'oe').replace(/[åÅ]/g, 'aa').replace(/[æÆ]/g, 'ae')
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-zA-Z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .slice(0, 60) || 'Station';
}

export async function getImageBase64(img) {
    if (img.data) {
        return img.data.split(',')[1] || null;
    }
    if (img.url) {
        const res = await fetch(img.url);
        if (!res.ok) throw new Error(`Bild-Download fehlgeschlagen (${res.status})`);
        const blob = await res.blob();
        return await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result.split(',')[1]);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }
    return null;
}

export function toggleLoader(show, text = "") {
    const l = document.getElementById('ai-loader');
    document.getElementById('ai-loader-text').innerText = text;
    show ? l.classList.add('active') : l.classList.remove('active');
}

export function fmtDate(d, opts) {
    return d ? d.toLocaleDateString('de-DE', opts || { day: '2-digit', month: 'long', year: 'numeric' }) : '';
}

/**
 * Bugfix 0.1: Liefert die beste verfügbare Bildquelle für ein Foto-Objekt.
 * Deckt sowohl das aktuelle Datenmodell (thumbUrl/url) als auch ältere/
 * abweichende Feldnamen ab, die in historischen Firestore-Daten vorkommen
 * können (photoUrl, imageUrl, src, downloadUrl). Gibt null zurück, wenn
 * wirklich keine Quelle auflösbar ist - dafür zeigt renderImageGrid/
 * openGlobalGallery dann einen sichtbaren Platzhalter statt eines leeren
 * Containers.
 */
export function resolvePhotoSrc(img, preferThumb = true) {
    if (!img) return null;
    const candidates = preferThumb
        ? [img.thumbUrl, img.url, img.data, img.photoUrl, img.imageUrl, img.downloadUrl, img.src]
        : [img.url, img.data, img.thumbUrl, img.photoUrl, img.imageUrl, img.downloadUrl, img.src];
    for (const c of candidates) {
        if (typeof c === 'string' && c.trim() !== '') return c;
    }
    return null;
}
