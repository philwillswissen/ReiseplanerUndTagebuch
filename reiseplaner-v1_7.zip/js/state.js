/**
 * state.js – Zentraler Anwendungs-State
 * ======================================
 * Alle Module importieren dieses eine Objekt `S` und lesen/schreiben
 * seine Properties direkt (S.stations.push(...), S.currentStationId = id, ...).
 *
 * Warum ein Objekt statt einzelner `export let`-Variablen?
 * ES-Module unterstützen zwar "live bindings" bei reexportierten `let`-Variablen,
 * aber sobald eine Variable komplett neu zugewiesen wird (z.B. `stations = [...]`
 * beim Neuladen der Firestore-Daten), müsste jedes importierende Modul das explizit
 * nachverfolgen. Ein einziges mutierbares Objekt ist robuster, einfacher zu debuggen
 * (ein Blick in die Konsole: `console.log(S)` zeigt den kompletten App-State) und
 * verträgt sich sauber mit den zirkulären Abhängigkeiten zwischen map.js/stations.js/etc.
 */

export const S = {
    // Firebase / Cloud
    map: null,
    db: null,
    storage: null,
    currentUser: null,

    // Stationen & aktuelle Auswahl
    stations: [],
    currentStationId: null,
    selectedSearchResult: null,
    searchTimeout: null,
    todoSortable: null,

    // Mehrere Reisen
    trips: [],
    trip: null,
    tripId: localStorage.getItem('active_trip_id') || 'skandinavien-2026',
    stationsUnsub: null,
    tripsUnsub: null,
    hasFittedMap: false,
    stayOverflowWarning: false,

    // Karten-Layer-Sichtbarkeit (Punkt: Layer-Toggles)
    showPois: JSON.parse(localStorage.getItem('skand_show_pois') ?? 'true'),
    showWeather: JSON.parse(localStorage.getItem('skand_show_weather') ?? 'true'),
    showStayDates: JSON.parse(localStorage.getItem('skand_show_stay_dates') ?? 'false'),

    // Zugriffsrechte
    isAdmin: false,
    hasViewAccess: false,
    previewMode: false, // F4: Admin ist eingeloggt, sieht aber die Nicht-Admin-Ansicht
    apiKey: "",
    aiStyle: "Schreibe einen lebendigen, atmosphärischen Reiseblog-Eintrag für eine Familie.",

    // Spracheingabe
    recognition: null,
    isRecording: false
};

// Konstanten (ändern sich nie, kein State im eigentlichen Sinn, aber zentral gehalten)
export const appId = 'skand-v4-opt6-final';
export const LEGACY_TRIP_ID = 'skandinavien-2026';
export const DEFAULT_AI_STYLE = "Schreibe einen lebendigen, atmosphärischen Reiseblog-Eintrag für eine Familie.";

export const firebaseConfig = {
    apiKey: "AIzaSyAvqkAuY6PQGHkHC0dO11i_f6674IxCzyo",
    authDomain: "reiseplaner2.firebaseapp.com",
    projectId: "reiseplaner2",
    storageBucket: "reiseplaner2.firebasestorage.app",
    messagingSenderId: "657701775714",
    appId: "1:657701775714:web:dbe5346b0eb6c29288243b"
};

export const tripKey = (suffix) => `trip_${S.tripId}_${suffix}`;
export const tripKeyFor = (id, suffix) => `trip_${id}_${suffix}`;
