/**
 * map.js – Leaflet-Kartenrendering (Marker, Routenlinien, Zeitleiste)
 * ======================================================================
 * Modul-privater State (mapLayers, photoLayers, timelineDayIndex, etc.):
 * wird nur innerhalb dieser Datei gebraucht, daher keine Aufnahme in S.
 */

import { S } from './state.js';
import { distanceKm, dayKey, dayColor, zoomWeight, markerSize } from './utils.js';
import { pvOpen, pvPhotos, pvIndex } from './media.js';
import { recalculateStays, getStayRange, ensureStayWeights } from './duration.js';
import { renderSegmentLines, ensureSegmentInfo } from './segments.js';
import { getMarkerWeatherBadge, ensureWeather } from './weather.js';
import { renderPoiMarkers, initPoiClickHandler, revalidatePois } from './pois.js';
import { ensurePoiSuggestions, renderPoiSuggestionsBadge } from './poi-suggestions.js';
import { ensureAllRoutePolylines } from './routing.js';
import { ensurePlaceLinks } from './place-links.js';

const VISITED_RADIUS_KM = 20;
const PHOTO_IMAGE_MAX = 2;   // Bilder erst zeigen, wenn höchstens so viele Punkte sichtbar sind

let mapLayers = [];
let stationMarkerLayers = [];
let lastRouteSignature = null;
let photoLayers = [];
let lastChronoPhotos = [];
let lastTravelDays = [];
let photoRenderTimer = null;
let scaledLines = [];   // {layer, base} - für schnelles Anpassen beim Zoomen
let timelineDayIndex = null;   // null = gesamte Reise anzeigen
let timelinePlayTimer = null;

export function fitMapToStations() {
    if (!S.map || S.hasFittedMap || !S.stations.length) return;
    S.hasFittedMap = true;
    try { S.map.fitBounds(L.latLngBounds(S.stations.map(s => [s.lat, s.lng])).pad(0.2)); } catch(e) {}
}

export function updateTripProgress() {
    const wrap = document.getElementById('trip-progress');
    if (!wrap || !S.stations.length) return;
    const photos = getAllPhotosChronological();
    if (!photos.length) { wrap.classList.add('hidden'); return; }

    const lastIdx = getLastVisitedStationIndex(photos);
    const total = Math.max(S.stations.length - 1, 1);
    const pct = Math.round((Math.max(lastIdx, 0) / total) * 100);

    wrap.classList.remove('hidden');
    document.getElementById('trip-progress-bar').style.width = pct + '%';
    const days = getTravelDays(photos).length;
    document.getElementById('trip-progress-label').innerText =
        `${pct}% der Route · ${days} Reisetag${days === 1 ? '' : 'e'} · ${photos.length} Fotos`;
}

export function getTravelDays(photoList) {
    const keys = [...new Set(photoList.map(p => dayKey(p.img.timestamp)))];
    keys.sort();
    return keys;
}

export function getAllPhotosChronological() {
    const all = [];
    S.stations.forEach(st => {
        (st.images || []).forEach((img, idx) => {
            if (img.lat && img.lng) {
                all.push({ img, station: st, indexInStation: idx });
            }
        });
    });
    all.sort((a, b) => new Date(a.img.timestamp || 0) - new Date(b.img.timestamp || 0));
    return all;
}

export function isStationVisited(st, photoList) {
    const all = photoList || getAllPhotosChronological();
    return all.some(p => distanceKm(st.lat, st.lng, p.img.lat, p.img.lng) <= VISITED_RADIUS_KM);
}

export function getLastVisitedStationIndex(photoList) {
    const all = photoList || getAllPhotosChronological();
    let last = -1;
    S.stations.forEach((st, idx) => { if (isStationVisited(st, all)) last = idx; });
    return last;
}

export function initMap() {
    S.map = L.map('map', { zoomControl: false, preferCanvas: true }).setView([56.0, 11.0], 5);
    L.control.zoom({ position: 'topleft' }).addTo(S.map);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OSM' }).addTo(S.map);
    S.map.on('zoomend', () => { updateLineWeights(); schedulePhotoRender(); renderStationMarkers(); });
    S.map.on('moveend', () => schedulePhotoRender());
    initPoiClickHandler();
    updateLayerToggleButtons();
    renderMap();
}

function updateLayerToggleButtons() {
    const map = { showWeather: 'layer-toggle-weather', showPois: 'layer-toggle-pois', showStayDates: 'layer-toggle-staydates' };
    Object.entries(map).forEach(([key, id]) => {
        const btn = document.getElementById(id);
        if (btn) btn.classList.toggle('layer-active', !!S[key]);
    });
}

const LAYER_STORAGE_KEYS = {
    showWeather: 'skand_show_weather',
    showPois: 'skand_show_pois',
    showStayDates: 'skand_show_stay_dates'
};

window.toggleMapLayer = function(key) {
    S[key] = !S[key];
    localStorage.setItem(LAYER_STORAGE_KEYS[key], JSON.stringify(S[key]));
    updateLayerToggleButtons();
    renderMap();
};

function updateTimelineUI(travelDays) {
    const bar = document.getElementById('timeline-bar');
    if (!bar) return;

    if (travelDays.length < 2) { bar.classList.add('hidden'); return; }
    bar.classList.remove('hidden');

    const slider = document.getElementById('tl-slider');
    slider.max = travelDays.length - 1;
    const idx = (timelineDayIndex === null) ? travelDays.length - 1 : timelineDayIndex;
    slider.value = idx;

    const dayStr = travelDays[idx];
    const label = document.getElementById('tl-label');
    const pretty = dayStr === 'unbekannt'
        ? 'Ohne Datum'
        : new Date(dayStr + 'T12:00:00').toLocaleDateString('de-DE', { weekday: 'short', day: '2-digit', month: 'short' });

    label.innerText = (timelineDayIndex === null)
        ? `Gesamte Reise · ${travelDays.length} Tage`
        : `Tag ${idx + 1}/${travelDays.length} · bis ${pretty}`;

    document.getElementById('tl-all').style.opacity = (timelineDayIndex === null) ? '0.4' : '1';
}

window.onTimelineSlide = function(val) {
    stopTimelinePlay();
    timelineDayIndex = parseInt(val, 10);
    renderMap();
};

window.setTimelineAll = function() {
    stopTimelinePlay();
    timelineDayIndex = null;
    renderMap();
};

function stopTimelinePlay() {
    if (timelinePlayTimer) {
        clearInterval(timelinePlayTimer);
        timelinePlayTimer = null;
        const icon = document.querySelector('#tl-play i');
        if (icon) icon.className = 'fa-solid fa-play text-xs';
    }
}

window.toggleTimelinePlay = function() {
    if (timelinePlayTimer) return stopTimelinePlay();

    const days = getTravelDays(getAllPhotosChronological());
    if (days.length < 2) return;

    timelineDayIndex = 0;
    renderMap();
    document.querySelector('#tl-play i').className = 'fa-solid fa-pause text-xs';

    timelinePlayTimer = setInterval(() => {
        if (timelineDayIndex === null || timelineDayIndex >= days.length - 1) {
            stopTimelinePlay();
            timelineDayIndex = null;
            renderMap();
            return;
        }
        timelineDayIndex++;
        renderMap();
    }, 1400);
};

function updateLineWeights() {
    scaledLines.forEach(item => {
        item.layer.setStyle({ weight: zoomWeight(item.base) });
    });
}

export function renderPhotoMarkers() {
    if (!S.map) return;
    photoLayers.forEach(l => S.map.removeLayer(l));
    photoLayers = [];

    const bounds = S.map.getBounds();
    const visible = [];
    lastChronoPhotos.forEach((p, i) => {
        if (bounds.contains([p.img.lat, p.img.lng])) visible.push({ p, i });
    });

    const showImages = visible.length > 0 && visible.length <= PHOTO_IMAGE_MAX;

    lastChronoPhotos.forEach((p, i) => {
        const dIdx = lastTravelDays.indexOf(dayKey(p.img.timestamp));
        const color = dayColor(Math.max(dIdx, 0), lastTravelDays.length);
        const isVisible = bounds.contains([p.img.lat, p.img.lng]);
        const isActive = pvOpen && pvPhotos[pvIndex] && pvPhotos[pvIndex].img === p.img;

        let layer;
        if (showImages && isVisible) {
            const src = p.img.thumbUrl || p.img.url || p.img.data;
            const icon = L.divIcon({
                className: '',
                html: `<div class="photo-marker ${isActive ? 'photo-marker-active' : ''}" style="width:34px;height:34px;background-image:url('${src}')"></div>`,
                iconSize: [34,34], iconAnchor: [17,17]
            });
            layer = L.marker([p.img.lat, p.img.lng], { icon, zIndexOffset: 0 }).addTo(S.map);
        } else {
            // Unsichtbare, großzügige Trefferfläche für bequemes Antippen
            const hit = L.circleMarker([p.img.lat, p.img.lng], {
                radius: 18, opacity: 0, fillOpacity: 0.001,
                fillColor: '#000', interactive: true
            }).addTo(S.map);
            hit.on('click', (e) => {
                L.DomEvent.stopPropagation(e);
                window.openPhotoViewer(i, lastChronoPhotos);
            });
            photoLayers.push(hit);

            layer = L.circleMarker([p.img.lat, p.img.lng], {
                radius: isActive ? 10 : 7,
                color: isActive ? '#f59e0b' : '#fff',
                weight: isActive ? 3 : 2.5,
                fillColor: color, fillOpacity: 1
            }).addTo(S.map);
        }

        layer.on('click', (e) => {
            L.DomEvent.stopPropagation(e);
            window.openPhotoViewer(i, lastChronoPhotos);
        });
        photoLayers.push(layer);
    });
}

export function schedulePhotoRender() {
    clearTimeout(photoRenderTimer);
    photoRenderTimer = setTimeout(renderPhotoMarkers, 180);
}

/**
 * Zeichnet die Stations-Marker. Eigenständige Funktion (statt inline in
 * renderMap), damit sie auch bei reinem Zoomen neu aufgerufen werden kann -
 * vorher blieben die Marker beim Zoomen in fester Pixelgröße stehen, während
 * Routenlinien und Fotomarker mitskalierten. Nutzt zoomWeight() wie die
 * Routenlinien für eine konsistente, zoomabhängige Größe.
 */
export function renderStationMarkers(chronoPhotosOverride) {
    if (!S.map) return;
    stationMarkerLayers.forEach(l => S.map.removeLayer(l));
    stationMarkerLayers = [];

    const chronoPhotos = chronoPhotosOverride || lastChronoPhotos;
    const size = markerSize();   // Bugfix: eigene Zoom-Skalierung statt zoomWeight() (siehe utils.js)

    const seenCoords = {};
    const markerPos = S.stations.map(st => {
        const key = `${st.lat.toFixed(3)},${st.lng.toFixed(3)}`;
        const n = seenCoords[key] || 0;
        seenCoords[key] = n + 1;
        if (n === 0) return [st.lat, st.lng];
        const angle = (n * 2.4);
        const r = 0.085 + n * 0.02;
        return [st.lat + Math.sin(angle) * r * 0.6, st.lng + Math.cos(angle) * r];
    });

    S.stations.forEach((st, idx) => {
        const visited = isStationVisited(st, chronoPhotos);
        let bg = visited ? '#16a34a' : '#2563eb';
        if (idx === 0 || idx === S.stations.length - 1) bg = '#e11d48';

        const label = (idx === 0 || idx === S.stations.length - 1) ? '⌂' : idx.toString();
        const photoCount = (st.images || []).length;
        const badge = photoCount ? `<span class="station-badge">${photoCount > 99 ? '99+' : photoCount}</span>` : '';

        let wxBadge = '';
        if (S.showWeather) {
            const wx = getMarkerWeatherBadge(st);
            if (wx && wx.days.length) {
                // Mehrere Tage (bis zu 3) nebeneinander statt nur Ankunftstag,
                // siehe Nutzer-Feedback "es soll das Wetter für zumindest die
                // ersten 3 Tage gezeigt werden". Klick öffnet externen
                // Wetterdienst (Punkt 0.3b, jetzt auch auf der Karte) -
                // stopPropagation, damit nicht zusätzlich das Side Panel aufgeht.
                const weatherUrl = `https://www.google.com/search?q=wetter+${wx.lat},${wx.lng}`;
                const dayCells = wx.days.map(d => {
                    const dayLabel = new Date(d.date + 'T12:00:00').toLocaleDateString('de-DE', { weekday: 'short' });
                    return `<span class="wx-day-cell" title="Wetter am ${dayLabel}${d.isExact ? '' : ', nächstgelegener verfügbarer Tag'}"><i class="fa-solid ${d.icon} ${d.colorClass}"></i>${d.tempMax}°</span>`;
                }).join('');
                wxBadge = `<a href="${weatherUrl}" target="_blank" onclick="event.stopPropagation();" class="station-weather-badge" style="width:${wx.days.length * 26}px;">${dayCells}</a>`;
            }
            ensureWeather(st, () => renderStationMarkers());
        }

        let stayBadge = '';
        if (S.showStayDates) {
            const range = getStayRange(st);
            if (range) {
                const fmt = iso => new Date(iso + 'T12:00:00').toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' });
                stayBadge = `<span class="station-stay-badge">${fmt(range.start)}–${fmt(range.end)}</span>`;
            }
        }
        const extraHeight = (wxBadge ? 17 : 0) + (stayBadge ? 14 : 0);

        const icon = L.divIcon({
            className: '',
            html: `<div class="station-marker-wrap" style="width:${size}px;height:${size + extraHeight}px;">
                     ${stayBadge}
                     <div class="station-marker" style="background:${bg};width:${size}px;height:${size}px;font-size:${Math.max(9, size * 0.36)}px;margin-top:${stayBadge ? 14 : 0}px;">${label}${badge}</div>
                     ${wxBadge}
                   </div>`,
            iconSize: [size, size + extraHeight], iconAnchor: [size / 2, size / 2 + (stayBadge ? 14 : 0)]
        });

        const pos = markerPos[idx];
        const marker = L.marker(pos, { icon, zIndexOffset: 1000 + idx }).addTo(S.map);
        marker.on('click', () => window.openSidePanel(st.id));
        stationMarkerLayers.push(marker);

        if (pos[0] !== st.lat || pos[1] !== st.lng) {
            const leader = L.polyline([[st.lat, st.lng], pos], {
                color: '#64748b', weight: 1.5, opacity: 0.55, dashArray: '3,3'
            }).addTo(S.map);
            stationMarkerLayers.push(leader);
        }
    });
}

export function renderMap() {
    if (!S.map) return;

    // Routen-Topologie-Änderung erkennen (Station hinzugefügt/gelöscht/verschoben) -
    // nur DANN die POIs revalidieren, nicht bei jedem Render (z.B. Foto-Upload,
    // Wetter-Update), sonst unnötige Firestore-Schreibzugriffe und "POI-Springen".
    const routeSignature = S.stations.map(s => s.id).join('|');
    if (lastRouteSignature !== null && routeSignature !== lastRouteSignature) {
        const poiResult = revalidatePois();
        if (poiResult.removed > 0) {
            const el = document.getElementById('sync-status');
            if (el) {
                const prevHtml = el.innerHTML;
                el.innerHTML = `<i class="fa-solid fa-star text-amber-400"></i> ${poiResult.removed} Sehenswürdigkeit${poiResult.removed === 1 ? '' : 'en'} nicht mehr auf der Route entfernt`;
                setTimeout(() => { el.innerHTML = prevHtml; }, 4000);
            }
        }
    }
    lastRouteSignature = routeSignature;

    ensureStayWeights(() => renderMap());   // KI-Gewichtung für neue Stationen im Hintergrund nachladen, dann neu rendern
    recalculateStays();   // Punkt 4: Vorschläge aktuell halten, sobald sich an der Route etwas ändert
    const warnEl = document.getElementById('stay-overflow-warning');
    if (warnEl) warnEl.classList.toggle('hidden', !S.stayOverflowWarning);
    mapLayers.forEach(l => S.map.removeLayer(l));
    mapLayers = [];
    scaledLines = [];

    const allPhotos = getAllPhotosChronological();
    const travelDays = getTravelDays(allPhotos);

    // Zeitleisten-Filter anwenden
    const visibleDays = (timelineDayIndex === null)
        ? travelDays
        : travelDays.slice(0, timelineDayIndex + 1);
    const chronoPhotos = allPhotos.filter(p => visibleDays.includes(dayKey(p.img.timestamp)));

    updateTimelineUI(travelDays);

    const lastVisitedIdx = getLastVisitedStationIndex(chronoPhotos);

    // ---- 1. PLANROUTE: nur noch offene Abschnitte, deutlich grau ----
    const plannedPath = [];
    S.stations.forEach((st, idx) => {
        if (idx >= Math.max(lastVisitedIdx, 0)) plannedPath.push([st.lat, st.lng]);
    });
    if (plannedPath.length > 1) {
        const planLine = L.polyline(plannedPath, {
            color: '#64748b', weight: zoomWeight(7), opacity: 0.85, dashArray: '14, 10', lineCap: 'round'
        }).addTo(S.map);
        mapLayers.push(planLine);
        scaledLines.push({ layer: planLine, base: 7 });
    }

    // ---- 2. TATSÄCHLICHE ROUTE: pro Reisetag ein eigener Grünton ----
    // Segmente gleicher Farbe werden zusammengefasst -> deutlich weniger Layer
    if (chronoPhotos.length > 0 && S.stations.length > 0) {
        let prev = [S.stations[0].lat, S.stations[0].lng];
        let currentColor = null;
        let buffer = [prev];

        const flush = () => {
            if (buffer.length > 1 && currentColor) {
                const seg = L.polyline(buffer, {
                    color: currentColor, weight: zoomWeight(5), opacity: 0.95,
                    lineJoin: 'round', lineCap: 'round'
                }).addTo(S.map);
                mapLayers.push(seg);
                scaledLines.push({ layer: seg, base: 5 });
            }
        };

        chronoPhotos.forEach(p => {
            const cur = [p.img.lat, p.img.lng];
            const dIdx = travelDays.indexOf(dayKey(p.img.timestamp));
            const color = dayColor(Math.max(dIdx, 0), travelDays.length);

            if (currentColor === null) {
                currentColor = color;
            } else if (color !== currentColor) {
                flush();
                buffer = [prev];
                currentColor = color;
            }
            buffer.push(cur);
            prev = cur;
        });
        flush();
    }

    // ---- 3. STATIONS-MARKER (eigene Funktion, s.u. renderStationMarkers) ----
    renderStationMarkers(chronoPhotos);

    // ---- 4. FOTO-MARKER (separat, viewport-abhängig) ----
    lastChronoPhotos = chronoPhotos;
    lastTravelDays = travelDays;
    renderPhotoMarkers();
    updateTripProgress();

    // ---- 5. ETAPPEN (klickbare Hitbox-Linien mit Info-Popup, Punkt 6) ----
    ensureSegmentInfo();   // befüllt fehlende Etappen automatisch per KI im Hintergrund
    renderSegmentLines();

    // ---- 5b. STRASSENROUTEN (für POI-Platzierung entlang der echten Route statt Luftlinie) ----
    ensureAllRoutePolylines();

    // ---- 6. POI-MARKER entlang der Strecke (Punkt 8) ----
    renderPoiMarkers();

    // ---- 7. KI-POI-VORSCHLÄGE (Punkt 8b) ----
    ensurePoiSuggestions();   // befüllt fehlende Vorschläge automatisch per KI im Hintergrund (nur Admin)
    renderPoiSuggestionsBadge();

    // ---- 8. GOOGLE-MAPS-LINKS für ToDos/Aktivitäten/Campingplätze ----
    ensurePlaceLinks();   // befüllt fehlende Links automatisch per KI im Hintergrund (nur Admin, max. 1 Station gleichzeitig)
}
