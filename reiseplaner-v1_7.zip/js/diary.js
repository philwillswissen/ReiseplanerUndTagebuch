/**
 * diary.js – Reisetagebuch: Blog-Generierung (KI), Magazin-Layout, Export/Druck
 */

import { S, tripKey } from './state.js';
import { esc, dayKey, distanceKm, fmtDate, slugifyName, toggleLoader, tripTitle, tripSubtitle, getImageBase64, showToast } from './utils.js';
import { getAllPhotosChronological, getTravelDays } from './map.js';
import { parseMarkdown, updateSidePanel } from './stations.js';
import { getStayRange } from './duration.js';
import { saveStationToCloud } from './firebase.js';
import { callGemini, getGeminiErrorMessage } from './gemini.js';

window.generateBlogEntry = async function() {
    if(!S.isAdmin) return;
    if(!S.currentStationId) return;
    const st = S.stations.find(s => s.id === S.currentStationId);
    
    if(!st.notes && (!st.todos || st.todos.length === 0) && (!st.images || st.images.length === 0)) {
        showToast("Bitte erfasse zuerst Notizen, To-Dos oder lade Fotos hoch.", 'info');
        return;
    }

    const todoContext = (st.todos || []).map(t => `- ${t.text} [Status: ${t.done ? 'Erledigt' : 'Offen'}]`).join('\n');
    const styleContext = localStorage.getItem('ai_style_instruction') || "Schreibe einen lebendigen, atmosphärischen Reiseblog-Eintrag für eine Familie.";

    toggleLoader(true, "Generiere Text...");
    try {
        if (!S.apiKey || S.apiKey.trim() === "") throw new Error("API Key fehlt in den Einstellungen.");

        const promptText = `System-Anweisung für den Schreibstil: ${styleContext}

Generiere einen Eintrag (ca. 2 Absätze) über die Station "${st.name}".
Verwebe folgende gesammelte Daten aktiv in den Text:

1. Notizen / Rohtext:
${st.notes || 'Keine Notizen angegeben'}

2. To-Dos (erledigte und offene Punkte):
${todoContext || 'Keine To-Dos'}

3. Die angehängten Fotos (analysiere die visuellen Eindrücke der Fotos und beziehe dich direkt darauf!).

WICHTIGE FORMATIERUNG:
- Nutze Emojis passend zum Kontext.
- Formatiere wichtige Begriffe und Highlights zwingend **fett** (mittels Markdown).
- Verwende Absätze oder unformatierte Aufzählungszeichen (Spiegelstriche) um den Text optisch ansprechend und lesefreundlich zu strukturieren.
- Gib NUR den reinen generierten Text des Eintrags aus, OHNE Code-Blöcke oder einleitende Sätze.`;

        const parts = [{ text: promptText }];
        if (st.images && st.images.length > 0) {
            for (const img of st.images) {
                try {
                    const base64Data = await getImageBase64(img);
                    if (base64Data) {
                        parts.push({
                            inline_data: {
                                mime_type: "image/jpeg",
                                data: base64Data
                            }
                        });
                    }
                } catch(err) {
                    console.warn('Konnte Foto nicht für KI-Analyse laden:', err);
                }
            }
        }

        // ✅ BUG-2 FIX: callGemini() mit multimodalem parts-Array (Text+Fotos) und Retry bei 429/503
        let resultText = await callGemini(parts, {
            onRetry: (attempt, max) => toggleLoader(true, `KI-Dienst ausgelastet – erneuter Versuch ${attempt}/${max}...`)
        });
        resultText = resultText.trim().replace(/^["']|["']$/g, '');

        st.blogEntry = resultText;
        saveStationToCloud(st);
        updateSidePanel(st.id);

    } catch(e) {
        // ✅ BUG-3 FIX: verständliche deutsche Meldung statt rohem API-Fehlerobjekt
        console.error('Blog-Text-Generierung fehlgeschlagen für', st.name, e);
        showToast(getGeminiErrorMessage(e), 'error');
    }
    toggleLoader(false);
};

export function diaryStats() {
    const photos = getAllPhotosChronological();
    const days = getTravelDays(photos);
    let km = 0;
    for (let i = 1; i < S.stations.length; i++) {
        km += distanceKm(S.stations[i-1].lat, S.stations[i-1].lng, S.stations[i].lat, S.stations[i].lng);
    }
    const dates = photos.map(p => new Date(p.img.timestamp)).filter(d => !isNaN(d));
    return {
        stations: Math.max(S.stations.length - 1, 0),
        photos: photos.length,
        days: days.length,
        km: Math.round(km),
        from: dates.length ? new Date(Math.min(...dates)) : null,
        to: dates.length ? new Date(Math.max(...dates)) : null
    };
}

export function figureHtml(img, station, wide) {
    const src = img.url || img.data;
    if (!src) return '';
    const d = img.timestamp ? new Date(img.timestamp) : null;
    const time = d && !isNaN(d)
        ? d.toLocaleString('de-DE', { weekday: 'short', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
        : '';
    const place = (img.geoSource === 'exif' || img.geoSource === 'takeout' || img.geoSource === 'manual' || img.geoSource === 'live')
        ? `${img.lat.toFixed(3)}, ${img.lng.toFixed(3)}` : '';
    const cap = [time, place].filter(Boolean).join(' · ');
    return `<figure class="ph ${wide ? 'ph-wide' : ''}">
        <img src="${esc(src)}" alt="${esc(station.name)}" loading="lazy">
        ${cap ? `<figcaption>${esc(cap)}</figcaption>` : ''}
    </figure>`;
}

export function splitBlogBlocks(html) {
    if (!html) return [];
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    return Array.from(tmp.children).map(el => el.outerHTML);
}

export function buildLocatorMap(allStations, currentIdx) {
    if (!allStations.length) return '';
    const lats = allStations.map(s => s.lat), lngs = allStations.map(s => s.lng);
    const latMin = Math.min(...lats), latMax = Math.max(...lats);
    const lngMin = Math.min(...lngs), lngMax = Math.max(...lngs);
    const latPad = (latMax - latMin) * 0.18 || 1.2;
    const lngPad = (lngMax - lngMin) * 0.18 || 1.2;
    const bLatMin = latMin - latPad, bLatMax = latMax + latPad;
    const bLngMin = lngMin - lngPad, bLngMax = lngMax + lngPad;

    const W = 168, H = 122, PAD = 14;
    const midLat = (bLatMin + bLatMax) / 2;
    const cosLat = Math.max(Math.cos(midLat * Math.PI / 180), 0.35);
    const dLng = Math.max((bLngMax - bLngMin) * cosLat, 0.001);
    const dLat = Math.max(bLatMax - bLatMin, 0.001);
    const scale = Math.min((W - 2 * PAD) / dLng, (H - 2 * PAD) / dLat);
    const cLng = (bLngMin + bLngMax) / 2, cLat = (bLatMin + bLatMax) / 2;

    const project = (lat, lng) => [
        W / 2 + (lng - cLng) * cosLat * scale,
        H / 2 - (lat - cLat) * scale
    ];

    const pts = allStations.map(s => project(s.lat, s.lng));
    const pathD = pts.map((p, i) => (i === 0 ? 'M' : 'L') + p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');

    const dots = allStations.map((s, i) => {
        const [x, y] = pts[i];
        if (i === currentIdx) {
            return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="9" fill="none" stroke="#d8a13a" stroke-width="1.2" opacity="0.45"/>
                    <circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5" fill="#d8a13a" stroke="#fdfbf7" stroke-width="2"/>`;
        }
        return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="2.4" fill="#14584a" opacity="0.5"/>`;
    }).join('');

    return `<svg class="locator-map" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Lage von ${esc(allStations[currentIdx].name)} auf der Reiseroute">
        <rect x="0.5" y="0.5" width="${W-1}" height="${H-1}" rx="12" fill="#f2ede3" stroke="#ddd0b4"/>
        <path d="${pathD}" fill="none" stroke="#9fb3a9" stroke-width="1.1" stroke-dasharray="2.2,2.6"/>
        ${dots}
        <text x="${W-11}" y="16" text-anchor="end" font-size="7.5" fill="#a8934f" font-family="Inter, sans-serif" font-weight="600">N ↑</text>
    </svg>`;
}

export function extractDateFromHeading(htmlBlock, referenceYear) {
    const text = htmlBlock.replace(/<[^>]+>/g, ' ');
    const m = text.match(/(\d{1,2})\.\s*(\d{1,2})\.(\s*(\d{4}))?/);
    if (!m) return null;
    const day = parseInt(m[1], 10), month = parseInt(m[2], 10);
    const year = m[4] ? parseInt(m[4], 10) : referenceYear;
    if (!day || !month || month > 12 || day > 31) return null;
    const pad = n => String(n).padStart(2, '0');
    return `${year}-${pad(month)}-${pad(day)}`;
}

export function buildStationChapter(st, idx) {
    const isEndpoint = (idx === 0 || idx === S.stations.length - 1);
    const chapterNo = isEndpoint ? (idx === 0 ? 'Start' : 'Ziel') : String(idx);

    const photos = (st.images || []).slice().sort(
        (a, b) => new Date(a.timestamp || 0) - new Date(b.timestamp || 0)
    );

    const dates = photos.map(p => new Date(p.timestamp)).filter(d => !isNaN(d));
    const refYear = dates.length ? new Date(Math.min(...dates)).getFullYear() : new Date().getFullYear();

    const stayRange = getStayRange(st);
    const dateLabel = stayRange
        ? (fmtDate(new Date(stayRange.start + 'T12:00:00'), { day: '2-digit', month: 'short' }) ===
           fmtDate(new Date(stayRange.end + 'T12:00:00'), { day: '2-digit', month: 'short' })
            ? fmtDate(new Date(stayRange.start + 'T12:00:00'))
            : `${fmtDate(new Date(stayRange.start + 'T12:00:00'), { day: '2-digit', month: 'short' })} – ${fmtDate(new Date(stayRange.end + 'T12:00:00'))}`)
        : (dates.length
            ? (fmtDate(new Date(Math.min(...dates)), { day: '2-digit', month: 'short' }) ===
               fmtDate(new Date(Math.max(...dates)), { day: '2-digit', month: 'short' })
                ? fmtDate(new Date(Math.min(...dates)))
                : `${fmtDate(new Date(Math.min(...dates)), { day: '2-digit', month: 'short' })} – ${fmtDate(new Date(Math.max(...dates)))}`)
            : '');

    const doneTodos = (st.todos || []).filter(t => t.done);
    const experiences = doneTodos.length
        ? `<div class="exp"><span class="exp-label">Was wir erlebt haben</span>
             <ul>${doneTodos.map(t => `<li>${esc(t.text)}</li>`).join('')}</ul>
           </div>` : '';

    const blocks = splitBlogBlocks(st.blogEntry ? parseMarkdown(st.blogEntry) : '');

    const byDay = {};
    photos.forEach(im => {
        const k = dayKey(im.timestamp);
        (byDay[k] = byDay[k] || []).push(im);
    });

    let body = '';
    const hero = photos[0];
    const usedInline = new Set();
    if (hero) { body += figureHtml(hero, st, true); usedInline.add(hero); }
    if (experiences) body += experiences;

    if (blocks.length) {
        let activeDay = null;
        let pendingForDay = [];

        blocks.forEach(b => {
            const isHeading = /^<h[23]/i.test(b.trim());
            if (isHeading) {
                const d = extractDateFromHeading(b, refYear);
                if (d) {
                    activeDay = d;
                    pendingForDay = (byDay[d] || []).filter(im => !usedInline.has(im));
                } else {
                    pendingForDay = [];
                }
                body += b;
                return;
            }

            body += b;

            if (activeDay && pendingForDay.length) {
                const take = pendingForDay.splice(0, 2);
                take.forEach(im => usedInline.add(im));
                if (take.length === 2) {
                    body += `<div class="ph-duo">${figureHtml(take[0], st)}${figureHtml(take[1], st)}</div>`;
                } else {
                    body += figureHtml(take[0], st, true);
                }
            }
        });
    }

    if (!body.trim()) {
        body = `<p class="empty">Für diese Station wurde noch nichts festgehalten.</p>`;
    }

    let collage = '';
    if (photos.length > 1) {
        collage = `<div class="collage">
            <div class="collage-head"><span>Alle Bilder dieser Station</span><em>${photos.length} Fotos, chronologisch</em></div>
            <div class="collage-grid">${photos.map(im => {
                const src = im.thumbUrl || im.url || im.data;
                const d = im.timestamp ? new Date(im.timestamp) : null;
                const t = d && !isNaN(d) ? d.toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '';
                return `<figure class="cl"><img src="${esc(src)}" alt="" loading="lazy">${t ? `<figcaption>${esc(t)}</figcaption>` : ''}</figure>`;
            }).join('')}</div>
        </div>`;
    }

    const desc = st.desc ? `<p class="lede">${esc(st.desc)}</p>` : '';
    const locator = S.stations.length > 1 ? buildLocatorMap(S.stations, idx) : '';

    return `<section class="chapter">
        <header class="chapter-head">
            <div class="chapter-no">${esc(chapterNo)}</div>
            <div class="chapter-title">
                <h2>${esc(st.name)}</h2>
                <div class="chapter-meta">${dateLabel ? esc(dateLabel) + ' · ' : ''}${st.lat.toFixed(3)}, ${st.lng.toFixed(3)}${photos.length ? ' · ' + photos.length + ' Fotos' : ''}</div>
            </div>
            ${locator ? `<div class="locator-wrap">${locator}</div>` : ''}
        </header>
        ${desc}
        ${body}
        ${collage}
    </section>`;
}

export function buildHighlightsSection() {
    const hl = JSON.parse(localStorage.getItem(tripKey('highlights')) || 'null');
    if (!hl || !hl.items || !hl.items.length) return '';
    return `<section class="highlights">
        <div class="hl-kicker">Die Reise in fünf Momenten</div>
        <ol class="hl-list">
            ${hl.items.map((h, i) => `<li><span class="hl-no">${String(i+1).padStart(2,'0')}</span><div><b>${esc(h.title || '')}</b><p>${esc(h.text || '')}</p></div></li>`).join('')}
        </ol>
    </section>`;
}

window.generateDiaryHighlights = async function() {
    if (!S.apiKey || S.apiKey.trim() === "") return showToast("Für die Highlights wird der Gemini API Key in den Einstellungen benötigt.", 'info');

    const material = S.stations.map((st, i) => {
        const todos = (st.todos || []).filter(t => t.done).map(t => t.text).join('; ');
        const blog = (st.blogEntry || '').slice(0, 1800);
        if (!todos && !blog) return '';
        return `STATION ${i}: ${st.name}\nErlebt: ${todos}\nTagebuch: ${blog}`;
    }).filter(Boolean).join('\n\n');

    if (!material.trim()) return showToast("Es gibt noch keine Tagebucheinträge, aus denen Highlights entstehen könnten.", 'info');

    toggleLoader(true, "Highlights werden zusammengestellt...");
    try {
        const prompt = `Hier ist das Material der Reise \"${tripTitle()}\":\n\n${material}\n\nWähle die FÜNF schönsten, besondersten Momente der gesamten Reise aus. Antworte AUSSCHLIESSLICH mit einem JSON-Array, ohne Markdown und ohne Vorrede, im Format:\n[{"title":"kurzer Titel (max 5 Wörter)","text":"ein bis zwei Sätze, warum dieser Moment besonders war"}]\nSchreibe auf Deutsch, warm und persönlich, in der Wir-Form.`;

        // ✅ BUG-2 FIX: callGemini() mit automatischem Retry bei 429/503
        const txt = await callGemini(prompt, {
            onRetry: (attempt, max) => toggleLoader(true, `KI-Dienst ausgelastet – erneuter Versuch ${attempt}/${max}...`)
        });
        const cleaned = txt.replace(/```json|```/g, '').trim();
        const items = JSON.parse(cleaned);
        if (!Array.isArray(items) || !items.length) throw new Error('Unerwartete Antwort');

        localStorage.setItem(tripKey('highlights'), JSON.stringify({ items: items.slice(0, 5), created: Date.now() }));
        toggleLoader(false);
        window.exportDiary();
    } catch (e) {
        toggleLoader(false);
        // ✅ BUG-3 FIX: verständliche deutsche Meldung statt rohem e.message
        console.error('Highlights-Generierung fehlgeschlagen', e);
        showToast('Highlights konnten nicht erstellt werden: ' + getGeminiErrorMessage(e), 'error');
    }
};

export function buildDiaryDocument() {
    const stats = diaryStats();
    const period = (stats.from && stats.to)
        ? `${fmtDate(stats.from, { day: '2-digit', month: 'long' })} – ${fmtDate(stats.to)}`
        : 'Reisetagebuch';

    const chapters = S.stations.map((st, i) => buildStationChapter(st, i)).join('');

    const body = `
    <div class="page">
        <header class="cover">
            <div class="cover-kicker">${esc(tripSubtitle() || 'Reisetagebuch')}</div>
            <h1>${esc(tripTitle())}</h1>
            <div class="cover-rule"></div>
            <div class="cover-period">${esc(period)}</div>
            <div class="stats">
                <div class="stat"><b>${stats.stations}</b><span>Stationen</span></div>
                <div class="stat"><b>${stats.days}</b><span>Reisetage</span></div>
                <div class="stat"><b>${stats.photos}</b><span>Fotos</span></div>
                <div class="stat"><b>${stats.km.toLocaleString('de-DE')}</b><span>km Luftlinie</span></div>
            </div>
        </header>
        ${buildHighlightsSection()}
        ${chapters}
        <footer class="colophon">
            <div class="colophon-rule"></div>
            <p>${esc(tripTitle())} · ${fmtDate(new Date())}</p>
        </footer>
    </div>`;

    const css = `
    @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300;9..144,600;9..144,900&family=Inter:wght@300;400;600&display=swap');
    *{box-sizing:border-box;}
    body{margin:0;background:#e8e3da;font-family:'Inter',system-ui,sans-serif;color:#20302b;line-height:1.75;-webkit-font-smoothing:antialiased;}
    .page{max-width:820px;margin:0 auto;background:#fdfbf7;padding:0 0 60px;box-shadow:0 0 60px rgba(0,0,0,.09);}
    .cover{padding:90px 56px 54px;text-align:center;background:linear-gradient(170deg,#0f3d2e 0%,#14584160 100%),#0f3d2e;color:#f6f2ea;}
    .cover-kicker{font-size:11px;letter-spacing:.32em;text-transform:uppercase;color:#9dc8b4;font-weight:600;}
    .cover h1{font-family:'Fraunces',Georgia,serif;font-weight:900;font-size:clamp(46px,10vw,86px);line-height:.95;margin:14px 0 0;letter-spacing:-.02em;}
    .cover-rule{width:64px;height:3px;background:#d8a13a;margin:26px auto 20px;border-radius:2px;}
    .cover-period{font-size:14px;letter-spacing:.06em;color:#cfe0d6;}
    .stats{display:flex;justify-content:center;gap:34px;flex-wrap:wrap;margin-top:40px;}
    .stat{display:flex;flex-direction:column;align-items:center;min-width:70px;}
    .stat b{font-family:'Fraunces',serif;font-size:30px;font-weight:600;color:#f6f2ea;line-height:1;}
    .stat span{font-size:10px;letter-spacing:.16em;text-transform:uppercase;color:#9dc8b4;margin-top:7px;}
    .chapter{padding:58px 56px 8px;border-bottom:1px solid #e6ded1;}
    .chapter:last-of-type{border-bottom:0;}
    .chapter-head{display:flex;align-items:flex-start;gap:20px;margin-bottom:22px;flex-wrap:wrap;}
    .chapter-title{flex:1 1 220px;min-width:0;}
    .locator-wrap{margin-left:auto;flex-shrink:0;}
    .locator-map{width:168px;height:auto;display:block;filter:drop-shadow(0 5px 14px rgba(15,61,46,.14));}
    .chapter-no{font-family:'Fraunces',serif;font-size:52px;font-weight:900;color:#0f3d2e;opacity:.13;line-height:.8;letter-spacing:-.04em;flex-shrink:0;}
    .chapter-title h2{font-family:'Fraunces',serif;font-size:34px;font-weight:600;margin:0;color:#0f3d2e;letter-spacing:-.01em;line-height:1.15;}
    .chapter-meta{font-size:11px;letter-spacing:.11em;text-transform:uppercase;color:#8a9a92;margin-top:8px;font-weight:600;}
    .lede{font-size:17px;color:#4a5c55;font-style:italic;border-left:3px solid #d8a13a;padding-left:18px;margin:0 0 28px;}
    .chapter p{margin:0 0 18px;font-size:16.5px;color:#2a3b35;}
    .chapter h2,.chapter h3{font-family:'Fraunces',serif;color:#14584a;margin:34px 0 12px;font-weight:600;line-height:1.25;}
    .chapter h2{font-size:23px;} .chapter h3{font-size:19px;}
    .chapter strong{color:#0f3d2e;font-weight:600;}
    .empty{color:#a8b3ae;font-style:italic;}
    .exp{background:#f2ede3;border-radius:14px;padding:22px 26px;margin:0 0 30px;}
    .exp-label{display:block;font-size:10px;letter-spacing:.2em;text-transform:uppercase;color:#997420;font-weight:600;margin-bottom:12px;}
    .exp ul{margin:0;padding-left:18px;}
    .exp li{margin-bottom:7px;font-size:15px;color:#3d4f48;}
    .exp li::marker{color:#d8a13a;}
    .ph{margin:0 0 26px;}
    .ph img{width:100%;display:block;border-radius:10px;box-shadow:0 8px 26px rgba(15,61,46,.16);object-fit:cover;}
    .ph-wide img{max-height:520px;}
    .ph figcaption{font-size:10.5px;letter-spacing:.09em;text-transform:uppercase;color:#93a29b;margin-top:9px;font-weight:600;}
    .ph-duo{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:26px;}
    .ph-duo .ph{margin:0;} .ph-duo img{height:250px;}
    .ph-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:6px 0 26px;}
    .ph-grid .ph{margin:0;} .ph-grid img{height:170px;}
    .highlights{padding:48px 56px 44px;background:#f2ede3;border-bottom:1px solid #e6ded1;}
    .hl-kicker{font-family:'Fraunces',serif;font-size:26px;font-weight:600;color:#0f3d2e;margin-bottom:24px;text-align:center;}
    .hl-list{list-style:none;margin:0;padding:0;display:grid;gap:16px;}
    .hl-list li{display:flex;gap:16px;align-items:flex-start;background:#fdfbf7;border-radius:12px;padding:16px 18px;}
    .hl-no{font-family:'Fraunces',serif;font-size:20px;font-weight:900;color:#d8a13a;line-height:1.1;flex-shrink:0;min-width:30px;}
    .hl-list b{display:block;font-family:'Fraunces',serif;font-size:17px;color:#14584a;font-weight:600;margin-bottom:3px;}
    .hl-list p{margin:0;font-size:14.5px;color:#4a5c55;line-height:1.6;}
    .collage{margin:34px 0 10px;padding-top:24px;border-top:1px dashed #ddd0b4;}
    .collage-head{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:14px;gap:10px;flex-wrap:wrap;}
    .collage-head span{font-size:10px;letter-spacing:.2em;text-transform:uppercase;color:#997420;font-weight:600;}
    .collage-head em{font-size:10px;color:#a8b3ae;font-style:normal;letter-spacing:.06em;}
    .collage-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;}
    .cl{margin:0;}
    .cl img{width:100%;height:104px;object-fit:cover;border-radius:7px;display:block;box-shadow:0 3px 10px rgba(15,61,46,.13);}
    .cl figcaption{font-size:8.5px;color:#a8b3ae;margin-top:4px;letter-spacing:.05em;font-weight:600;}
    .colophon{padding:44px 56px 0;text-align:center;}
    .colophon-rule{width:44px;height:2px;background:#d8c9ab;margin:0 auto 18px;}
    .colophon p{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#a3aea9;margin:0;}
    @media (max-width:680px){
        .cover{padding:60px 24px 40px;} .chapter{padding:40px 24px 6px;}
        .chapter-head{gap:14px;} .chapter-no{font-size:38px;}
        .locator-wrap{width:100%;margin-left:0;order:3;}
        .locator-map{width:140px;margin:4px auto 0;}
        .chapter-title h2{font-size:26px;}
        .ph-grid{grid-template-columns:repeat(2,1fr);}
        .highlights{padding:34px 24px 30px;} .hl-kicker{font-size:21px;}
        .collage-grid{grid-template-columns:repeat(3,1fr);gap:7px;}
        .cl img{height:76px;}
        .colophon{padding:32px 24px 0;}
    }
    @media print{
        body{background:#fff;} .page{box-shadow:none;max-width:none;}
        .chapter{page-break-inside:auto;break-inside:auto;}
        .chapter-head{page-break-after:avoid;}
        .ph,.ph-duo,.ph-grid,.exp,.locator-wrap,.hl-list li,.collage{page-break-inside:avoid;break-inside:avoid;}
        .highlights{page-break-after:always;}
        .cover{page-break-after:always;}
    }`;

    return { body, css };
}

export function fullDiaryHtml() {
    const { body, css } = buildDiaryDocument();
    return `<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${esc(tripTitle())} · Reisetagebuch</title><style>${css}</style></head><body>${body}</body></html>`;
}

window.exportDiary = function() {
    const frame = document.getElementById('export-frame');
    frame.srcdoc = fullDiaryHtml();
    document.getElementById('export-modal').classList.remove('hidden');
    document.getElementById('export-modal').classList.add('flex');
};

window.closeExport = function() {
    const m = document.getElementById('export-modal');
    m.classList.add('hidden');
    m.classList.remove('flex');
};

window.downloadDiaryFile = function() {
    const blob = new Blob([fullDiaryHtml()], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${slugifyName(tripTitle())}_Reisetagebuch_${new Date().toISOString().slice(0,10)}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 4000);
};

window.printDiary = function() {
    const frame = document.getElementById('export-frame');
    if (frame && frame.contentWindow) {
        frame.contentWindow.focus();
        frame.contentWindow.print();
    }
};