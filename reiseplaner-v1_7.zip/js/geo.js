/**
 * geo.js – Standort-Verlauf (Ersatz für von Android entfernte GPS-EXIF-Daten)
 * ==============================================================================
 * Modul-privater State (geoTrack, geoWatchId): wird nur innerhalb dieser Datei
 * gebraucht, daher keine Aufnahme in den globalen State S.
 */

import { showToast } from './utils.js';

export let geoTrack = JSON.parse(localStorage.getItem('skand_geo_track') || '[]');
export let geoWatchId = null;

function saveGeoTrack() {
    // maximal 2000 Punkte behalten, damit localStorage nicht überläuft
    if (geoTrack.length > 2000) geoTrack = geoTrack.slice(-2000);
    localStorage.setItem('skand_geo_track', JSON.stringify(geoTrack));
}

function addGeoPoint(lat, lng, accuracy) {
    const now = Date.now();
    const last = geoTrack[geoTrack.length - 1];
    // Nur speichern, wenn > 60s seit letztem Punkt oder > 50m Abstand
    if (last) {
        const dt = now - last.t;
        const dist = Math.hypot((lat - last.lat) * 111000, (lng - last.lng) * 111000 * Math.cos(lat * Math.PI / 180));
        if (dt < 60000 && dist < 50) return;
    }
    geoTrack.push({ t: now, lat: lat, lng: lng, acc: accuracy || null });
    saveGeoTrack();
}

window.startGeoTracking = function(silent) {
    if (!navigator.geolocation) {
        if (!silent) showToast('Standortbestimmung wird von diesem Browser nicht unterstützt.', 'error');
        return;
    }
    if (geoWatchId !== null) return;
    geoWatchId = navigator.geolocation.watchPosition(
        pos => {
            addGeoPoint(pos.coords.latitude, pos.coords.longitude, pos.coords.accuracy);
            updateGeoTrackStatus();
        },
        err => {
            console.warn('Standort-Tracking Fehler:', err.message);
            if (!silent) showToast('Standort konnte nicht ermittelt werden: ' + err.message, 'error');
            geoWatchId = null;
            updateGeoTrackStatus();
        },
        { enableHighAccuracy: true, maximumAge: 30000, timeout: 20000 }
    );
    localStorage.setItem('skand_geo_tracking_on', '1');
    updateGeoTrackStatus();
};

window.stopGeoTracking = function() {
    if (geoWatchId !== null) {
        navigator.geolocation.clearWatch(geoWatchId);
        geoWatchId = null;
    }
    localStorage.setItem('skand_geo_tracking_on', '0');
    updateGeoTrackStatus();
};

window.toggleGeoTracking = function() {
    if (geoWatchId !== null) window.stopGeoTracking();
    else window.startGeoTracking(false);
};

export function updateGeoTrackStatus() {
    const el = document.getElementById('geo-track-status');
    if (!el) return;
    const active = geoWatchId !== null;
    el.innerHTML = active
        ? `<i class="fa-solid fa-satellite-dish text-green-600"></i> Standort-Aufzeichnung aktiv &middot; ${geoTrack.length} Punkte`
        : `<i class="fa-solid fa-satellite-dish text-slate-400"></i> Standort-Aufzeichnung aus &middot; ${geoTrack.length} Punkte gespeichert`;
    const btn = document.getElementById('geo-track-btn');
    if (btn) {
        btn.innerText = active ? 'Aufzeichnung stoppen' : 'Aufzeichnung starten';
        btn.className = active
            ? 'w-full bg-red-100 text-red-700 py-2 rounded font-bold text-sm hover:bg-red-200'
            : 'w-full bg-emerald-100 text-emerald-700 py-2 rounded font-bold text-sm hover:bg-emerald-200';
    }
}

export function findTrackLocation(timestampIso, toleranceMs = 45 * 60 * 1000) {
    if (!geoTrack.length || !timestampIso) return null;
    const target = new Date(timestampIso).getTime();
    if (isNaN(target)) return null;
    let best = null, bestDiff = Infinity;
    for (const p of geoTrack) {
        const diff = Math.abs(p.t - target);
        if (diff < bestDiff) { bestDiff = diff; best = p; }
    }
    if (best && bestDiff <= toleranceMs) {
        return { lat: best.lat, lng: best.lng, diffMinutes: Math.round(bestDiff / 60000) };
    }
    return null;
}
